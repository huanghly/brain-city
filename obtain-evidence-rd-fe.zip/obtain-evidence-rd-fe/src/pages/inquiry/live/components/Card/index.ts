import Inquiree from './Inquiree';
import Inquirer from './Inquirer';

export default {
  Inquiree,
  Inquirer,
};
