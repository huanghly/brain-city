import Sketch from './Sketch';
import Description from './Description';

export default { Sketch, Description };
