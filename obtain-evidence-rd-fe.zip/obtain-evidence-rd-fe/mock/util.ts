export const wrapResponse = (data: any | any[]) => ({
  errCode: 0,
  errName: '',
  errMsg: '',
  wrapped: true,
  success: true,
  data,
});

export const wrapPagination = (
  totalCount: number,
  toPage: number,
  pageSize: number,
  list: any[],
) => ({
  totalCount,
  toPage,
  pageSize,
  datas: list,
});
