import React from 'react';
import { Tabs } from 'antd';
import styles from './councilor.less';
import { Media } from '@/common/media';

type IProps = {};
type IState = {};
export default class Councilor extends React.PureComponent<IProps, IState> {
  constructor(props: IProps) {
    super(props);
  }
  render() {
    return (
      <div className={styles.councilor}>
        <div className={styles.topContent}>
          <div className={styles.videoList}>
            <Media className={styles.video} src="/chenxiao/demo2.mp4" />
          </div>
          <Media className={styles.mainVideo} src="/chenxiao/demo.mp4" />
          <div className={styles.rightTabs}>
            <Tabs type="card">
              <Tabs.TabPane tab="督导" key="1">
                <img src="/chenxiao/dudao_tab1.png" />
              </Tabs.TabPane>
              <Tabs.TabPane tab="示证" key="2">
                <img src="/chenxiao/dudao_tab2.png" />
              </Tabs.TabPane>
              <Tabs.TabPane tab="笔录" key="3">
                <img src="/chenxiao/record.png" />
              </Tabs.TabPane>
            </Tabs>
          </div>
        </div>
        <div className={styles.btmContent}>
          <div className={styles.btn1}>添加询问室</div>
        </div>
      </div>
    );
  }
}
