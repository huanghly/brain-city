import React, { Component } from 'react';

class CaseEvidence extends Component {
  render() {
    return <div>证据核验</div>;
  }
}

export default CaseEvidence;
