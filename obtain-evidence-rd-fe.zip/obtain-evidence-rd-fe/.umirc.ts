import { resolve } from 'path';
import { defineConfig } from 'umi';

const AntdDayjsWebpackPlugin = require('antd-dayjs-webpack-plugin');

import theme from './theme';

const PUBLIC_PATH = '/';

export const TARGETS = {
  mock: 'http://localhost:8000',
  dev: 'http://47.98.61.153:7001',
  prod: 'http://47.98.61.153:7001',
};

const TARGET = TARGETS[process.env.PROXY_TARGET] || TARGETS.dev;

export default defineConfig({
  publicPath: PUBLIC_PATH,
  define: {
    'process.env.PUBLIC_PATH': PUBLIC_PATH,
  },
  nodeModulesTransform: {
    type: 'none',
  },
  // antd: {
  //   dark: true,
  // },
  theme,
  dva: {
    immer: true,
  },
  proxy: {
    context: (pathname: string, req: any) => {
      return req.headers['x-requested-with'] === 'XMLHttpRequest';
    },
    target: TARGET,
    changeOrigin: true,
    ws: true,
    onProxyReqWs: (proxyReq: any) => {
      proxyReq.setHeader('origin', TARGET);
    },
    secure: false,
  },
  links: [
    {
      rel: 'stylesheet',
      href: '//at.alicdn.com/t/font_1920706_2buqx1saeg7.css',
    },
  ],
  headScripts: [
    {
      src: '//at.alicdn.com/t/font_1920706_2buqx1saeg7.js',
      id: 'script_iconfont',
    },
    {
      src: '/libs/artvc-web-sdk_1.3.2/lib/mcu.js',
      defer: true,
    },
    {
      src: '/libs/artvc-web-sdk_1.3.2/lib/meeting_api.js',
      defer: true,
    },
    {
      src: '/libs/artvc-web-sdk_1.3.2/lib/log4b.js',
      defer: true,
    },
    {
      src: '/libs/artvc-web-sdk_1.3.2/lib/tts_api.js',
      defer: true,
    },
    {
      src: '/libs/artvc-web-sdk_1.3.2/lib/asr_api.js',
      defer: true,
    },
    {
      src: '/libs/artvc-web-sdk_1.3.2/lib/reconnecting-websocket.min.js',
      defer: true,
    },
    {
      src: '/libs/artvc-web-sdk_1.3.2/lib/resampler.js',
      defer: true,
    },
    {
      src: '/libs/artvc-web-sdk_1.3.2/lib/mtc_api.js',
      defer: true,
    },
    {
      src: '/libs/artvc-web-sdk_1.3.2/lib/BandwidthHandler.js',
      defer: true,
    },
    {
      src: '/libs/artvc-web-sdk_1.3.2/lib/RecordRTC.min.js',
      defer: true,
    },
    {
      src: '/libs/artvc-web-sdk_1.3.2/lib/html2canvas.js',
      defer: true,
    },
    {
      src: '/libs/artvc-web-sdk_1.3.2/lib/pdf.js',
      defer: true,
    },
    {
      src: '/libs/artvc-web-sdk_1.3.2/lib/EBML.js',
      defer: true,
    },
  ],
  dynamicImport: {
    loading: 'components/Empty',
  },
  chainWebpack(config) {
    config.resolve.modules.add(resolve(__dirname, './src'));
    config.plugin('AntdDayjsWebpackPlugin').use(new AntdDayjsWebpackPlugin());
    console.log(config);
    config.module
      .rule('worker-loader')
      .test(/\.worker\.js$/i)
      .use('worker-loader')
      .loader('file-loader');
  },
});
