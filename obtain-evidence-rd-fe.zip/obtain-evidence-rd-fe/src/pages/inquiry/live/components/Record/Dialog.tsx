import React, { useEffect, useRef } from 'react';
import { InquiryRecordTypes, RawInquiryRecordLine } from 'umi';

import { WifiOutlined } from '@ant-design/icons';
import { Tooltip, Row, Col, Avatar, message } from 'antd';
import { AvatarProps } from 'antd/lib/avatar';

import styles from './Record.less';

interface DialogProps {
  value: RawInquiryRecordLine[];
}

const Dialog: React.FC<DialogProps> = props => {
  const { value } = props;
  const refDialogList = useRef<any>();

  useEffect(() => {
    const elem = document.querySelector(
      `.${refDialogList.current?.props?.className}`,
    );
    if (elem) {
      elem.scrollTop = elem.scrollHeight;
    }
  }, [value]);

  return (
    <Row align="stretch" justify="space-between" className={styles.dialog}>
      <Col ref={refDialogList} flex={1} className={styles.dialogList}>
        {value.map(item => (
          <DialogItem key={item.asr.msg_id} value={item} />
        ))}
      </Col>
    </Row>
  );
};

export default Dialog;

interface DialogItemProps {
  value: RawInquiryRecordLine;
  // @TODO add avatar display
  avatar?: string;
}

const DialogItem: React.FC<DialogItemProps> = React.memo(props => {
  const { value, avatar } = props;
  const { type, asr } = value;

  const copyContent = () => {
    document.designMode = 'on';
    const inputElem = document.createElement('input');
    document.body.appendChild(inputElem);
    inputElem.setAttribute('value', value.asr.value);
    inputElem.setAttribute('readonly', 'readonly');
    inputElem.select();
    document.execCommand('copy');
    document.body.removeChild(inputElem);
    document.designMode = 'off';
  };

  return (
    <Tooltip title="双击复制文本" placement="bottom">
      <Row align="top" onDoubleClick={copyContent}>
        <Col className={styles.avatarCol}>
          {type === InquiryRecordTypes.Answer && (
            <AvatarCol avatar={avatar} type={type} />
          )}
        </Col>
        <Col className={styles.dialogContent}>
          <div
            className={
              type === InquiryRecordTypes.Ask ? styles.right : styles.left
            }
          >
            <div className={styles.text}>{asr.value}</div>
            <div className={styles.audio}>
              <label>{Math.ceil(asr.sentence_duration / 1000)}''</label>
              <WifiOutlined rotate={90} />
            </div>
          </div>
        </Col>
        <Col className={styles.avatarCol}>
          {type === InquiryRecordTypes.Ask && (
            <AvatarCol avatar={avatar} type={type} />
          )}
        </Col>
      </Row>
    </Tooltip>
  );
});

interface AvatarColProps {
  avatar?: string;
  type: InquiryRecordTypes;
}

const AvatarCol: React.FC<AvatarColProps> = props => {
  const { avatar, type } = props;

  const avatarProps: AvatarProps = { size: 40 };
  if (avatar) {
    avatarProps.src = avatar;
  } else {
    let content: string;
    switch (type) {
      case InquiryRecordTypes.Ask:
        content = '问';
        break;
      case InquiryRecordTypes.Answer:
        content = '答';
        break;
    }
    avatarProps.children = content;
  }

  return <Avatar {...avatarProps} />;
};
