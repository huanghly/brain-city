import React from 'react';
import {
  EvidenceRecord,
  InquirerRoles,
  InquiryMapIdentity,
  InquiryIdentityTypes,
} from 'umi';

import { Spin, Card, Avatar } from 'antd';

import styles from './Card.less';

interface InquirerCardProps {
  value?: EvidenceRecord['detail']['inquirer'];
  mapIdentity: InquiryMapIdentity;
  currentRole: InquirerRoles;
  publish: React.ReactNode;
  subscribe?: React.ReactNode;
}

const InquirerCard: React.FC<InquirerCardProps> = props => {
  const { value, mapIdentity, currentRole, publish, subscribe } = props;
  if (!value) {
    return <Spin />;
  }

  const inquirer = value[mapIdentity[InquiryIdentityTypes.Inquirer]![0]];
  const recorder = value[mapIdentity[InquiryIdentityTypes.Recorder]![0]];

  return (
    <Card title="询问人&记录人" size="small" bordered={false}>
      <div className={styles.imgList}>
        {currentRole === InquirerRoles.Inquirer && (
          <>
            <div>
              {publish}
              <label>询问人：{inquirer?.userName}</label>
            </div>
            <div>
              {subscribe}
              <label>记录人：{recorder?.userName}</label>
            </div>
          </>
        )}
        {currentRole === InquirerRoles.InquirerRecorder && (
          <div>
            {publish}
            <label>询问人&记录人：{inquirer?.userName}</label>
          </div>
        )}
        {currentRole === InquirerRoles.Recorder && (
          <>
            <div>
              {subscribe}
              <label>询问人：{inquirer?.userName}</label>
            </div>
            <div>
              {publish}
              <label>记录人：{recorder?.userName}</label>
            </div>
          </>
        )}
      </div>
    </Card>
  );
};

export default React.memo(InquirerCard);
