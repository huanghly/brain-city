import React from 'react';

import { Layout } from 'antd';

import styles from './Layout.less';

const InquiryLayout: React.FC = props => {
  const [header, left, content, right, footer] = React.Children.toArray(
    props.children,
  );

  return (
    <Layout className={styles.layout}>
      {header}
      <Layout>
        {left}
        {content}
        {right}
      </Layout>
      {footer}
    </Layout>
  );
};

export default InquiryLayout;
