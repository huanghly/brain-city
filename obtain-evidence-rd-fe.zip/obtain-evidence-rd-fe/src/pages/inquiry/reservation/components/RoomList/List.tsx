import React from 'react';
import moment from 'moment';

import { RoomInfo, ReservationSubmit } from 'umi';
import { getDaySectionFromStartTime } from '@/common/util';

import { Divider, Row, Empty, Spin } from 'antd';
import Item, { SelectionReservings } from './Item';

import styles from './index.less';

export interface RoomListProps {
  value: RoomInfo[];
  date: string;
  loading?: boolean;
  onReserve: (reservation: Partial<ReservationSubmit>) => void;
}

interface RoomListStates {
  reservings: SelectionReservings;
}

class RoomList extends React.PureComponent<RoomListProps, RoomListStates> {
  state: Readonly<RoomListStates> = {
    reservings: ['', []],
  };

  componentDidMount() {
    window.addEventListener('click', this.clearSelection, false);
  }

  componentWillUnmount() {
    window.removeEventListener('click', this.clearSelection, false);
  }

  private clearSelection = () => {
    this.setState({
      reservings: ['', []],
    });
  };

  private setReservings = (reservings: SelectionReservings) => {
    this.setState({ reservings });
  };

  private reserve = () => {
    const { value, onReserve } = this.props;
    const [roomId, periods] = this.state.reservings;
    const room = value.find(val => val.roomId === roomId);
    onReserve({ roomId, periods, roomName: room?.roomName });
  };

  render() {
    const { value, date, loading } = this.props;
    const [selectedRoomId, selectedPeriods] = this.state.reservings;
    const currentDate = moment().format('YYYY-MM-DD');
    const startIndex =
      currentDate === date ? getDaySectionFromStartTime(moment()) : undefined;

    return (
      <>
        <Divider />
        <div className={styles.list}>
          <Row align="middle" className={styles.title}>
            <div className={styles.text}>会议室预约</div>
            <ul className={styles.status}>
              <li>
                <span className={`${styles.statusRect} ${styles.available}`} />
                <span>空闲</span>
              </li>
              <li>
                <span
                  className={`${styles.statusRect} ${styles.unavailable}`}
                />
                <span>不可定</span>
              </li>
              <li>
                <span className={`${styles.statusRect} ${styles.reserved}`} />
                <span>已预定</span>
              </li>
            </ul>
          </Row>
          <Spin spinning={loading} wrapperClassName={styles.content}>
            {!value.length ? (
              <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
            ) : (
              value.map(room => (
                <Item
                  key={room.roomId}
                  room={room}
                  date={date}
                  startIndex={startIndex}
                  periods={
                    selectedRoomId === room.roomId ? selectedPeriods : undefined
                  }
                  setReservings={this.setReservings}
                  onReserve={this.reserve}
                />
              ))
            )}
          </Spin>
        </div>
      </>
    );
  }
}

export default RoomList;
