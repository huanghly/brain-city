import React from 'react';

type IProps = {
  src: string;
  className?: string;
  style?: React.CSSProperties;
};

let gNum = 0;
export class Media extends React.PureComponent<IProps> {
  private id = `video_media_${++gNum}`;
  private el!: HTMLDivElement;
  private player!: any;

  private setRef = (el: HTMLDivElement) => {
    this.el = el;
  };

  componentWillReceiveProps(nextProps: IProps) {
    if (nextProps.src !== this.props.src) {
      this.player.loadByUrl(nextProps.src);
    }
  }

  componentDidMount() {
    const { src } = this.props;
    this.player = new Aliplayer({
      id: this.id,
      source: src,
      width: '100%',
      height: '100%',
      autoplay: true,
      isLive: false,
      rePlay: true,
      playsinline: true,
      preload: true,
      controlBarVisibility: 'hover',
      useH5Prism: true,
      skinLayout: [
        {
          name: 'H5Loading',
          align: 'cc',
        },
        {
          name: 'errorDisplay',
          align: 'tlabs',
          x: 0,
          y: 0,
        },
        {
          name: 'infoDisplay',
        },
        {
          name: 'thumbnail',
        },
        {
          name: 'controlBar',
          align: 'blabs',
          x: 0,
          y: 0,
          children: [],
        },
      ],
    });
  }

  render() {
    const { style, className } = this.props;
    return (
      <div className={className} style={style}>
        <div id={this.id} ref={this.setRef}></div>
      </div>
    );
  }
}
