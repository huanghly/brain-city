import {
  EvidenceRecord,
  InquiryMapIdentity,
  EvidenceRecordPerson,
  InquiryIdentityTypes,
} from 'umi';

export function getMapIdentityByRecord(record?: EvidenceRecord) {
  if (!record) {
    return {};
  }
  const inquirers = Object.values(record.detail.inquirer);
  const inquirees = Object.values(record.detail.inquired);
  const mapIdentity: InquiryMapIdentity = {};
  (inquirers as EvidenceRecordPerson[])
    .concat(inquirees)
    .forEach(({ identityType, identityId }) => {
      if (!mapIdentity[identityType]) {
        mapIdentity[identityType] = [identityId];
        return;
      }
      mapIdentity[identityType]!.push(identityId);
    });
  return mapIdentity;
}

export function getInquireeIdentityIdByMapIdentity(
  mapIdentity: InquiryMapIdentity,
) {
  const identityIds =
    mapIdentity[InquiryIdentityTypes.Suspect] ||
    mapIdentity[InquiryIdentityTypes.Victim] ||
    mapIdentity[InquiryIdentityTypes.Witness];
  if (Array.isArray(identityIds)) {
    return identityIds[0];
  }
  return undefined;
}
