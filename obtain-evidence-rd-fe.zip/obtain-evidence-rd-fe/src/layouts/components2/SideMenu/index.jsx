import { Menu } from 'antd';
import PropTypes from 'prop-types';
import './index.less';

const { SubMenu } = Menu;

const SideMenu = ({ sideMenus, handleClick, selectedKeys }) => {
  if (!sideMenus || sideMenus.length === 0) {
    return null;
  }
  return (
    <Menu
      mode="inline"
      theme="light"
      style={{ width: 208, paddingTop: '24px' }}
      onClick={({ key, keyPath }) => {
        handleClick(key, keyPath);
      }}
      selectedKeys={selectedKeys}
    >
      {sideMenus.map(
        ({ name, path: { path }, sideMenus: subMenus, className }) => {
          if (subMenus) {
            return (
              <SubMenu
                key={path}
                title={
                  <span>
                    <span>{name}</span>
                  </span>
                }
              >
                {subMenus.map(item => (
                  <Menu.Item key={item.path}>{item.name}</Menu.Item>
                ))}
              </SubMenu>
            );
          }
          return (
            <Menu.Item
              style={className ? { fontSize: 20, color: '#FFFFFF' } : ''}
              key={path}
            >
              {name}
            </Menu.Item>
          );
        },
      )}
    </Menu>
  );
};

SideMenu.propTypes = {
  sideMenus: PropTypes.arrayOf(
    PropTypes.shape({
      onClick: PropTypes.func,
      name: PropTypes.string,
      id: PropTypes.string,
      checkAuth: PropTypes.bool,
    }),
  ).isRequired,
  handleClick: PropTypes.func,
  selectedKeys: PropTypes.arrayOf(PropTypes.string),
};

export default SideMenu;
