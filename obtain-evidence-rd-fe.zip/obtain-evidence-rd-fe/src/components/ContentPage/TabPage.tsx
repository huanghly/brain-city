import React from 'react';
import classnames from 'classnames';

import ContentPage, { ContentPageProps } from './ContentPage';

import styles from './index.less';

const TabPage: React.FC<ContentPageProps> = props => {
  const { className, ...restProps } = props;

  const cls = classnames({
    [styles.tabPage]: true,
    [className as string]: !!className,
  });
  return (
    <ContentPage className={cls} {...restProps}>
      {props.children}
    </ContentPage>
  );
};

export default TabPage;
