export default window.g_history;
