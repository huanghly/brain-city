/* 
  页面层级配置：
  一个嵌套数组。
  第一层级是顶部的tab
  sideMenus下是侧边栏的配置，支持无限层级嵌套
  会根据pathConfig中配置的路径权限进行配置的筛选，如果配置下的路径都没有权限，则该目录层级会隐藏
*/
import { pathConfigWithRole } from './pathConfig';

import { LayoutConfigItem } from './types';

function getItem(): LayoutConfigItem[] {
  return [
    {
      name: '询问管理',
      pathConfig: pathConfigWithRole.reservation,
      sideMenus: [
        {
          name: '询问预约',
          pathConfig: pathConfigWithRole.createReservation,
          icon: 'icon-schedule',
        },
      ],
    },
    {
      name: '现场询问',
      pathConfig: pathConfigWithRole.inquirySchedule,
      sideMenus: [
        {
          name: '专案组询问日程',
          pathConfig: pathConfigWithRole.inquirySchedule,
          icon: 'icon-schedule',
        },
      ],
    },
    {
      name: '案卷管理',
      pathConfig: pathConfigWithRole.case,
      sideMenus: [
        {
          name: '案件档案',
          pathConfig: pathConfigWithRole.caseAll,
          icon: 'icon-case',
        },
        {
          name: '我的案件',
          pathConfig: pathConfigWithRole.caseMy,
          icon: 'icon-case-my',
        },
        {
          name: '我的调阅',
          pathConfig: pathConfigWithRole.caseSubscription,
          icon: 'icon-transfer',
        },
        {
          name: '我的审批',
          pathConfig: pathConfigWithRole.caseAudit,
          icon: 'icon-verify',
        },
        {
          name: '我发起的',
          pathConfig: pathConfigWithRole.caseMyApplication,
          icon: 'icon-initiate',
        },
      ],
    },
    {
      name: '询问指挥',
      pathConfig: pathConfigWithRole.guide,
      sideMenus: [],
    },
    {
      name: '用户管理',
      // @TODO
      disabled: true,
      pathConfig: pathConfigWithRole.userManagement,
    },
  ];
}

function getLayoutConfig(
  config: LayoutConfigItem[],
  userType?: string,
): LayoutConfigItem[] {
  return config
    .filter(item => !item.pathConfig.role || item.pathConfig.role === userType)
    .map(item => {
      return {
        name: item.name,
        pathConfig: item.pathConfig,
        ...(item.sideMenus
          ? { sideMenus: getLayoutConfig(item.sideMenus, userType) }
          : {}),
        className: item.className,
        // @FIXME
        disabled: item.disabled,
        icon: item.icon,
      };
    });
}

export default function layoutConfig(userType?: string) {
  return getLayoutConfig(getItem(), userType);
}
