import React from 'react';
import classnames from 'classnames';

import styles from './DescriptionCard.less';

interface DescriptionCardProps {
  className?: string;
}

const DescriptionCard: React.FC<DescriptionCardProps> & {
  Title: React.FC;
  Subtitle: React.FC;
} = props => {
  const cls = classnames({
    [styles.descriptionCard]: true,
    [props.className as string]: !!props.className,
  });

  return <div className={cls}>{props.children}</div>;
};

DescriptionCard.Title = props => (
  <div className={styles.title}>{props.children}</div>
);
DescriptionCard.Subtitle = props => (
  <div className={styles.subtitle}>{props.children}</div>
);

export default DescriptionCard;
