import React from 'react';
import classnames from 'classnames';
import { RoomSchedule } from 'umi';

import { getTimespanFromDaySection } from '@/common/util';

import { Tooltip } from 'antd';

import styles from './index.less';

interface RoomListItemCellProps {
  index: number;
  disabled?: boolean;
  reserving: boolean;
  schedule?: RoomSchedule;
  renderReserving: (idx: number) => React.ReactNode;
}

const RoomListItemCell: React.FC<RoomListItemCellProps> = props => {
  const { index, disabled, reserving, schedule, renderReserving } = props;
  const hasReserved = !!schedule;

  const cls = classnames({
    [styles.reserved]: hasReserved,
    [styles.available]: !hasReserved && !disabled,
    [styles.reserving]: reserving,
    [styles.unavailable]: !hasReserved && !!disabled,
  });

  return (
    <li className={cls}>
      {schedule ? (
        <ScheduleContent schedule={schedule} />
      ) : (
        reserving && renderReserving(index)
      )}
    </li>
  );
};

export default RoomListItemCell;

const ScheduleContent: React.FC<Required<
  Pick<RoomListItemCellProps, 'schedule'>
>> = props => {
  const { periods, reservedName } = props.schedule;

  const title = `${getTimespanFromDaySection(periods[0])[0]}~${
    getTimespanFromDaySection(periods[periods.length - 1])[1]
  } 已被 ${reservedName} 预定`;

  return (
    <Tooltip title={title} placement="bottom">
      <span></span>
    </Tooltip>
  );
};
