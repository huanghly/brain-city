import React, { Component } from 'react';
import { Moment } from 'moment';
import {
  connect,
  ConnectProps,
  RootModelState,
  Dispatch,
  UserInfo,
  CaseSimple,
  Case,
  ReservationStatus,
  ReservationQueryParams,
  ReservationSubmit,
  ModelNamespaces,
} from 'umi';
import { getDispatchType } from '@/common/util';

import { Tabs, Row, Col, Popconfirm, Button, message } from 'antd';
const { TabPane } = Tabs;

import { TabPage } from '@/components/ContentPage';
import ReservationCardList from '@/components/ReservationCardList';
import SearchForm from './components/SearchForm';
import ReservationDrawer from './components/ReservationDrawer';
import CaseDrawer from '@/pages/case/components/CaseDrawer';
import ScheduleCalendar from './components/ScheduleCalendar';

import styles from './reservation.less';

interface MyReservationStates {
  reservationQueryParams: ReservationQueryParams;
  reservationDrawerVisible: boolean;
  caseDrawerVisible: boolean;
  suggestedCases: CaseSimple[];
  selectedCaseUsers: UserInfo[];
  editingCase?: Partial<Case>;
}

type MyReservationProps = ConnectProps &
  MyReservationStateProps &
  MyReservationDispatchProps;

class MyReservation extends Component<MyReservationProps, MyReservationStates> {
  state: Readonly<MyReservationStates> = {
    reservationQueryParams: {},
    reservationDrawerVisible: false,
    caseDrawerVisible: false,
    suggestedCases: [],
    selectedCaseUsers: [],
  };

  private queryMyReservation = (
    queryParams?: Partial<ReservationQueryParams>,
  ) => {
    const { reservationQueryParams } = this.state;
    const params = {
      ...reservationQueryParams,
      ...queryParams,
    };
    this.setState({ reservationQueryParams: params });
    this.props.getMyPaginationReservations(params);
  };

  private openReservationDrawer = () => {
    if (!this.state.suggestedCases.length) {
      this.querySuggestedCases('');
    }
    this.setState({ reservationDrawerVisible: true });
  };

  private querySuggestedCases = (keyword: string) => {
    this.props.getSuggestedCases(keyword, (suggestedCases: CaseSimple[]) => {
      this.setState({ suggestedCases });
    });
  };

  private queryCaseUsers = (caseId: string) => {
    this.props.getUsers(caseId, (users: UserInfo[]) => {
      this.setState({ selectedCaseUsers: users });
    });
  };

  private addReservation = (reservation: ReservationSubmit) => {
    this.props.addReservation(reservation, () => {
      this.setState({ reservationDrawerVisible: false });
      this.queryMyReservation();
      message.info('预约成功！');
    });
  };

  private createCase = () => {
    const {
      currentUser,
      users,
      caseTypes,
      getUsers,
      getCaseTypes,
    } = this.props;
    if (!users.length) {
      getUsers(null);
    }
    if (!caseTypes.length) {
      getCaseTypes();
    }
    this.setState({
      editingCase: {
        creatorId: currentUser?.userId,
        creatorName: currentUser?.userName,
      },
      caseDrawerVisible: true,
    });
  };

  private saveCase = (value: Case) => {
    const { editingCase } = this.state;
    const updatedCase = { ...editingCase, ...value };
    this.props.saveCase(updatedCase, () => {
      this.setState({ caseDrawerVisible: false });
      message.info('新增案事件成功！');
    });
  };

  private closeReservationDrawer = () => {
    this.setState({ reservationDrawerVisible: false, selectedCaseUsers: [] });
  };

  private closeCaseDrawer = () => {
    this.setState({ caseDrawerVisible: false });
  };

  private removeReservation = (reservationId: string) => {
    this.props.releaseRoom(reservationId, () => {
      message.info('释放成功！');
    });
  };

  private changeMonth = (step: 1 | -1) => {
    const { selectedDate, setSelectedDate } = this.props;
    const nextSelectedDate = selectedDate.add(step, 'month');
    setSelectedDate(nextSelectedDate);
  };

  private renderFooter = (id: string, status: ReservationStatus) => {
    return (
      status === ReservationStatus.NotStarted && (
        <Popconfirm
          title="确认要释放吗？"
          placement="bottomRight"
          onConfirm={() => this.removeReservation(id)}
        >
          <Button size="small">释放</Button>
        </Popconfirm>
      )
    );
  };

  private paginationChange = (current: number, pageSize?: number) => {
    this.queryMyReservation({ current, pageSize });
  };

  render() {
    const {
      myReservations,
      reservations,
      monthReservationDates,
      selectedDate,
      users,
      caseTypes,
      setSelectedDate,
      downloadRecordTemplate,
    } = this.props;

    const {
      reservationDrawerVisible,
      caseDrawerVisible,
      suggestedCases,
      selectedCaseUsers,
      editingCase,
    } = this.state;

    return (
      <TabPage className={styles.my} title="我的预约">
        <Tabs defaultActiveKey="reservation">
          <TabPane tab="询问预约" key="reservation">
            <SearchForm.MyReservation
              onCreate={this.openReservationDrawer}
              onChange={this.queryMyReservation}
            />
            <ReservationCardList
              pagination={myReservations}
              renderFooter={this.renderFooter}
              onPaginationChange={this.paginationChange}
            />
          </TabPane>
          <TabPane tab="日程提醒" key="schedule">
            <Row className={styles.content}>
              <Col className={styles.scheduleSelector}>
                <ScheduleCalendar.Selector
                  dates={monthReservationDates}
                  value={selectedDate}
                  selectedStyleType="dot"
                  onSelect={setSelectedDate}
                  onChangeMonth={this.changeMonth}
                />
                <ScheduleCalendar.Timeline
                  className={styles.timeline}
                  value={reservations.day}
                />
              </Col>
              <Col flex={1} className={styles.calendar}>
                <ScheduleCalendar.Calendar
                  date={selectedDate}
                  reservations={reservations}
                />
              </Col>
            </Row>
          </TabPane>
        </Tabs>
        <ReservationDrawer
          visible={reservationDrawerVisible}
          users={selectedCaseUsers}
          cases={suggestedCases}
          onSearchCase={this.querySuggestedCases}
          onSearchCaseUsers={this.queryCaseUsers}
          onCreateCase={this.createCase}
          onDownloadTemplate={downloadRecordTemplate}
          onClose={this.closeReservationDrawer}
          onSave={this.addReservation}
        />
        <CaseDrawer
          visible={caseDrawerVisible}
          caseTypes={caseTypes}
          users={users}
          value={editingCase}
          onSave={this.saveCase}
          onCancel={this.closeCaseDrawer}
        />
      </TabPage>
    );
  }
}

const mapStateToProps = (state: RootModelState) => ({
  myReservations: state.reservation.myReservations,
  reservations: state.reservation.reservations,
  monthReservationDates: state.reservation.monthReservationDates,
  selectedDate: state.reservation.selectedDate,
  caseTypes: state.case.caseTypes,
  users: state.user.users,
  currentUser: state.user.currentUser,
  loading: state.loading,
});

const mapDispatchToProps = (dispatch: Dispatch) => ({
  getMyPaginationReservations: (params: ReservationQueryParams) =>
    dispatch({
      type: getDispatchType(
        ModelNamespaces.Reservation,
        'getMyPaginationReservations',
      ),
      payload: { params },
    }),
  releaseRoom: (reservationId: string, callback: () => void) =>
    dispatch({
      type: getDispatchType(ModelNamespaces.Reservation, 'releaseRoom'),
      payload: { reservationId },
      callback,
    }),
  setSelectedDate: (date: Moment) =>
    dispatch({
      type: getDispatchType(ModelNamespaces.Reservation, 'setSelectedDate'),
      payload: { date },
    }),
  getSuggestedCases: (
    keyword: string,
    callback: (suggestedCases: CaseSimple[]) => void,
  ) =>
    dispatch({
      type: `${ModelNamespaces.Case}/getSuggestedCases`,
      payload: { keyword },
      callback,
    }),
  getCaseTypes: () =>
    dispatch({
      type: `${ModelNamespaces.Case}/getCaseTypes`,
    }),
  getUsers: (caseId: string | null, callback?: (users: UserInfo[]) => void) =>
    dispatch({
      type: `${ModelNamespaces.User}/getUsers`,
      payload: { caseId },
      callback,
    }),
  saveCase: (updatedCase: Case, callback: () => void) =>
    dispatch({
      type: `${ModelNamespaces.Case}/saveCase`,
      payload: updatedCase,
      callback,
    }),
  downloadRecordTemplate: () =>
    dispatch({
      type: getDispatchType(
        ModelNamespaces.Reservation,
        'downloadRecordTemplate',
      ),
    }),
  addReservation: (reservation: ReservationSubmit, callback: () => void) =>
    dispatch({
      type: 'reservation/addReservation',
      payload: {
        reservation,
      },
      callback,
    }),
});

type MyReservationStateProps = ReturnType<typeof mapStateToProps>;
type MyReservationDispatchProps = ReturnType<typeof mapDispatchToProps>;

export default connect(mapStateToProps, mapDispatchToProps)(MyReservation);
