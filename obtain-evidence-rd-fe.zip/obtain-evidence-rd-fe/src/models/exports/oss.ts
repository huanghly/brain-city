import { Effect, ModelNamespaces } from 'umi';

export type OSSFileInfo = {
  ossFileName: string;
  originFileName: string;
  md5: string;
};

export interface OSSModelType {
  namespace: ModelNamespaces.OSS;
  effects: {
    getOssFiles: Effect;
  };
}
