import React from 'react';
import classnames from 'classnames';

import { PageHeader } from 'antd';
import { PageHeaderProps } from 'antd/lib/page-header';

import styles from './index.less';

export interface ContentPageProps extends PageHeaderProps {
  bordered?: boolean;
}

const ContentPage: React.FC<ContentPageProps> = props => {
  const { children, bordered, className, ...restPageHeaderProps } = props;

  const cls = classnames({
    [styles.contentPage]: true,
    [styles.bordered]: !!bordered,
    [className as string]: !!className,
  });
  return (
    <div className={cls}>
      <PageHeader {...restPageHeaderProps} />
      <div>{props.children}</div>
    </div>
  );
};

ContentPage.defaultProps = {
  bordered: true,
};

export default ContentPage;
