import React from 'react';
import { omit } from 'lodash-es';
import { ReservationSimple } from 'umi';

import { Pagination, Row, Col, Empty } from 'antd';
import { PaginationProps } from 'antd/lib/pagination';
import Card, { ReservationCardProps } from './Card';

import styles from './index.less';

interface ReservationCardListProps
  extends Pick<ReservationCardProps, 'renderFooter'> {
  dataSource?: ReservationSimple[];
  pagination?: PaginationModel<ReservationSimple>;
  onPaginationChange?: PaginationProps['onChange'];
}

const ReservationCardList: React.FC<ReservationCardListProps> = props => {
  const { pagination, dataSource, renderFooter, onPaginationChange } = props;
  let paginationProps: Partial<PaginationProps> | null = null;
  let list: ReservationSimple[] = [];

  if (pagination) {
    list = pagination.list;
    paginationProps = omit(pagination, 'list');
  } else if (dataSource) {
    list = dataSource;
  }

  if (!Array.isArray(list) || !list.length) {
    return (
      <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="暂无询问预约" />
    );
  }

  return (
    <div className={styles.list}>
      <div>
        <Row gutter={[16, 16]}>
          {list.map(item => (
            <Col key={item.id} xl={6} lg={8} sm={12} xs={24}>
              <Card value={item} renderFooter={renderFooter} />
            </Col>
          ))}
        </Row>
      </div>
      {paginationProps && (
        <Row justify="end">
          <Pagination
            {...paginationProps}
            showTotal={total => <span>共有{total}条</span>}
            pageSizeOptions={['8', '12', '16', '20']}
            showSizeChanger
            showQuickJumper
            onChange={onPaginationChange}
            onShowSizeChange={onPaginationChange}
          />
        </Row>
      )}
    </div>
  );
};

export default ReservationCardList;
