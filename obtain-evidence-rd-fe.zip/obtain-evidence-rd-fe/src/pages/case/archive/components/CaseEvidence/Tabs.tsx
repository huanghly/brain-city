import React from 'react';

import { Tabs } from 'antd';
const { TabPane } = Tabs;

import styles from './CaseEvidence.less';

const CaseEvidenceTabs: React.FC = props => {
  const [
    imageEvidence,
    elementExtract,
    screenRecording,
    videoRecording,
  ] = React.Children.toArray(props.children);

  return (
    <Tabs type="card" className={styles.tabs}>
      <TabPane tab="现场示证" key="imageEvidence">
        {imageEvidence}
      </TabPane>
      <TabPane tab="要素提取" key="elementExtract">
        {elementExtract}
      </TabPane>
      <TabPane tab="操作录屏" key="screenRecording">
        {screenRecording}
      </TabPane>
      <TabPane tab="录音录像" key="videoRecording">
        {videoRecording}
      </TabPane>
    </Tabs>
  );
};

export default CaseEvidenceTabs;
