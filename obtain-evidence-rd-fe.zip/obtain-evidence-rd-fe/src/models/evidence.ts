import {
  RootModelState,
  EvidenceModelState,
  EvidenceModelType,
  EvidenceBase,
  InquiryEvidence,
  EvidenceImage,
  EvidenceVideo,
  EvidenceRecord,
  EvidencePersonPayload,
  InquireeWsPayload,
  matchPath,
  getMapIdentityByRecord,
} from 'umi';
import moment from 'moment';
import { set, get } from 'lodash-es';

import {
  ModelNamespaces,
  EvidenceFrom,
  EvidenceTypes,
  InquirerRoles,
  InquiryIdentityTypes,
} from './constants';
import { NotificationActions } from '@/common/constants';
import api from '@/services';
import { RouteParams } from '@/common/route';
import { getDispatchType, handleError } from '@/common/util';

const initialState: EvidenceModelState = {
  currentInquiryEvidence: {
    inquiree: [],
    inquirer: [],
  },
  currentEvidenceStatus: {
    inquireeDirty: false,
  },
  mapIdentity: {},
  currentRole: InquirerRoles.None,
  caseInquiriesEvidences: {},
};

const EvidenceModel: EvidenceModelType = {
  namespace: ModelNamespaces.Evidence,
  state: initialState,
  effects: {
    *getInquiryEvidences({ payload }, { all, call, put }) {
      const { inquiryId, evidenceFrom } = payload;
      const effects: {
        inquirer?: Function;
        inquiree?: Function;
      } = {};
      if (evidenceFrom === EvidenceFrom.Inquirer || !evidenceFrom) {
        effects.inquirer = call(api.getEvidences, {
          inquiryId,
          type: EvidenceTypes.Image,
          evidenceFrom: EvidenceFrom.Inquirer,
        });
      }
      if (evidenceFrom === EvidenceFrom.Inquiree || !evidenceFrom) {
        effects.inquiree = call(api.getEvidences, {
          inquiryId,
          type: EvidenceTypes.Image,
          evidenceFrom: EvidenceFrom.Inquiree,
        });
      }
      try {
        const { inquirer, inquiree } = yield all(effects);
        if (inquirer) {
          yield put({
            type: 'save',
            payload: {
              value: inquirer,
              path: ['currentInquiryEvidence', 'inquirer'],
            },
          });
        }
        if (inquiree) {
          yield put({
            type: 'save',
            payload: {
              value: inquiree,
              path: ['currentInquiryEvidence', 'inquiree'],
            },
          });
        }
      } catch (err) {
        handleError(err);
      }
    },

    *getInquiryRecordEvidence({ payload }, { select, all, call, put }) {
      let inquiryId = payload?.inquiryId;
      if (!inquiryId) {
        inquiryId = yield select(
          (state: RootModelState) => state.inquiry.live.currentInquiryId,
        );
      }
      try {
        const asyncData = yield call(api.getEvidences, {
          inquiryId,
          type: EvidenceTypes.Record,
        });
        const record: EvidenceRecord = asyncData[0];
        const currentUserId = yield select(
          (state: RootModelState) => state.user.currentUser!.userId,
        );

        const mapIdentity = getMapIdentityByRecord(record);
        const inquirerId =
          record.detail.inquirer[mapIdentity[InquiryIdentityTypes.Inquirer]![0]]
            .userId;
        const recorderId =
          record.detail.inquirer[mapIdentity[InquiryIdentityTypes.Recorder]![0]]
            .userId;

        let currentRole = InquirerRoles.None;
        if (currentUserId === inquirerId && currentUserId === recorderId) {
          currentRole = InquirerRoles.InquirerRecorder;
        } else if (currentUserId === inquirerId) {
          currentRole = InquirerRoles.Inquirer;
        } else if (currentUserId === recorderId) {
          currentRole = InquirerRoles.Recorder;
        }

        yield all([
          put({
            type: 'save',
            payload: {
              value: { currentRole, mapIdentity },
              partial: true,
            },
          }),
          put({
            type: 'save',
            payload: {
              value: record,
              path: ['currentInquiryEvidence', 'record'],
            },
          }),
        ]);
        if (payload?.init) {
          yield put({
            type: `${ModelNamespaces.Inquiry}/save`,
            payload: {
              value: record.detail.lines,
              path: ['live', 'recordLines'],
            },
          });
        }
      } catch (err) {
        handleError(err);
      }
    },

    *updateInquiryEvidence({ payload }, { put }) {
      const { value, path } = payload;
      const evidencePath = [...path];
      evidencePath.unshift('currentInquiryEvidence');
      yield put({ type: 'save', payload: { value, path: evidencePath } });
    },
    *updateInquiryEvidenceFromWs(action, { select, all, put }) {
      const payload: InquireeWsPayload = action.payload;

      const [
        inquireeImageEvidences,
        inquirerImageEvidences,
        currentInquiryId,
      ]: [
        EvidenceImage[],
        EvidenceImage[],
        number,
      ] = yield select((state: RootModelState) => [
        state.evidence.currentInquiryEvidence.inquiree,
        state.evidence.currentInquiryEvidence.inquirer,
        state.inquiry.live.currentInquiryId,
      ]);

      switch (payload.action) {
        case NotificationActions.imageEvidenceUploaded:
          const updatedEvidences = inquireeImageEvidences.concat(
            payload.evidences.map(({ evidenceFile, signImage, id }) => {
              const item: EvidenceImage = {
                id,
                inquiryId: currentInquiryId,
                evidenceFrom: EvidenceFrom.Inquiree,
                type: EvidenceTypes.Image,
                detail: {
                  file: evidenceFile,
                  inquiredSignImage: signImage,
                  confirmedList: [],
                },
              };
              return item;
            }),
          );
          yield all([
            put({
              type: 'updateInquiryEvidence',
              payload: {
                value: updatedEvidences,
                path: ['inquiree'],
              },
            }),
            put({
              type: 'setCurrentEvidenceStatus',
              payload: {
                key: 'inquireeDirty',
                value: true,
              },
            }),
          ]);
          break;
        case NotificationActions.imageEvidenceConfirmed:
          const imageEvidenceIdx = inquirerImageEvidences.findIndex(
            evidence => evidence.id === payload.evidenceId,
          );
          if (imageEvidenceIdx >= 0) {
            const { confirmedList } = inquirerImageEvidences[
              imageEvidenceIdx
            ].detail;
            // @FIXME
            const updatedConfirmedList = confirmedList.concat({
              userId: payload.identityId,
              userName: '',
              confirmedTime: moment().format('YYYY-MM-DD HH:mm:ss'),
            });
            yield put({
              type: 'updateInquiryEvidence',
              payload: {
                value: updatedConfirmedList,
                path: ['inquirer', imageEvidenceIdx, 'detail', 'confirmedList'],
              },
            });
          }
          break;
        case NotificationActions.recordConfirmed:
        case NotificationActions.recordSigned:
          yield put({ type: 'updateEvidencePersonConfirmFromWs', payload });
          break;
      }
    },

    *setCurrentEvidenceStatus({ payload }, { put }) {
      const { key, value } = payload;
      yield put({
        type: 'save',
        payload: { value: value, path: ['currentEvidenceStatus', key] },
      });
    },

    *editEvidenceCategoryPersons({ payload }, { select, call, put }) {
      const evidenceId: number = yield select(
        (state: RootModelState) =>
          state.evidence.currentInquiryEvidence.record?.id,
      );
      const { type, partialValue } = payload;
      try {
        yield call(api.editEvidenceCategoryPersons, {
          type,
          info: JSON.stringify(partialValue),
          evidenceId,
        });
        yield put({
          type: getDispatchType(
            ModelNamespaces.Evidence,
            'getInquiryRecordEvidence',
          ),
        });
      } catch (err) {
        handleError(err);
      }
    },

    *editEvidencePerson({ payload, callback }, { select, all, call, put }) {
      const evidenceId: number = yield select(
        (state: RootModelState) =>
          state.evidence.currentInquiryEvidence.record?.id,
      );
      let requestParams = payload;
      if (!Array.isArray(payload)) {
        requestParams = [payload];
      }
      try {
        yield all(
          requestParams.map((param: EvidencePersonPayload) =>
            call(api.editEvidencePerson, { ...param, evidenceId }),
          ),
        );
        yield put({
          type: getDispatchType(
            ModelNamespaces.Evidence,
            'getInquiryRecordEvidence',
          ),
        });
        callback();
      } catch (err) {
        handleError(err);
      }
    },

    *uploadImageEvidences({ payload }, { select, all, call, put }) {
      const { files } = payload;
      const currentInquiryId = yield select(
        (state: RootModelState) => state.inquiry.live.currentInquiryId,
      );
      try {
        const effects: Function[] = files.map((file: File) => {
          const formData = new FormData();
          formData.append('type', EvidenceTypes.Image.toString());
          formData.append('evidenceFile', file);
          formData.append('evidenceFrom', EvidenceFrom.Inquirer.toString());
          formData.append('inquiryId', currentInquiryId);
          return call(api.uploadEvidence, formData);
        });
        yield all(effects);
        yield put({
          type: 'getInquiryEvidences',
          payload: {
            evidenceFrom: EvidenceFrom.Inquirer,
            inquiryId: currentInquiryId,
          },
        });
      } catch (err) {
        handleError(err);
      }
    },

    *getCaseInquiryEvidences({ payload }, { call, put }) {
      const { inquiryId } = payload;
      try {
        const evidences: EvidenceBase[] = yield call(api.getEvidences, {
          inquiryId,
        });
        const inquiryEvidence: InquiryEvidence = {
          inquirer: [],
          inquiree: [],
          screen: [],
        };
        evidences.forEach(item => {
          switch (item.type) {
            case EvidenceTypes.Image:
              if (item.evidenceFrom === EvidenceFrom.Inquirer) {
                inquiryEvidence.inquirer.push(item as EvidenceImage);
              } else if (item.evidenceFrom == EvidenceFrom.Inquiree) {
                inquiryEvidence.inquiree.push(item as EvidenceImage);
              }
              break;
            case EvidenceTypes.Record:
              inquiryEvidence.record = item as EvidenceRecord;
              break;
            case EvidenceTypes.Video:
              inquiryEvidence.video = item as EvidenceVideo;
              break;
            case EvidenceTypes.Screen:
              inquiryEvidence.screen!.push(item as EvidenceVideo);
              break;
          }
        });
        const mapIdentity = getMapIdentityByRecord(inquiryEvidence.record);
        yield put({
          type: 'save',
          payload: {
            value: { evidence: inquiryEvidence, mapIdentity },
            path: ['caseInquiriesEvidences', inquiryId],
          },
        });
      } catch (err) {
        handleError(err);
      }
    },
  },
  reducers: {
    save(state, action) {
      const { value, path, partial } = action.payload;
      if (!path) {
        Object.keys(value).forEach(key => set(state, key, value[key]));
        return;
      }
      if (!partial) {
        set(state, path, value);
        return;
      }
      const prevValue = get(state, path);
      const newValue = {
        ...prevValue,
        ...value,
      };
      set(state, path, newValue);
    },
    updateEvidencePersonConfirmFromWs(state, action) {
      const payload: InquireeWsPayload = action.payload;
      const evidencePersons = state.currentInquiryEvidence.record?.detail
        .inquired!;
      switch (payload.action) {
        case NotificationActions.recordConfirmed:
          const {
            confirmImage,
            signImage,
            startConfirmTime,
            endConfirmTime,
            identityId,
          } = payload;
          if (confirmImage) {
            evidencePersons[identityId].confirmImage = {
              ossFileName: confirmImage,
              originFileName: '',
              md5: '',
            };
          }
          if (signImage) {
            evidencePersons[identityId].signImage = {
              ossFileName: signImage,
              originFileName: '',
              md5: '',
            };
          }
          if (startConfirmTime) {
            evidencePersons[identityId].confirmBeginTime = startConfirmTime;
            evidencePersons[identityId].confirmEndTime = endConfirmTime;
          }
          break;
        case NotificationActions.recordSigned:
          evidencePersons[payload.identityId].signImage = {
            ossFileName: payload.signature,
            originFileName: '',
            md5: '',
          };
          break;
      }
    },
  },
  subscriptions: {
    setup({ dispatch, history }) {
      return history.listen(({ pathname }) => {
        const match = matchPath<RouteParams>(pathname, {
          path: '/inquiry/live/:inquiryId',
          exact: true,
        });
        if (!match) {
          dispatch({
            type: 'save',
            payload: { value: initialState },
          });
        }
      });
    },
  },
};

export default EvidenceModel;
