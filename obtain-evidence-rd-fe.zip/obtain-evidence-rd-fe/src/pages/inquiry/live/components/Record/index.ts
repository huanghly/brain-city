import Dialog from './Dialog';
import Evidence from './Evidence';
import Receive from './Receive';

export default { Dialog, Evidence, Receive };
