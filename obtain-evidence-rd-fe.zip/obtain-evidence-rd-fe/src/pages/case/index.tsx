import React from 'react';
import { Redirect } from 'umi';
import pathConfig from '@/config/pathConfig';

export default () => {
  return <Redirect to={pathConfig.caseAll} />;
};
