import React from 'react';

import { Row, Badge } from 'antd';

import styles from './CaseCard.less';

const Description: React.FC = () => {
  return (
    <Row className={styles.description} align="middle" justify="space-around">
      <Badge color="green" text="本案原始笔录" />
      <Badge color="orange" text="本案并案笔录" />
    </Row>
  );
};

export default Description;
