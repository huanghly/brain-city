import { Effect, ModelNamespaces, RecordDownloadStatus } from 'umi';

export interface InquiryDownloadResponse {
  state: RecordDownloadStatus;
  msg: string;
  url: string;
}

export interface DownloadModelType {
  namespace: ModelNamespaces.Download;
  effects: {
    downloadInquiryRecord: Effect;
    exportInquiryRecord: Effect;
  };
}
