import React from 'react';
import moment, { Moment } from 'moment';
import { range, divide } from 'lodash-es';
import { CalendarReservation } from 'umi';

import { DAYS_OF_WEEK, DAY_SECTIONS, DAY_HOURS } from '@/common/constants';
import { DayItems, DaySectionsRange } from './constants';
import { getDaySectionFromStartTime } from '@/common/util';

import { Row, Col, Popover } from 'antd';

import Container from './Container';
import Card from '@/components/ReservationCardList/Card';

import styles from './Calendar.less';

interface CalendarWeekProps {
  date: Moment;
  value: CalendarReservation[];
}

const CalendarWeek: React.FC<CalendarWeekProps> = props => {
  const { date, value } = props;

  const firstDay = date.startOf('week');
  const daysOfWeek = range(0, DAYS_OF_WEEK);

  return (
    <Container
      header={daysOfWeek.map(idx => {
        const currentDate = firstDay.add(idx, 'days');
        return (
          <div key={idx} className={styles.title}>
            {currentDate.format('D')} {currentDate.format('ddd')}
          </div>
        );
      })}
    >
      {daysOfWeek.map(idx => {
        const currentDate = firstDay.add(idx, 'days');
        const currentReservations = value.filter(
          ({ date }) => date === currentDate.format('YYYY-MM-DD'),
        );
        return (
          <div key={idx} className={styles.column}>
            <div className={styles.body}>
              {DaySectionsRange.map(idx => (
                <div className={styles.cell} key={idx}></div>
              ))}
              {currentReservations.map((reservation, idx) => {
                const {
                  startTime,
                  durationHours,
                  roomName,
                  caseName,
                } = reservation;
                const section = getDaySectionFromStartTime(startTime) as number;

                const style: React.CSSProperties = {
                  top: `${(section / DAY_SECTIONS) * 100}%`,
                  height: `calc(${(durationHours / DAY_HOURS) * 100}% + 1px)`,
                };

                return (
                  <Popover
                    key={idx}
                    placement="bottomLeft"
                    content={
                      <Card
                        bordered={false}
                        className={styles.card}
                        value={reservation}
                      />
                    }
                  >
                    <div className={styles.calendarLine} style={style}>
                      <span>
                        {roomName}（{caseName}）
                      </span>
                    </div>
                  </Popover>
                );
              })}
            </div>
          </div>
        );
      })}
    </Container>
  );
};

export default CalendarWeek;
