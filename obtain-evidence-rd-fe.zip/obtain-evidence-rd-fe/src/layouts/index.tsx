import React from 'react';
import {
  ConnectProps,
  connect,
  history,
  withRouter,
  UserInfo,
  RootModelState,
} from 'umi';
import { RouteComponentWithParams } from '@/common/route';

import zhCN from 'antd/lib/locale-provider/zh_CN';
import { ConfigProvider, Skeleton } from 'antd';
import Error from '@/components/Error';
import { Layout, Header, Sider, Content } from './components/Layout';

import layoutConfig from '@/config/layoutConfig';
const Menus = layoutConfig();

import styles from '@/assets/styles/reset.less';
console.log(styles);

type PortalProps = ConnectProps & PortalStateProps & RouteComponentWithParams;

interface PortalStates {
  errorMessage: string;
}

class Portal extends React.PureComponent<PortalProps, PortalStates> {
  state = { errorMessage: '' };

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    console.error('Layout Catched Error:', error, info);
    this.setState({
      errorMessage: error.message || 'Layout Catched Error with no message.',
    });
  }

  private goHome = () => {
    history.push('/');
    this.setState({
      errorMessage: '',
    });
  };

  private getPopupContainer = () => document.body;

  render() {
    const { errorMessage } = this.state;
    if (errorMessage) {
      return (
        <Error
          message={errorMessage}
          returnButtonText="返回首页"
          onReturn={this.goHome}
        />
      );
    }
    const pathname = this.props.location.pathname;
    const sideMenus = Menus.find(({ pathConfig }) =>
      pathname.startsWith(pathConfig.path),
    )?.sideMenus;

    const { currentUser } = this.props;

    if (!currentUser) {
      return <Skeleton active paragraph={{ rows: 15 }} />;
    }

    return (
      <ConfigProvider locale={zhCN} getPopupContainer={this.getPopupContainer}>
        {sideMenus !== undefined ? (
          <Layout>
            <Header navgations={Menus} userName={currentUser?.userName} />
            {sideMenus.length ? <Sider menus={sideMenus} /> : null}
            <Content>{this.props.children}</Content>
          </Layout>
        ) : (
          this.props.children
        )}
      </ConfigProvider>
    );
  }
}

type PortalStateProps = {
  currentUser?: UserInfo;
};

export default withRouter(
  connect<PortalStateProps, {}, {}, RootModelState>(state => ({
    currentUser: state.user.currentUser,
  }))(Portal),
);
