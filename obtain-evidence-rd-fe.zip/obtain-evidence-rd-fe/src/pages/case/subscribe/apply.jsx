import React, { Component, useState } from 'react';
import { Button, Drawer, Input } from 'antd';
import styles from './index.less';

class Apply extends Component {
  render() {
    const { onClose, visible } = this.props;

    return (
      <Drawer
        title="案事件卷宗调阅申请"
        placement="right"
        width={640}
        visible={visible}
        onClose={onClose}
        footer={
          <div style={{ textAlign: 'left' }}>
            <Button
              onClick={onClose}
              type="primary"
              style={{ marginLeft: 10, marginRight: 10 }}
            >
              确定
            </Button>
            <Button onClick={onClose}>取消</Button>
          </div>
        }
      >
        <div className={styles.Applyinfo}>
          <h3>莲花小区盗窃案</h3>
          <div>申请时间：2020-06-20 10:00</div>
          <div>审批人：张三</div>
        </div>
        <div className={styles.title}>申请事由</div>
        <Input.TextArea rows={4} />
      </Drawer>
    );
  }
}

export default Apply;
