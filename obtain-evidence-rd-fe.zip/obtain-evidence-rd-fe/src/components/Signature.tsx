import React, { useEffect, useRef, useState } from 'react';
import Konva from 'konva';
import { Vector2d } from 'konva/types/types';

interface SignatureProps {
  finish: boolean;
  containerStyle?: React.CSSProperties;
  onOk: (blob: Blob) => void;
}

const Signature: React.FC<SignatureProps> = props => {
  const { finish, containerStyle, onOk } = props;

  const [containerId] = useState(`signature_${new Date().getTime()}`);
  const refCanvas = useRef<HTMLCanvasElement>();

  useEffect(() => {
    refCanvas.current?.toBlob(blob => onOk(blob as Blob));
  }, [finish]);

  useEffect(() => {
    // @NOTE user setTimeout to fix width get 0
    setTimeout(() => {
      const { width, height } = document
        .getElementById(containerId)
        ?.getBoundingClientRect() as DOMRect;

      const stage = new Konva.Stage({
        container: containerId,
        width,
        height,
      });
      const layer = new Konva.Layer();
      stage.add(layer);
      const canvas = document.createElement('canvas');
      canvas.width = stage.width();
      canvas.height = stage.height();
      refCanvas.current = canvas;
      const image = new Konva.Image({
        image: canvas,
        x: 0,
        y: 0,
      });
      layer.add(image);
      stage.draw();

      const context = canvas.getContext('2d') as CanvasRenderingContext2D;
      context.strokeStyle = '#000';
      context.lineJoin = 'round';
      context.lineWidth = 5;

      let isPaint = false;
      let lastPointerPosition: Vector2d | null;
      let mode = 'brush';
      image.on('mousedown touchstart', function() {
        isPaint = true;
        lastPointerPosition = stage.getPointerPosition();
      });

      stage.on('mouseup touchend', function() {
        isPaint = false;
      });

      stage.on('mousemove touchmove', function() {
        if (!isPaint) {
          return;
        }

        if (mode === 'brush') {
          context.globalCompositeOperation = 'source-over';
        }
        if (mode === 'eraser') {
          context.globalCompositeOperation = 'destination-out';
        }
        context.beginPath();

        var localPos = {
          x: (lastPointerPosition as Vector2d).x - image.x(),
          y: (lastPointerPosition as Vector2d).y - image.y(),
        };
        context.moveTo(localPos.x, localPos.y);
        var pos = stage.getPointerPosition() as Vector2d;
        localPos = {
          x: pos.x - image.x(),
          y: pos.y - image.y(),
        };
        context.lineTo(localPos.x, localPos.y);
        context.closePath();
        context.stroke();

        lastPointerPosition = pos;
        layer.batchDraw();
      });
    }, 0);
  }, []);

  return (
    <div
      id={containerId}
      style={{
        height: '100%',
        width: '100%',
        minWidth: 420,
        minHeight: 210,
        ...containerStyle,
      }}
    />
  );
};

export default Signature;
