import React from 'react';
import { range } from 'lodash-es';
import moment from 'moment';
import styles from './index.less';

const textMap = {
  1: '一',
  2: '二',
  3: '三',
  4: '四',
  5: '五',
  6: '六',
  0: '日',
};
const DaySelector = ({ value, onChange, className, style }) => {
  const offsetNumbers = range(0, 14);
  return (
    <div className={`${styles.container} ${className || ''}`} style={style}>
      {offsetNumbers.map(offsetNumber => {
        const now = moment();
        const day = now.add(offsetNumber, 'days');
        let weekDayText = textMap[day.weekday()];
        if (offsetNumber === 0) {
          weekDayText = '今天';
        }
        if (offsetNumber === 1) {
          weekDayText = '明天';
        }
        const formatDate = day.format('YYYY-MM-DD');
        return (
          <div className={styles.itemWrap}>
            <div className={styles.item}>{weekDayText}</div>
            <div
              className={`${styles.item} ${
                value === formatDate ? styles.itemActive : ''
              }`}
              style={{ cursor: 'pointer' }}
              onClick={() => {
                onChange(formatDate);
              }}
            >
              {day.date()}
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default DaySelector;
