import React from 'react';
import { RouteComponentProps } from 'react-router';
import styles from './detail.less';
import { Button, Modal, Form, Select, Radio, Input } from 'antd';
import moment from 'moment';
import { Media } from '@/common/media';

type IProps = RouteComponentProps;
type IState = {
  modal: boolean;
};
/**案卷管理，详情 */
export default class AnguanguanliDetail extends React.PureComponent<
  IProps,
  IState
> {
  constructor(props: IProps) {
    super(props);
    this.state = {
      modal: false,
    };
  }

  private closeModal = () => {
    this.setState({ modal: false });
  };

  private showModal = () => {
    this.setState({ modal: true });
  };

  private renderModal() {
    const { modal } = this.state;
    return (
      <Modal
        wrapClassName={styles.modal}
        visible={modal}
        title="并案申请"
        okText="确认"
        cancelText="取消"
        onCancel={this.closeModal}
        onOk={this.closeModal}
      >
        <Form>
          <Form.Item label="案事件名称">
            <Select placeholder="请选择我的案件">
              <Select.Option value="1">案件一</Select.Option>
              <Select.Option value="2">案件一</Select.Option>
              <Select.Option value="3">案件一</Select.Option>
              <Select.Option value="4">案件一</Select.Option>
            </Select>
          </Form.Item>
          <Form.Item label="申请理由">
            <Input.TextArea placeholder="请输入申请调阅理由" />
          </Form.Item>
          <Form.Item label="申请时间">
            {moment().format('YYYY-MM-DD hh:mm')}
          </Form.Item>
          <Form.Item label="申请笔录类型">
            <Radio.Group>
              <Radio value="1">复印件</Radio>
              <Radio value="2">原件</Radio>
            </Radio.Group>
          </Form.Item>
          <Form.Item label="被询问人">
            <Select placeholder="请选择被询问人">
              <Select.Option value="1">张三</Select.Option>
              <Select.Option value="2">李四</Select.Option>
              <Select.Option value="3">王五</Select.Option>
            </Select>
            {/* <img src="/chenxiao/sig1.png" /> */}
          </Form.Item>
          <Form.Item label="审批人">赵六</Form.Item>
        </Form>
      </Modal>
    );
  }

  render() {
    const showMask = this.props.location?.query?.novideo == 1;
    return (
      <div className={styles.detail}>
        <div className={styles.content}>
          {showMask ? (
            <Button
              className={styles.btn}
              type="primary"
              size="middle"
              onClick={this.showModal}
            >
              并案申请
            </Button>
          ) : null}
          {this.renderModal()}
          {showMask ? <div className={styles.mask} /> : null}
          <div className={styles.record}>
            <img src="/chenxiao/record.png" width="100%" />
          </div>
          <div className={styles.videos}>
            <img src="/chenxiao/signa.jpg" width="100%" />
            <br />
            <br />
            <Media className={styles.video} src="/chenxiao/signature.mp4" />
            <br />
            <Media className={styles.video} src="/chenxiao/demo.mp4" />
            <br />
            <br />
            <img src="/chenxiao/block.jpg" width="100%" />
          </div>
        </div>
      </div>
    );
  }
}
