import React from 'react';
import { debounce, omit } from 'lodash-es';
import { CaseQueryParams, CaseType } from 'umi';
import { SEARCH_FORM_CHANGE_DEBOUNCE } from '@/common/constants';

import { SearchOutlined } from '@ant-design/icons';
import { Form, Input, Cascader, DatePicker, Button } from 'antd';
const { RangePicker } = DatePicker;

interface SearchFormProps {
  caseTypes?: CaseType[];
  simple?: boolean;
  onChange: (changedValues: Partial<CaseQueryParams>) => void;
  onAdd?: () => void;
}

const SearchForm: React.FC<SearchFormProps> = props => {
  const { caseTypes, simple, onChange, onAdd } = props;
  const [form] = Form.useForm();

  const valuesChange = debounce((_, values: Partial<CaseQueryParams>) => {
    const { createDate, types } = values;
    if (createDate) {
      values.startDate = createDate[0].format('YYYY-MM-DD');
      values.endDate = createDate[1].format('YYYY-MM-DD');
    }
    if (types) {
      values.subType = types[1];
    }
    const changedValues = omit(values, ['createDate', 'types'] as Array<
      keyof CaseQueryParams
    >);
    onChange(changedValues);
  }, SEARCH_FORM_CHANGE_DEBOUNCE);

  const resetFields = () => {
    form.resetFields();
    valuesChange(null, {});
  };

  return (
    <Form
      form={form}
      layout="inline"
      className="g-form-search"
      onValuesChange={valuesChange}
    >
      <Form.Item name="keyword">
        <Input
          className="g-input-keyword"
          suffix={<SearchOutlined />}
          placeholder="请输入关键词，如案事件名称"
        />
      </Form.Item>
      {!simple && (
        <>
          <Form.Item name="types">
            <Cascader
              placeholder="请选择案件类型"
              options={caseTypes}
              fieldNames={{ label: 'name', value: 'id' }}
            />
          </Form.Item>
          <Form.Item name="createDate">
            <RangePicker />
          </Form.Item>
          <Form.Item>
            <Button onClick={resetFields}>重置</Button>
          </Form.Item>
          <Form.Item>
            <Button type="primary" onClick={onAdd}>
              新增案事件档案
            </Button>
          </Form.Item>
        </>
      )}
    </Form>
  );
};

export default SearchForm;
