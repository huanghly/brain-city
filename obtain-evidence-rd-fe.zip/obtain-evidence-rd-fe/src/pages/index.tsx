import React from 'react';
import { Redirect } from 'umi';

const PageIndex: React.FC = () => {
  return <Redirect to="/inquiry/reservation" />;
};

export default PageIndex;
