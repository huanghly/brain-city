import React from 'react';

import { createFromIconfontCN } from '@ant-design/icons';

const scriptUrl = document
  .getElementById('script_iconfont')
  ?.getAttribute('src') as string;

const IconFont = createFromIconfontCN({
  scriptUrl,
});

export default IconFont;
