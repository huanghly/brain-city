import { generateAPI, setAxiosOptions } from 'cool-utils';
import api from './api';
import { AxiosRequestConfig } from 'axios';

export default generateAPI(api);

setAxiosOptions({
  notLoginErrorCode: 1005,
  loginPage: `http://ums.citybrain.com/login?redirectUrl=${window.location}`,
} as AxiosRequestConfig['options']);
