export const setTheme = (themeKey: 'dark') => {
  let styleLink = document.getElementById('theme-style');

  const src = `/theme/${themeKey}.css`;

  if (!styleLink) {
    styleLink = document.createElement('link');
    styleLink.setAttribute('type', 'text/css');
    styleLink.setAttribute('rel', 'stylesheet');
    styleLink.setAttribute('id', 'theme-style');
    styleLink.setAttribute('href', src);
    document.body.append(styleLink);
  } else {
    styleLink.setAttribute('href', src);
  }
  document.body.className = `body-wrap-theme-${themeKey}`;
};

export const resetTheme = () => {
  const styleLink = document.getElementById('theme-style');
  if (styleLink) {
    styleLink.remove();
  }
};
