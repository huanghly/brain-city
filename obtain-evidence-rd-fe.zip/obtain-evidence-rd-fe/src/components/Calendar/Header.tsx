import React from 'react';

import { Radio, Row, Col } from 'antd';

import { CalendarTypes } from './constants';

import styles from './Calendar.less';

interface HeaderProps {
  type: CalendarTypes;
  renderHeader?: () => React.ReactNode;
  onChange: (type: CalendarTypes) => void;
}

const Header: React.FC<HeaderProps> = props => {
  const { type, renderHeader, onChange } = props;
  return (
    <Row
      align="middle"
      justify="space-between"
      className={styles.calendarHeader}
    >
      <Col>{renderHeader && renderHeader()}</Col>
      <Col>
        <Radio.Group
          size="small"
          value={type}
          onChange={e => {
            onChange(e.target.value);
          }}
        >
          <Radio.Button className={styles.label} value={CalendarTypes.Day}>
            日
          </Radio.Button>
          <Radio.Button className={styles.label} value={CalendarTypes.Week}>
            周
          </Radio.Button>
        </Radio.Group>
      </Col>
    </Row>
  );
};

export default Header;
