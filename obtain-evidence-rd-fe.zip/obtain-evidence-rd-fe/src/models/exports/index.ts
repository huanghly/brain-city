export * from './case';
export * from './download';
export * from './inquiry';
export * from './evidence';
export * from './oss';
export * from './reservation';
export * from './user';
export * from './workflow';
export * from './analysis';

import {
  Loading,
  ModelNamespaces,

  // ModelState
  UserModelState,
  ReservationModelState,
  InquiryModelState,
  CaseModelState,
  EvidenceModelState,
  WorkflowModelState,
  AnalysisModelState,

  // Model Type
  UserModelType,
  ReservationModelType,
  InquiryModelType,
  CaseModelType,
  EvidenceModelType,
  WorkflowModelType,
  AnalysisModelType,
  DownloadModelType,
  OSSModelType,
} from 'umi';

export interface RootModelState {
  [ModelNamespaces.User]: UserModelState;
  [ModelNamespaces.Reservation]: ReservationModelState;
  [ModelNamespaces.Inquiry]: InquiryModelState;
  [ModelNamespaces.Case]: CaseModelState;
  [ModelNamespaces.Analysis]: AnalysisModelState;
  [ModelNamespaces.Evidence]: EvidenceModelState;
  [ModelNamespaces.Workflow]: WorkflowModelState;
  [ModelNamespaces.Analysis]: AnalysisModelState;
  [ModelNamespaces.Workflow]: WorkflowModelState;
  loading: Loading;
}

export type ModelDispatchType = {
  [ModelNamespaces.User]: keyof UserModelType['effects'];
  [ModelNamespaces.Reservation]: keyof ReservationModelType['effects'];
  [ModelNamespaces.Inquiry]: keyof InquiryModelType['effects'];
  [ModelNamespaces.Case]: keyof CaseModelType['effects'];
  [ModelNamespaces.Evidence]: keyof EvidenceModelType['effects'];
  [ModelNamespaces.Download]: keyof DownloadModelType['effects'];
  [ModelNamespaces.OSS]: keyof OSSModelType['effects'];
  [ModelNamespaces.Workflow]: keyof WorkflowModelType['effects'];
  [ModelNamespaces.Analysis]: keyof AnalysisModelType['effects'];
};
