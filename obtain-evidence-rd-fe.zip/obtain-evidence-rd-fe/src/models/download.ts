import { DownloadModelType, InquiryDownloadResponse } from 'umi';
import { delay } from 'redux-saga';
import { ModelNamespaces, RecordDownloadStatus } from './constants';
import api from '@/services';

import { message } from 'antd';
import { handleError } from '@/common/util';

const DownloadModel: DownloadModelType = {
  namespace: ModelNamespaces.Download,
  effects: {
    *downloadInquiryRecord({ payload }, { call, put }) {
      console.log(arguments);
      const { inquiryId, polling } = payload;
      try {
        const response: InquiryDownloadResponse = yield call(
          api.downloadCaseInquiryRecord,
          {
            inquiryId,
          },
        );
        if (response.state === RecordDownloadStatus.Done) {
          const href = document.createElement('a');
          href.setAttribute('target', '_blank');
          href.setAttribute('href', response.url);
          href.click();
        } else {
          if (
            response.state === RecordDownloadStatus.Fail ||
            response.state === RecordDownloadStatus.NotFound
          ) {
            message.error(response.msg);
          } else if (!polling) {
            message.info(response.msg);
          }
          yield call(delay, 10000);
          yield put({
            type: 'downloadInquiryRecord',
            payload: { ...payload, polling: true },
          });
        }
      } catch (err) {
        handleError(err);
      }
    },
    *exportInquiryRecord({ payload }, { call, put }) {
      console.log(arguments);
      const { inquiryId, polling } = payload;
      try {
        const response: InquiryDownloadResponse = yield call(
          api.exportCaseInquiryRecord,
          {
            inquiryId,
          },
        );
        if (response.state === RecordDownloadStatus.Done) {
          const href = document.createElement('a');
          href.setAttribute('target', '_blank');
          href.setAttribute('href', response.url);
          href.click();
        } else {
          if (
            response.state === RecordDownloadStatus.Fail ||
            response.state === RecordDownloadStatus.NotFound
          ) {
            message.error(response.msg);
          } else if (!polling) {
            message.info(response.msg);
          }
          yield call(delay, 10000);
          yield put({
            type: 'exportInquiryRecord',
            payload: { ...payload, polling: true },
          });
        }
      } catch (err) {
        handleError(err);
      }
    },
  },
};

export default DownloadModel;
