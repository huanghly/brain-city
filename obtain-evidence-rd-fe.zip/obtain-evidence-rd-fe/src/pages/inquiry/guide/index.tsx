import React, { Component } from 'react';
import Councilor from './councilor';
import Analysis from './analysis';
import { Tabs } from 'antd';
const { TabPane } = Tabs;
import styles from './index.less';

class Guide extends Component {
  render() {
    return (
      <div className={styles.page}>
        <Tabs defaultActiveKey="analysis">
          <TabPane tab="综合分析" key="analysis">
            <Analysis />
          </TabPane>
          {/* <TabPane tab="指挥督导" key="supervisor">
            <Councilor />
          </TabPane> */}
        </Tabs>
      </div>
    );
  }
}

export default Guide;
