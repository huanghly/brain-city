import React from 'react';
import PropTypes from 'prop-types';

const InterrogationManagement = props => {
  return <div>interrogationManagement</div>;
};

InterrogationManagement.propTypes = {};

export default InterrogationManagement;
