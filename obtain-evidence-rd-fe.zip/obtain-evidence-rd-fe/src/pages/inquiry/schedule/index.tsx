import React from 'react';
import {
  connect,
  ConnectProps,
  RootModelState,
  ReservationStatus,
  ReservationSimple,
  ReservationDisplay,
  InquirerRoles,
  ModelNamespaces,
  Dispatch,
} from 'umi';
import { RouteComponentWithParams } from '@/common/route';
import { getDispatchType } from '@/common/util';

import { Tabs, Button } from 'antd';
const { TabPane } = Tabs;
import { TabPage } from '@/components/ContentPage';
import ReservationCardList from '@/components/ReservationCardList';
import InquiryGatewayModal from './components/InquiryGatewayModal';

type InquiryScheduleProps = ConnectProps &
  RouteComponentWithParams &
  InquiryScheduleStateProps &
  InquiryScheduleDispatchProps;

interface InquiryScheduleStates {
  modalVisible: boolean;
  editingReservation?: ReservationDisplay;
}

class InquirySchedule extends React.PureComponent<
  InquiryScheduleProps,
  InquiryScheduleStates
> {
  state: Readonly<InquiryScheduleStates> = {
    modalVisible: false,
  };

  private enterInquiry = (reservation: ReservationDisplay) => {
    const { currentUser } = this.props;
    const { inquiryId, inquirerId, recorderId } = reservation;
    if (
      currentUser?.userId !== inquirerId &&
      currentUser?.userId !== recorderId
    ) {
      this.setState({ modalVisible: true, editingReservation: reservation });
    } else {
      this.initMeeting(inquiryId);
    }
  };

  private initMeeting = (inquiryId: string) => {
    this.props.enterInquiry(inquiryId, () => {
      this.props.history.push(`/inquiry/live/${inquiryId}`);
    });
  };

  private renderFooter = (
    _: string,
    status: ReservationStatus,
    reservation: ReservationSimple,
  ) => {
    let canEnter = false;

    const { currentUser } = this.props;
    const { inquirerId, recorderId } = reservation as ReservationDisplay;

    if (status !== ReservationStatus.Finished) {
      // 在询问人列表内
      if (
        inquirerId === currentUser?.userId ||
        recorderId === currentUser?.userId
      ) {
        canEnter = true;
      } else {
        // 不在询问人列表内，可以走变更流程，条件是询问人或者被询问人尚未进入
        canEnter = !(
          status & ReservationStatus.InquirerEntered &&
          status & ReservationStatus.RecorderEntered
        );
      }
    }

    return (
      canEnter && (
        <Button
          size="small"
          onClick={() => this.enterInquiry(reservation as ReservationDisplay)}
        >
          进入
        </Button>
      )
    );
  };

  private changeInquiry = (reservationId: string, roles: InquirerRoles[]) => {
    this.initMeeting(reservationId, roles);
  };

  private closeModal = () => {
    this.setState({ modalVisible: false });
  };

  render() {
    const { reservations, getWeekPaginationReservations } = this.props;
    const { today, week } = reservations;
    const { modalVisible, editingReservation } = this.state;

    return (
      <TabPage title="专案组询问日程">
        <Tabs defaultActiveKey="today">
          <TabPane tab="今天" key="today">
            <ReservationCardList
              dataSource={today}
              renderFooter={this.renderFooter}
            />
          </TabPane>
          <TabPane tab="本周" key="week">
            <ReservationCardList
              pagination={week}
              onPaginationChange={getWeekPaginationReservations}
            />
          </TabPane>
        </Tabs>
        {editingReservation && (
          <InquiryGatewayModal
            visible={modalVisible}
            reservation={editingReservation}
            onOk={this.changeInquiry}
            onCancel={this.closeModal}
          />
        )}
      </TabPage>
    );
  }
}

const mapStateToProps = (state: RootModelState) => ({
  reservations: state.inquiry.reservations,
  currentUser: state.user.currentUser,
});

const mapDispatchToProps = (dispatch: Dispatch) => ({
  enterInquiry: (inquiryId: string, callback: () => void) =>
    dispatch({
      type: getDispatchType(ModelNamespaces.Inquiry, 'enterInquiry'),
      payload: { inquiryId },
      callback,
    }),
  getWeekPaginationReservations: (current: number, pageSize?: number) =>
    dispatch({
      type: getDispatchType(
        ModelNamespaces.Inquiry,
        'getWeekPaginationReservations',
      ),
      payload: {
        current,
        pageSize,
      },
    }),
});

type InquiryScheduleStateProps = ReturnType<typeof mapStateToProps>;
type InquiryScheduleDispatchProps = ReturnType<typeof mapDispatchToProps>;

export default connect(mapStateToProps, mapDispatchToProps)(InquirySchedule);
