import { RouteComponentProps } from 'react-router';

export interface RouteParams {
  caseId: string;
  caseQueryType: string;
  inquiryId: string;
}

export type RouteComponentWithParams = RouteComponentProps<RouteParams>;
