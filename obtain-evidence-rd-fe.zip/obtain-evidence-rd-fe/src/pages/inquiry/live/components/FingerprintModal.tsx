import React from 'react';

import { Modal, Row, Col } from 'antd';
import { LoadingOutlined } from '@ant-design/icons';

interface FingerprintModalProps {
  visible: boolean;
  origin: string;
  converted: string;
  onOk: () => void;
  onCancel: () => void;
}

const FingerprintModal: React.FC<FingerprintModalProps> = props => {
  const { visible, origin, converted, onOk, onCancel } = props;

  return (
    <Modal
      visible={visible}
      title="指纹识别"
      confirmLoading={!converted}
      onOk={onOk}
      onCancel={onCancel}
    >
      <Row>
        <Col span={12}>
          <Row align="middle" justify="center">
            <img src={origin} className="g-fit-contain" />
          </Row>
        </Col>
        <Col span={12}>
          <Row align="middle" justify="center">
            {converted ? (
              <img src={converted} className="g-fit-contain" />
            ) : (
              <LoadingOutlined spin />
            )}
          </Row>
        </Col>
      </Row>
    </Modal>
  );
};

export default FingerprintModal;
