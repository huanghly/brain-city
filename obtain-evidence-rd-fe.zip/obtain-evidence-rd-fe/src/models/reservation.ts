import moment, { Moment } from 'moment';
import { set } from 'lodash-es';
import { downloadFile } from 'cool-utils';
import {
  ReservationModelType,
  RootModelState,
  RoomInfo,
  RoomSchedule,
  ReservationSubmit,
} from 'umi';
import { ModelNamespaces } from './constants';
import { CLOUD_SYSTEM_TYPE } from '@/common/constants';
import api from '@/services';
import {
  getDefaultPaginationModel,
  parseResponsePagination,
  parseRequestPagination,
  handleError,
} from '@/common/util';
import { message } from 'antd';

const ReservationModel: ReservationModelType = {
  namespace: ModelNamespaces.Reservation,
  state: {
    locations: [],
    rooms: [],
    roomQueryParams: { date: moment().format('YYYY-MM-DD') },
    myReservations: getDefaultPaginationModel(12),
    monthReservationDates: [],
    selectedDate: moment(),
    reservations: {
      day: [],
      week: [],
    },
  },
  effects: {
    *getMyPaginationReservations({ payload }, { call, select, put }) {
      const { pageSize, current } = yield select(
        (state: RootModelState) => state.reservation.myReservations,
      );
      const requestParams = parseRequestPagination({
        pageSize,
        current,
        ...payload?.params,
      });
      try {
        const asyncData = yield call(
          api.getMyPaginationReservations,
          requestParams,
        );
        const result = parseResponsePagination(asyncData);
        yield put({
          type: 'save',
          payload: { value: result, path: ['myReservations'] },
        });
      } catch (err) {
        handleError(err);
      }
    },
    *getRooms({ payload }, { select, call, put }) {
      const { params } = payload;
      if (!params.date) {
        params.date = yield select(
          (state: RootModelState) => state.reservation.roomQueryParams.date,
        );
      }
      try {
        const rooms: RoomInfo[] = yield call(api.getRooms, params);
        rooms.forEach(room => {
          room.reservedPeriods = room.schedules.reduce<{
            [key: number]: RoomSchedule;
          }>((accObj, schedule) => {
            schedule.periods.sort((p1, p2) => p1 - p2);
            schedule.periods.reduce((acc, currentPeriod) => {
              acc[currentPeriod] = schedule;
              return acc;
            }, accObj);
            return accObj;
          }, {});
        });
        yield put({
          type: 'save',
          payload: { value: rooms, path: ['rooms'] },
        });
        yield put({
          type: 'save',
          payload: { value: params, path: ['roomQueryParams'] },
        });
      } catch (err) {
        console.log(err);
      }
    },
    *getLocations(_, { call, put }) {
      try {
        const asyncData = yield call(api.getLocations);
        yield put({
          type: 'save',
          payload: { value: asyncData, path: ['locations'] },
        });
      } catch (err) {
        handleError(err);
      }
    },

    *downloadRecordTemplate(_, { call }) {
      try {
        const { ossFileName } = yield call(api.getRecordTemplate);
        if (!ossFileName) {
          message.warning('暂无笔录模板可供下载！');
          return;
        }
        downloadFile(ossFileName);
        message.info('笔录模板开始下载！');
      } catch (err) {
        handleError(err);
      }
    },

    *addReservation({ payload, callback }, { call, select, put }) {
      const reservation: ReservationSubmit = payload.reservation;
      const formData = new FormData();
      Object.entries(reservation).forEach(([key, value]) => {
        if (!value) {
          return;
        }
        formData.append(
          key,
          Array.isArray(value) ? JSON.stringify(value) : value,
        );
      });
      formData.append('inquiryType', CLOUD_SYSTEM_TYPE.toString());
      try {
        const asyncData = yield call(api.addReservation, formData);
        if (asyncData) {
          callback?.();
        }
      } catch (err) {
        handleError(err);
      }
    },

    *releaseRoom({ payload, callback }, { call, put }) {
      const { reservationId } = payload;
      try {
        yield call(api.removeReservation, { id: reservationId });
        yield put({ type: 'getMyPaginationReservations' });
        callback && callback();
      } catch (err) {
        handleError(err);
      }
    },

    *getReservationCalendar({ payload }, { select, call, put }) {
      let yearMonth = payload?.yearMonth;
      if (!yearMonth) {
        const selectedDate: Moment = yield select(
          (state: RootModelState) => state.reservation.selectedDate,
        );
        yearMonth = selectedDate.format('YYYY-MM');
      }
      try {
        const dates: string[] = yield call(api.getReservationCalendar, {
          yearMonth,
        });
        const momentDates = (dates || []).map(date => moment(date));
        yield put({
          type: 'save',
          payload: {
            value: momentDates,
            path: ['monthReservationDates'],
          },
        });
      } catch (err) {
        handleError(err);
      }
    },
    *setSelectedDate({ payload }, { select, call, put }) {
      const selectedDate: Moment = yield select(
        (state: RootModelState) => state.reservation.selectedDate,
      );
      const { date } = payload;
      yield put({
        type: 'save',
        payload: { value: date, path: ['selectedDate'] },
      });
      yield put({ type: 'getMyDayReservations' });
      if (!selectedDate.isSame(date, 'week')) {
        yield put({ type: 'getMyWeekReservations' });
      }

      if (!selectedDate.isSame(date, 'month')) {
        yield put({
          type: 'getReservationCalendar',
          payload: { yearMonth: date.format('YYYY-MM') },
        });
      }
    },
    *getMyDayReservations(_, { select, call, put }) {
      const selectedDate: Moment = yield select(
        (state: RootModelState) => state.reservation.selectedDate,
      );
      try {
        const result = yield call(api.getMyDayReservations, {
          date: selectedDate.format('YYYY-MM-DD'),
        });
        yield put({
          type: 'save',
          payload: { value: result, path: ['reservations', 'day'] },
        });
      } catch (err) {
        handleError(err);
      }
    },
    *getMyWeekReservations(_, { select, call, put }) {
      const selectedDate: Moment = yield select(
        (state: RootModelState) => state.reservation.selectedDate,
      );
      const startDate = selectedDate.startOf('week').format('YYYY-MM-DD');
      const endDate = selectedDate.endOf('week').format('YYYY-MM-DD');
      try {
        const result = yield call(api.getMyWeekReservations, {
          startDate,
          endDate,
        });
        yield put({
          type: 'save',
          payload: { value: result, path: ['reservations', 'week'] },
        });
      } catch (err) {
        handleError(err);
      }
    },
    *initializePageCalendar(_, { all, put }) {
      yield all([
        put({ type: 'getMyPaginationReservations' }),
        put({ type: 'getReservationCalendar' }),
        put({ type: 'getMyDayReservations' }),
        put({ type: 'getMyWeekReservations' }),
      ]);
    },
  },
  reducers: {
    save(state, action) {
      const { value, path } = action.payload;
      set(state, path, value);
    },
  },
  subscriptions: {
    setup({ dispatch, history }) {
      return history.listen(({ pathname }) => {
        switch (pathname) {
          case '/inquiry/reservation':
            dispatch({ type: 'initializePageCalendar' });
            break;
        }
      });
    },
  },
};

export default ReservationModel;
