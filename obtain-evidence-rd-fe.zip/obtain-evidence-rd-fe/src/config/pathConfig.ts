/* 
  路径配置：
  一个对象，path表示路径，role表示路径的权限，如果没有role则该路径没有权限控制，可自由访问
*/
import { forEach } from 'cool-utils';

import { PathConfigItem } from './types';

export const pathConfigWithRole = {
  reservation: { path: '/inquiry/reservation' },
  createReservation: { path: '/inquiry/reservation' },

  inquirySchedule: { path: '/inquiry/schedule' },

  case: { path: '/case' },
  caseAll: { path: '/case/all' },
  caseMy: { path: '/case/my' },
  caseSubscription: { path: '/case/subscription' },
  caseAudit: { path: '/case/audit' },
  caseMyApplication: { path: '/case/application' },

  guide: { path: '/inquiry/guide' },
  guideAnalysis: { path: '/inquiry/guide/analysis' },
  guidesupervision: { path: '/inquiry/guide/supervision' },

  userManagement: { path: '/userManagement' },
  redirectPath: { path: process.env.REDIRECT_URL || '/' },
  defaultPath: { path: '/case' },
};

const pathConfigObj: { [key: string]: string } = {};

forEach(pathConfigWithRole, function(value: PathConfigItem, key: string) {
  pathConfigObj[key] = value.path;
});

export default pathConfigObj;
