import React from 'react';

import { Link, useLocation, useDispatch, ModelNamespaces } from 'umi';
import { Layout, Dropdown, Menu, Button } from 'antd';
const { Header } = Layout;
import { CaretDownOutlined } from '@ant-design/icons';

import { LayoutConfigItem } from '@/config/types';

import logo from '@/assets/imgs/logo.png';
import defaultAvatar from '@/assets/imgs/default_avatar.png';

import styles from './index.less';

interface PortalHeaderProps {
  navgations: LayoutConfigItem[];
  userName?: string;
}

const PortalHeader: React.FC<PortalHeaderProps> = props => {
  const dispatch = useDispatch();
  const location = useLocation();
  const { navgations, userName } = props;

  const selectedKeys = navgations
    .filter(({ pathConfig }) => location.pathname.includes(pathConfig.path))
    .map(({ pathConfig }) => pathConfig.path);

  const logout = () => {
    dispatch({ type: `${ModelNamespaces.User}/logout` });
  };

  return (
    <Header className={styles.header}>
      <div className={styles.title}>
        <div className={styles.logo}>
          <img src={logo} />
        </div>
        <h1>云上取证</h1>
      </div>
      <Menu
        selectedKeys={selectedKeys}
        className={styles.nav}
        theme="dark"
        mode="horizontal"
      >
        {navgations.map(nav => (
          <Menu.Item key={nav.pathConfig.path} disabled={nav.disabled}>
            <Link to={nav.pathConfig.path}>{nav.name}</Link>
          </Menu.Item>
        ))}
      </Menu>
      <Dropdown
        trigger={['click']}
        overlay={
          <Menu theme="dark">
            <Menu.Item>
              <div onClick={logout}>退出登录</div>
            </Menu.Item>
          </Menu>
        }
      >
        <span className={styles.avatar}>
          <img src={defaultAvatar} />
          <label>办案人员：{userName}</label>
          <CaretDownOutlined />
        </span>
      </Dropdown>
    </Header>
  );
};

export default PortalHeader;
