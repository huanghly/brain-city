import React, { useMemo } from 'react';
import moment from 'moment';
import classnames from 'classnames';

import styles from './index.less';

interface DatePickerBarProps {
  forward?: number;
  value: string;
  onSelect: (date: string) => void;
}

type BarItem = {
  date: string;
  title: string;
  dayNumber: number;
};

const DatePickerBar: React.FC<DatePickerBarProps> = props => {
  const { forward, value, onSelect } = props;

  const barItems = useMemo<BarItem[]>(() => {
    const items = [...Array(forward).keys()].map(idx => {
      const date = moment().add(idx, 'day');
      return {
        date: date.format('YYYY-MM-DD'),
        title: date.format('dd'),
        dayNumber: +date.format('D'),
      };
    });
    items[0].title = '今天';
    items[1].title = '明天';
    return items;
  }, [forward]);

  return (
    <div className={styles.bar}>
      {barItems.map(item => (
        <DatePickerBarItem
          key={item.date}
          value={item}
          selected={value === item.date}
          onSelect={onSelect}
        />
      ))}
    </div>
  );
};

DatePickerBar.defaultProps = {
  forward: 8,
};

export default DatePickerBar;

interface DatePickerBarItemProps {
  value: BarItem;
  selected: boolean;
  onSelect: (date: string) => void;
}

const DatePickerBarItem: React.FC<DatePickerBarItemProps> = props => {
  const { value, selected, onSelect } = props;
  const { title, dayNumber, date } = value;
  const select = () => {
    onSelect(date);
  };

  const cls = classnames({
    [styles.selected]: selected,
  });

  return (
    <div className={styles.item} onClick={select}>
      <div>{title}</div>
      <div className={cls}>{dayNumber}</div>
    </div>
  );
};
