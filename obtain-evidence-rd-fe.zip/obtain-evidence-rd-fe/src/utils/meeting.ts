// refer: https://yuque.antfin-inc.com/docs/share/f732c870-75e6-4ec8-a9e0-c2d35041fe1d?#nPYDN

export const ROOM_SERVER_URL_RELEASE = 'wss://artvcroom.alipay.com/ws';
// export const ROOM_SERVER_URL_RELEASE = 'wss://artvcroom.test.alipay.net/ws';
export const NETWORK_CHECK_TIMEOUT = 10000;

export type MeetingConfigParams = {
  uid: string;
  biz_name: string;
  sub_biz: string;
  room_server_url: string;
};

export type MeetingRoomConfigParams = {
  auto_publish_subscribe: 1 | 2 | 3 | 4;
  need_volume_analyser?: boolean;
  media_type: 1 | 2 | 3;
  publish_device: 1 | 2 | 3 | 4;
  initPublish: Array<{
    publish_video_id: string;
    publish_stream_id: string;
    publish_tag: string;
  }>;
  initSubscribe: Array<{
    subscribe_video_id: string;
    subscribe_audio_id: string;
    feedId_id: string;
    subscribe_streamId_id: string;
  }>;
  bizName: string;
  subBiz: string;
  uid: string;
  signature?: string;
};

export type MeetingRoomInfo = {
  room_id: string;
  rtoken: string;
};

export type RecordParams = {
  /**
   * 0：双人模式，1：画中画模式（双人），2：多人录制模式
   *
   * @type {(0 | 1 | 2)}
   */
  layoutMode?: 0 | 1 | 2;

  tagFilter?: 'VIDEO_SOURCE_CAMERA' | 'VIDEO_SOURCE_SCREEN';
};

export type AsrParams = {
  sid: string;
  idleTime?: number;
  procType: 8;
  tag: string;
};

export type AsrMessage = {
  name: 'asr' | 'nlu';
  value: string;
  type: 0 | 1;
  sentence_id: number;
  sentence_duration: number;
  msg_id: number;
  timestamp: number;
};

export type RemoteRecordParams = {};

declare global {
  export class McuController {
    OnGetSign(bizName: string, subBiz: string, uid: string): string;
    Connect(params: MeetingConfigParams): void;
    OnConnectOK(): void;
    OnConnectFailed(err_code: string, err_msg: string): void;

    InitRoomConfig(params: MeetingRoomConfigParams): void;
    OnInitRoomConfigOK(): void;
    OnInitRoomConfigFail(err_code: string, err_msg: string): void;

    CreateRoom(): void;
    OnCreateRoomSucc(room_id: string, rtoken: string): void;
    OnCreateRoomFailed(err_code: string, err_msg: string): void;

    /**
     *
     *
     * @param {string} room_id
     * @param {string} rtoken
     * @param {(0 | 1)} engine 0: alipay 1: aliyun
     * @memberof McuController
     */
    JoinRoom(room_id: string, rtoken: string, engine: 0 | 1): void;
    OnJoinRoomSucc(): void;
    OnJoinRoomFailed(err_code: string, err_msg: string): void;
    OnNewJoinerIn(participant: string): void;
    LeaveRoom(): void;
    OnLeaveRoom(): void;

    /**
     *
     *
     * @param {(0 | 1)} type 0 截取本地端 1 截取远端图像
     * @param {number} width 图像宽度
     * @param {number} height 图像高度
     * @param {number} sid 流id
     * @param {(1 | 2)} picture_type 1 png 2 jpeg/jpg
     * @memberof McuController
     */
    TakePicture(
      type: 0 | 1,
      width: number | undefined,
      height: number | undefined,
      sid: number,
      picture_type: 1 | 2,
    ): string;

    StartAsr(params: AsrParams): void;
    StopAsr(sid: string): void;

    OnStartAsrSuccess(sid: number, tag: string, session: string): void;
    OnStartAsrFailed(sid: number, tag: string, session: string): void;

    /**
     * 语音转文本回调
     *
     * @param {string} msg json 字符串
     * @param {string} sid 流 id
     * @param {string} tag
     * @param {(0 | 1)} status 0 未结束 1 回话结束
     * @param {string} sessionId
     * @memberof McuController
     */
    OnAsrMessage(
      msg: string,
      sid: string,
      tag: string,
      status: 0 | 1,
      sessionId: string,
    ): void;

    OnNewPublish(feed: {
      uid: string;
      feedId: string;
      tag: 'VIDEO_SOURCE_CAMERA' | 'VIDEO_SOURCE_SCREEN';
    }): void;
    OnUnPublish(feed: { uid: string; feedId: string }): void;

    StartRemoteRecord(filePath?: string): void;
    StartRemoteRecord(
      filePath: string,
      recordParams: RecordParams,
      recordThirdId?: string,
    ): void;

    OnStartRecordSucc(recordId: string, recordThirdId: string): void;
    OnStartRecordFailed(
      recordId: string,
      err_code: string,
      err_msg: string,
    ): void;
    StopRemoteRecord(recordId: string): void;
    OnStopRecordSucc(record_id: string): void;
    OnStopRecordFailed(
      record_id: string,
      err_code: string,
      err_msg: string,
    ): void;
    GetRecordInfo(recordId: string, roomId: string, mediaType: 0 | 1 | 2): void;
    OnRecordInfoSucc(recordInfo: {
      recordId: string;
      status: 0 | 1 | 2 | 3;
      fileType: 1 | 2 | 3;
      filePath: string;
    }): void;
    OnRecordInfoFailed(
      recordId: string,
      err_code: string,
      err_msg: string,
    ): void;

    LeaveRoom(): void;
    OnLeaveRoom(leaveType: string): void;
    OnParticipantLeaveRoom(uid: string, exitType: string): void;

    Disconnect(): void;
    OnConnectClose(): void;
  }
}
