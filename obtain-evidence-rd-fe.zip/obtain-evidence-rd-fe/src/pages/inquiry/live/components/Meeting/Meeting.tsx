import React from 'react';

import { MEETING_HTML_TAGS, DEFAULT_ROOM_CONFIG_PARAMS } from './constants';
import {
  AsrMessage,
  MeetingConfigParams,
  ROOM_SERVER_URL_RELEASE,
} from '@/utils/meeting';

import { message, Spin } from 'antd';

import styles from './Meeting.less';
import {
  InquiryRecordLine,
  InquiryRecordTypes,
  MeetingSdkRoomParams,
  LiveMeetingParams,
  RawInquiryRecordLine,
} from 'umi';

interface MeetingProps {
  params: LiveMeetingParams;
  floating?: boolean;
  screenshotSignal?: boolean;
  onCreate: (params: MeetingSdkRoomParams) => void;
  onStart: () => void;
  onScreenRecord: (recordId: string) => void;
  onAsr: (message: RawInquiryRecordLine) => void;
  onScreenshot: (base64: string) => void;
  onClose?: () => void;
}

interface MeetingStates extends Pick<MeetingProps, 'screenshotSignal'> {
  waiting: boolean;
  floatingStyle: React.CSSProperties;
  screenVideoFeedId?: string;
  hangup?: boolean;
}

const DEFAULT_FLOATING_WIDTH = 220;

class Meeting extends React.PureComponent<MeetingProps, MeetingStates> {
  private shouldReinitialize: boolean = false;
  private isMovingVideo: boolean = false;
  private lastScreenRecordId: string = '';

  state: Readonly<MeetingStates> = {
    waiting: true,
    floatingStyle: {},
  };

  private mcuController?: McuController;
  private sdkRoomParams: MeetingSdkRoomParams = {
    recordId: '',
    roomId: '',
    roomToken: '',
  };

  componentDidMount() {
    this.initMeeting();
  }

  static getDerivedStateFromProps: React.GetDerivedStateFromProps<
    MeetingProps,
    MeetingStates
  > = (nextProps, prevState) => {
    if (!nextProps.floating || prevState.waiting) {
      return { floatingStyle: {} };
    }
    const videoElem = document.getElementById(
      MEETING_HTML_TAGS.SUBSCRIBE_VIDEO_ID,
    )!;
    const {
      width: videoWidth,
      height: videoHeight,
    } = videoElem.getBoundingClientRect();

    const prevFloatingStyle = prevState.floatingStyle;
    return {
      floatingStyle: {
        position: 'fixed',
        zIndex: 99,
        width: DEFAULT_FLOATING_WIDTH,
        height: (DEFAULT_FLOATING_WIDTH * videoHeight) / videoWidth,
        right: prevFloatingStyle.right || 24,
        bottom: prevFloatingStyle.bottom || 96,
        cursor: 'move',
      },
    };
  };

  componentDidUpdate(prevProps: MeetingProps) {
    const { screenshotSignal, onScreenshot } = this.props;

    if (screenshotSignal !== prevProps.screenshotSignal) {
      const base64 = this.mcuController?.TakePicture(
        1,
        undefined,
        undefined,
        parseInt(
          document.getElementById(MEETING_HTML_TAGS.SUBSCRIBE_VIDEO_ID)?.name,
        ),
        1,
      );
      onScreenshot(base64 as string);
    }
  }

  private initMeeting = () => {
    this.mcuController = new McuController();

    this.mcuController.OnConnectOK = this.connected;
    this.mcuController.OnConnectFailed = (errCode: string, errMsg: string) => {
      message.error(
        `连接视频服务失败！请刷新页面后重试！${errCode}: ${errMsg}`,
      );
    };
    this.mcuController.OnConnectClose = this.onConnectClose;

    this.mcuController.OnInitRoomConfigOK = this.onInitRoomConfigOK;
    this.mcuController.OnInitRoomConfigFail = this.onInitRoomConfigFail;

    this.mcuController.OnCreateRoomSucc = this.createRoomSucc;
    this.mcuController.OnCreateRoomFailed = (
      errCode: string,
      errMsg: string,
    ) => {
      message.error(`创建房间失败！${errCode}: ${errMsg}`);
    };

    this.mcuController.OnJoinRoomSucc = this.joinRoomSucc;
    this.mcuController.OnJoinRoomFailed = this.joinRoomFailed;
    this.mcuController.OnNewJoinerIn = (participant: string) => {
      console.log('new joiner: ', participant);
      const { waiting } = this.state;
      if (!waiting) {
        return;
      }
      this.setState({ waiting: false });
      this.props.onStart();
      setTimeout(() => {
        this.startAsr();
      }, 5000);
    };

    this.mcuController.OnAsrMessage = this.onAsrMessage;
    this.mcuController.OnStartAsrSuccess = () => {
      message.info('开始进行语音识别！');
    };
    this.mcuController.OnStartAsrFailed = (sid, tag, session) => {
      message.error(`开始进行语音识别失败！${sid}, ${tag}, ${session}`);
    };

    this.mcuController.OnNewPublish = this.onNewPublish;
    this.mcuController.OnUnPublish = this.onUnPublish;

    this.mcuController.OnStartRecordSucc = this.startRecordSucc;
    this.mcuController.OnStartRecordFailed = (recordId, errCode, errMsg) => {
      message.error(`开始录制音视频失败！${errCode}:${errMsg}(${recordId})`);
    };
    this.mcuController.OnStopRecordSucc = this.afterStopRecord;
    this.mcuController.OnStopRecordFailed = this.afterStopRecord;

    const { params } = this.props;
    this.mcuController.OnGetSign = () => params.signature;
    const connectParams: MeetingConfigParams = {
      room_server_url: ROOM_SERVER_URL_RELEASE,
      uid: params.uid,
      biz_name: params.bizName,
      sub_biz: params.subBiz,
    };
    this.mcuController.Connect(connectParams);
  };

  private initRoomConfig = () => {
    const { params } = this.props;
    this.mcuController?.InitRoomConfig({
      auto_publish_subscribe: 3,
      media_type: 1,
      publish_device: 1,
      bizName: params.bizName,
      subBiz: params.subBiz,
      uid: params.uid,
      ...DEFAULT_ROOM_CONFIG_PARAMS,
    });
  };

  private connected = () => {
    message.info('连接视频服务成功！');
    this.initRoomConfig();
  };

  private onConnectClose = () => {
    // @TODO 异常处理
    const { onClose } = this.props;
    onClose && onClose();
  };

  private onInitRoomConfigOK = () => {
    message.info('初始化房间成功！');
    const { roomId, roomToken } = this.props.params;
    if (roomId && roomToken && !this.shouldReinitialize) {
      this.sdkRoomParams.roomId = roomId;
      this.sdkRoomParams.roomToken = roomToken;
      this.mcuController?.JoinRoom(roomId, roomToken, 0);
    } else {
      this.mcuController?.CreateRoom();
    }
  };

  private onInitRoomConfigFail = (errCode: string, errMsg: string) => {
    message.error(`初始化房间失败！${errCode}:${errMsg}`);
  };

  private createRoomSucc: McuController['OnCreateRoomSucc'] = (
    roomId,
    roomToken,
  ) => {
    this.sdkRoomParams.roomId = roomId;
    this.sdkRoomParams.roomToken = roomToken;
    this.mcuController?.StartRemoteRecord();
  };

  private joinRoomSucc = () => {
    this.mcuController?.StartRemoteRecord();
    this.props.onStart();
    this.setState({ waiting: false });
    setTimeout(() => {
      this.startAsr();
    }, 5000);
  };

  private joinRoomFailed = () => {
    this.shouldReinitialize = true;
    this.initMeeting();
  };

  private onNewPublish: McuController['OnNewPublish'] = subscriber => {
    if (subscriber.tag !== 'VIDEO_SOURCE_SCREEN') {
      return;
    }
    this.setState({ screenVideoFeedId: subscriber.feedId });
    this.mcuController?.StartRemoteRecord(
      '',
      {
        tagFilter: 'VIDEO_SOURCE_SCREEN',
      },
      'VIDEO_SOURCE_SCREEN',
    );
  };
  private onUnPublish: McuController['OnUnPublish'] = subscriber => {
    if (subscriber.feedId === this.state.screenVideoFeedId) {
      this.setState({ screenVideoFeedId: '' });
      if (this.lastScreenRecordId) {
        this.mcuController?.StopRemoteRecord(this.lastScreenRecordId);
      }
    }
  };

  private startRecordSucc = (recordId: string, recordThirdId: string) => {
    message.info('开始录制音视频！');
    if (!recordThirdId) {
      this.sdkRoomParams.recordId = recordId;
      this.props.onCreate(this.sdkRoomParams);
    } else if (recordThirdId === 'VIDEO_SOURCE_SCREEN') {
      this.lastScreenRecordId = recordId;
      this.props.onScreenRecord(recordId);
      console.log('开始录制录屏： ', recordId);
    }
  };

  private startAsr = () => {
    [
      MEETING_HTML_TAGS.SUBSCRIBE_VIDEO_ID,
      MEETING_HTML_TAGS.PUBLISH_VIDEO_ID,
    ].forEach(elemId => {
      const sid = document.getElementById(elemId)?.name;
      this.mcuController?.StartAsr({
        sid,
        tag: 'inquiry_asr_tag',
        procType: 8,
      });
    });
  };

  private onAsrMessage: McuController['OnAsrMessage'] = (
    msg,
    sid,
    tag,
    status,
    sessionId,
  ) => {
    const subscribeSid = document.getElementById(
      MEETING_HTML_TAGS.SUBSCRIBE_VIDEO_ID,
    )?.name;
    const publishSid = document.getElementById(
      MEETING_HTML_TAGS.PUBLISH_VIDEO_ID,
    )?.name;
    let recordType: InquiryRecordTypes = InquiryRecordTypes.Ask;
    switch (sid) {
      case subscribeSid:
        recordType = InquiryRecordTypes.Answer;
        break;
      case publishSid:
        recordType = InquiryRecordTypes.Ask;
        break;
    }

    const asrMsg: AsrMessage = JSON.parse(msg);
    const rawMsg: RawInquiryRecordLine = {
      asr: asrMsg,
      type: recordType,
      status,
    };
    console.log(asrMsg);
    this.props.onAsr(rawMsg);
  };

  private afterStopRecord = (recordId: string) => {
    if (recordId === this.lastScreenRecordId) {
      this.lastScreenRecordId = '';
      return;
    }
    this.mcuController?.Disconnect();
  };

  componentWillUnmount() {
    this.mcuController?.StopRemoteRecord(this.sdkRoomParams.recordId);
  }

  private movingVideoStart = () => {
    this.isMovingVideo = true;
    window.addEventListener('click', this.movingVideoStop, false);
  };

  private movingVideoStop = () => {
    this.isMovingVideo = false;
    window.removeEventListener('click', this.movingVideoStop, false);
  };

  private movingVideo = (e: React.MouseEvent) => {
    const { floatingStyle } = this.state;
    if (!floatingStyle.cursor || !this.isMovingVideo) {
      return;
    }
    const { right, bottom, width, height } = floatingStyle as {
      right: number;
      bottom: number;
      width: number;
      height: number;
    };
    const { movementX, movementY } = e;
    let newRight = Math.max(right - movementX, 0);
    let newBottom = Math.max(bottom - movementY, 0);
    if (right + width - movementX > document.body.clientWidth) {
      newRight = document.body.clientWidth - width;
    }
    if (bottom + height - movementY > document.body.clientHeight) {
      newBottom = document.body.clientHeight - height;
    }

    this.setState({
      floatingStyle: {
        ...floatingStyle,
        right: newRight,
        bottom: newBottom,
      },
    });
  };

  render() {
    const { screenshotSignal } = this.props;
    const { waiting, floatingStyle, screenVideoFeedId } = this.state;

    return (
      <Spin
        spinning={waiting}
        tip="正在等待被询问人加入..."
        wrapperClassName={styles.meeting}
      >
        <div
          className={styles.meeting}
          style={floatingStyle}
          onMouseDown={this.movingVideoStart}
          onMouseUp={this.movingVideoStop}
          onMouseMove={this.movingVideo}
        >
          <div className={styles.tip}>
            <i className="iconfont icon-encrypt" />
            <label>加密视频通话</label>
          </div>

          <div className={styles.video}>
            <video
              id={MEETING_HTML_TAGS.SUBSCRIBE_VIDEO_ID}
              autoPlay
              muted
            ></video>
          </div>
          <div
            className={styles.video}
            style={
              screenVideoFeedId && floatingStyle.cursor !== 'move'
                ? {}
                : { width: 0, flex: 'none' }
            }
          >
            <video
              id={MEETING_HTML_TAGS.SUBSCRIBE_VIDEO_ID_2}
              autoPlay
              muted
            ></video>
          </div>

          <audio id={MEETING_HTML_TAGS.SUBSCRIBE_AUDIO_ID} autoPlay></audio>
          <label
            style={{ display: 'none' }}
            id={MEETING_HTML_TAGS.FEEDID_ID}
          ></label>
          <label
            style={{ display: 'none' }}
            id={MEETING_HTML_TAGS.SUBSCRIBE_STREAM_ID}
          ></label>
          <label style={{ display: 'none' }}>{screenshotSignal}</label>

          <audio id={MEETING_HTML_TAGS.SUBSCRIBE_AUDIO_ID_2} muted></audio>
          <label
            style={{ display: 'none' }}
            id={MEETING_HTML_TAGS.FEEDID_ID_2}
          ></label>
          <label
            style={{ display: 'none' }}
            id={MEETING_HTML_TAGS.SUBSCRIBE_STREAM_ID_2}
          ></label>
        </div>
      </Spin>
    );
  }
}

export default Meeting;
