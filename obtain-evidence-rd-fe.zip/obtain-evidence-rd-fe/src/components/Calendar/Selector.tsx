import React from 'react';
import moment, { Moment } from 'moment';
import classnames from 'classnames';

import { LeftOutlined, RightOutlined } from '@ant-design/icons';
import { Calendar, Row, Col, Badge } from 'antd';
import { HeaderRender } from 'antd/lib/calendar/generateCalendar';

import styles from './Calendar.less';

interface CalendarSelectorProps {
  className?: string;
  dates: Moment[];
  value: Moment;
  selectedStyleType: 'dot' | 'color';
  onSelect: (date: Moment) => void;
  onChangeMonth: (step: 1 | -1) => void;
}

const CalendarSelector: React.FC<CalendarSelectorProps> = props => {
  const {
    className,
    dates,
    value,
    selectedStyleType,
    onChangeMonth,
    onSelect,
  } = props;

  const headerRender: HeaderRender<Moment> = config => {
    return (
      <Row className={styles.selectorHeader}>
        <LeftOutlined onClick={() => onChangeMonth(-1)} />
        <Col flex={1}>
          <Row align="middle" justify="center">
            <span className={styles.selectorTitle}>
              {config.value.format('YYYY年M月')}
            </span>
          </Row>
        </Col>
        <RightOutlined onClick={() => onChangeMonth(1)} />
      </Row>
    );
  };

  const dateFullCellRender = (date: Moment) => {
    const isToday = moment().isSame(date, 'day');
    const selected = date.isSame(value, 'day');
    const included =
      Array.isArray(dates) && ~dates.findIndex(d => d.isSame(date, 'date'));
    const wrapperCls = classnames({
      [styles.selectorCellTitle]: true,
    });
    const contentCls = classnames({
      [styles.selectorCellIncluded]: selectedStyleType === 'color' && included,
      [styles.selectorCellToday]: isToday,
      [styles.selectorCellSelected]: selected,
    });

    const title = (
      <div className={wrapperCls}>
        <span className={contentCls}>{isToday ? '今' : date.format('D')}</span>
      </div>
    );

    let dot: React.ReactNode;
    if (selectedStyleType === 'dot' && included) {
      dot = <span className={styles.selectorCellDot} />;
    }

    return (
      <>
        {title}
        {dot}
      </>
    );
  };

  const cls = classnames({
    [styles.selector]: true,
    [className as string]: !!className,
  });

  return (
    <Calendar
      className={cls}
      value={value}
      fullscreen={false}
      headerRender={headerRender}
      dateFullCellRender={dateFullCellRender}
      onSelect={onSelect}
    />
  );
};

export default CalendarSelector;
