import moment from 'moment';
import { random, range } from 'lodash';
import api from '../src/services/api';
import { wrapResponse, wrapPagination } from './util';
import { CaseSimple, CaseType } from 'umi';
import { CaseAuthTypes } from '../src/models/constants';

import { getRandomUsers } from './user';

const caseTypes: CaseType[] = [
  {
    id: '01',
    name: '刑事',
    children: [
      {
        id: '001',
        name: '电诈',
      },
      {
        id: '002',
        name: '盗窃',
      },
      { id: '003', name: '抢劫' },
    ],
  },
  {
    id: '02',
    name: '民诉',
    children: [
      {
        id: '003',
        name: '斗殴',
      },
      {
        id: '004',
        name: '劳动纠纷',
      },
    ],
  },
];

const cases: CaseSimple[] = [
  {
    id: '001',
    title: '5.12电信诈骗案',
    typeName: caseTypes[0].name,
    subTypeName: caseTypes[0].children[0].name,
    dutyUserName: getRandomUsers(1)[0].userName,
    nextTime: moment()
      .add('day', 8)
      .format('YYYY-MM-DD'),
    authType: CaseAuthTypes.LookUp,
    createDate: moment().format('YYYY-MM-DD'),
  },
  {
    id: '002',
    title: '莲花小区盗窃案',
    typeName: caseTypes[0].name,
    subTypeName: caseTypes[0].children[1].name,
    dutyUserName: getRandomUsers(1)[0].userName,
    nextTime: moment()
      .add('day', 8)
      .format('YYYY-MM-DD'),
    authType: CaseAuthTypes.Edit,
    createDate: moment().format('YYYY-MM-DD'),
  },
  {
    id: '003',
    title: '丰潭小区盗窃案',
    typeName: caseTypes[0].name,
    subTypeName: caseTypes[0].children[1].name,
    dutyUserName: getRandomUsers(1)[0].userName,
    nextTime: moment()
      .add('day', 8)
      .format('YYYY-MM-DD'),
    authType: CaseAuthTypes.LookUp,
    createDate: moment().format('YYYY-MM-DD'),
  },
  {
    id: '004',
    title: 'xx银行抢劫案',
    typeName: caseTypes[0].name,
    subTypeName: caseTypes[0].children[2].name,
    dutyUserName: getRandomUsers(1)[0].userName,
    nextTime: moment()
      .add('day', 8)
      .format('YYYY-MM-DD'),
    authType: CaseAuthTypes.LookUp,
    createDate: moment().format('YYYY-MM-DD'),
  },
];

export default {
  [api.getPaginationCases]: (req: any, res: any) => {
    const { pageSize, toPage } = req.query;
    const casePagination = wrapPagination(100, +toPage, +pageSize, cases);
    return res.end(JSON.stringify(wrapResponse(casePagination)));
  },
  [api.getMyPaginationCases]: (req: any, res: any) => {
    const { pageSize, toPage } = req.query;
    const casePagination = wrapPagination(100, +toPage, +pageSize, cases);
    return res.end(JSON.stringify(wrapResponse(casePagination)));
  },
  [api.getCaseTypes]: wrapResponse(caseTypes),
};
