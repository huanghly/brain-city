import {
  Effect,
  ImmerReducer,
  Subscription,
  ModelNamespaces,
  ReservationStatus,
  InquiryRecordTypes,
  ReservationDisplay,
  OSSFileInfo,
} from 'umi';
import { AsrMessage } from '@/utils/meeting';
import { NotificationActions } from '@/common/constants';

export type LiveMeetingParams = {
  bizName: string;
  signature: string;
  subBiz: string;
  uid: string;
  roomId?: string;
  roomToken?: string;
};

export type InquiryInfoSimple = {
  startTime: string;
  endTime: string;
  inquiryId: number;
  durationHours: number;
};

export type InquiryInfo = {
  date: string;
  startTime: string;
  endTime: string;
  inquiryLocation: string;
  caseName: string;
  reservationId: string;
  inquirerId: string;
  inquirerName: string;
  inquirerDepartment: string;
  recorderId: string;
  recorderName: string;
  recorderDepartment: string;
  inquiryStatus: ReservationStatus;
};

export type InquiryRecordInquiree = {
  inquiredName: string;

  inquiredEducation: string;
  inquiredPolitical: string;
  inquiredIsDeputy: boolean;
  inquiredCertType: string;
  inquiredCertNO: string;

  inquiredWorkAddress: string;
  inquiredAddress: string;
  inquiredHouseholdAddress: string;

  inquiredGender: string;
  inquiredAge: string;
  inquiredNationality: string;
  inquiredNation: string;
  inquiredBirth: string;
  inquiredPhone: string;
  inquiredLocation?: string;

  inquiredType?: '受害人' | '证人' | '嫌疑人' | '监护人';
};

export type InquiryRecordImage = {
  id: string;
  file?: string;
};

export type InquiryRecordLine = {
  type: InquiryRecordTypes;
  content: string;
  timestamp: number;
  images?: { [categoryName: string]: InquiryRecordImage[] };
  isDeleted?: number;
  updatedTimestamp?: number;
};

export type RawInquiryRecordLine = {
  asr: AsrMessage;
  type: InquiryRecordTypes;
  status: 0 | 1;
};

export type UpdateLines = {
  type: InquiryRecordTypes | undefined;
  timestamp?: number;
  images: { id: string; file?: string | undefined }[] | undefined;
  content: string | undefined;
  isDeleted: number;
  updatedTimestamp: number;
}[];

export type MeetingSdkRoomParams = {
  roomId: string;
  roomToken: string;
  recordId: string;
};

// websocket payload

export type InquireeWsPayload =
  | {
      action: NotificationActions.imageEvidenceUploaded;
      evidences: Array<{
        id: string;
        signImage: OSSFileInfo;
        evidenceFile: OSSFileInfo;
      }>;
    }
  | {
      action: NotificationActions.imageEvidenceConfirmed;
      evidenceId: string;
      identityId: string;
    }
  | {
      action: NotificationActions.startRecordConfirm;
    }
  | { action: NotificationActions.startRecordSign; identityId: string }
  | {
      action: NotificationActions.recordConfirmed;
      signImage: string;
      confirmImage: string;
      startConfirmTime: string;
      endConfirmTime: string;
      identityId: string;
    }
  | {
      action: NotificationActions.recordSigned;
      signature: string;
      identityId: string;
    }
  | {
      action: NotificationActions.keepAlive;
    }
  | {
      action: NotificationActions.editRecord;
    }
  | {
      action: NotificationActions.recordEdited;
      lines: {};
    }
  | {
      action: NotificationActions.recordEdited;
      info: {};
    };

export interface InquiryModelState {
  reservations: {
    today: ReservationDisplay[];
    week: PaginationModel<ReservationDisplay>;
  };

  inquiryInfo?: InquiryInfo;

  live: {
    currentInquiryId: number;
    meetingParams: LiveMeetingParams;
    recordStatus: {
      confirmed: boolean;
      evidenceId?: number;
    };

    recordLines: InquiryRecordLine[];
  };
}

export interface InquiryModelType {
  namespace: ModelNamespaces.Inquiry;
  state: InquiryModelState;
  effects: {
    getTodayReservations: Effect;
    getWeekPaginationReservations: Effect;
    editReservation: Effect;

    getInquiryInfo: Effect;
    editInquiree: Effect;

    uploadRecordLines: Effect;
    getConvertedFingerprint: Effect;

    editInquiry: Effect;
    enterInquiry: Effect;
    createMeeting: Effect;
    addScreenRecord: Effect;
    endMeeting: Effect;
    addLiveRecordLine: Effect;
    editRecord: Effect;
    removeRecord: Effect;

    initializePageLive: Effect;
  };
  reducers: {
    save: ImmerReducer<InquiryModelState>;
    saveLiveModel: ImmerReducer<InquiryModelState>;
    editInquireeRecord: ImmerReducer<InquiryModelState>;
    saveLiveRecordLine: ImmerReducer<InquiryModelState>;
    editSingleRecord: ImmerReducer<InquiryModelState>;
    removeSingleRecord: ImmerReducer<InquiryModelState>;
  };
  subscriptions: { setup: Subscription };
}

export interface MapConfig {
  style: {};
  key: string;
  map: {};
}
