# **Usage**

`import API from 'services’;`  //引用

`API.get(data, headers, config);`  //方法调用

- data: 入参
- headers: 请求头参数
- config: 请求配置，透传到`axios`
