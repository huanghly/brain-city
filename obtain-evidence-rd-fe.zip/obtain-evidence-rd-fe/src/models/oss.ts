import { OSSModelType } from 'umi';
import { ModelNamespaces } from './constants';
import api from '@/services';

import { handleError } from '@/common/util';

const CaseModel: OSSModelType = {
  namespace: ModelNamespaces.OSS,
  effects: {
    *getOssFiles({ payload, callback }, { call }) {
      const { uuids } = payload;
      try {
        const fileUrls: string[] = yield call(api.getOssFiles, { uuids });
        callback(fileUrls);
      } catch (err) {
        handleError(err);
      }
    },
  },
};

export default CaseModel;
