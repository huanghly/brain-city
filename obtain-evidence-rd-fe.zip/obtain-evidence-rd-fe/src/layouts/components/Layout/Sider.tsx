import React, { useState } from 'react';
import { useLocation, history } from 'umi';

import { MenuFoldOutlined, MenuUnfoldOutlined } from '@ant-design/icons';
import { Layout, Row, Menu } from 'antd';
const { Sider } = Layout;
const { SubMenu } = Menu;

import { ClickParam } from 'antd/lib/menu';
import { LayoutConfigItem } from '@/config/types';

import styles from './index.less';

interface PortalSiderProps {
  menus: LayoutConfigItem[];
}

const PortalSider: React.FC<PortalSiderProps> = props => {
  const { pathname } = useLocation();
  const { menus } = props;
  const [collapsed, setCollapsed] = useState(false);

  const toggleCollapsed = () => {
    setCollapsed(!collapsed);
  };

  const renderMenu = (items: LayoutConfigItem[]) =>
    items.map(menuItem => {
      const icon = (
        <span className="anticon">
          <i className={`${menuItem.icon} iconfont ${styles.menuIcon}`} />
        </span>
      );
      return menuItem.sideMenus?.length ? (
        <SubMenu
          key={menuItem.pathConfig.path}
          icon={icon}
          title={menuItem.name}
        >
          {renderMenu(menuItem.sideMenus)}
        </SubMenu>
      ) : (
        <Menu.Item key={menuItem.pathConfig.path} icon={icon}>
          {menuItem.name}
        </Menu.Item>
      );
    });

  const menuClick = (params: ClickParam) => {
    const { key } = params;
    if (key.startsWith('/')) {
      history.push(key);
    }
  };

  return (
    <Sider
      width={208}
      theme="light"
      className={styles.sider}
      collapsible
      collapsed={collapsed}
      trigger={null}
    >
      <Row className={styles.folder} align="middle" justify="center">
        {collapsed ? (
          <MenuUnfoldOutlined onClick={toggleCollapsed} />
        ) : (
          <MenuFoldOutlined onClick={toggleCollapsed} />
        )}
      </Row>
      <Row>
        <Menu
          className={styles.menu}
          mode="inline"
          selectedKeys={[pathname]}
          onClick={menuClick}
        >
          {renderMenu(menus)}
        </Menu>
      </Row>
    </Sider>
  );
};

export default PortalSider;
