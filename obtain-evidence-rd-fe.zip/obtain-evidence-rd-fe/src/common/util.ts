import { Moment } from 'moment';
import { message } from 'antd';
import {
  DAY_HOURS,
  HOUR_MINUTES,
  DAY_SECTIONS,
  DEFAULT_PAGE_SIZE,
  MINUTE_STEP,
} from './constants';
import { padStart, omit } from 'lodash-es';
import { ModelDispatchType } from 'umi';

export function getTimespanFromDaySection(
  daySection: number,
): [string, string] {
  if (daySection < 0 || daySection >= DAY_SECTIONS) {
    throw new Error(`daySection should be between 0 and ${daySection}`);
  }

  const [startTime, endTime] = [daySection, daySection + 1].map(section => {
    const minutes = (section / DAY_SECTIONS) * DAY_HOURS * HOUR_MINUTES;
    const hour = padStart(
      Math.floor(minutes / HOUR_MINUTES).toString(),
      2,
      '0',
    );
    const minute = padStart(
      Math.floor(minutes % HOUR_MINUTES).toString(),
      2,
      '0',
    );
    return `${hour}:${minute}`;
  });
  return [startTime, endTime];
}

export function getDaySectionFromStartTime(time: string | Moment) {
  if (!time) {
    return undefined;
  }
  const timeStr = typeof time === 'string' ? time : time.format('HH:mm');
  const [hour, minute] = timeStr.split(':').map(Number);
  const daySection =
    (hour * DAY_SECTIONS) / DAY_HOURS + Math.floor(minute / MINUTE_STEP);
  return daySection;
}

export function getDefaultPaginationModel<T>(
  pageSize: number = DEFAULT_PAGE_SIZE,
): PaginationModel<T> {
  return {
    list: [],
    total: 0,
    pageSize,
    current: 1,
  };
}

export function parseRequestPagination(params: any) {
  const { current } = params;
  const requestParams = omit(params, 'current');
  requestParams.toPage = current;
  return requestParams;
}

export function parseResponsePagination(asyncData: any): PaginationModel<any> {
  console.log(asyncData);
  const {
    datas: list,
    pageSize,
    toPage: current,
    totalCount: total,
  } = asyncData;
  return { list, pageSize, current, total };
}

export function getDispatchType<T extends keyof ModelDispatchType>(
  namespace: T,
  effectName: ModelDispatchType[T],
) {
  return `${namespace}/${effectName}`;
}

export function handleError(err: any) {
  const msg = err.message || `${err.data?.errCode}: ${err.data?.errMsg}`;
  if (msg) {
    message.error(msg);
  }
}

export function getBlobsFromBase64Images(base64Images: string[]) {
  const promise = Promise.all(
    base64Images.map(base64 => fetch(base64)),
  ).then(resImages => Promise.all(resImages.map(res => res.blob())));
  return promise;
}
