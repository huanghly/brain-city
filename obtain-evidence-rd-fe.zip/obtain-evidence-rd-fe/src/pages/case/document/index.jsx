import React, { Component, useState } from 'react';
import {
  Input,
  Select,
  DatePicker,
  Button,
  Table,
  Space,
  Drawer,
  Form,
} from 'antd';
import { history } from 'umi';
import { SearchOutlined } from '@ant-design/icons';
import styles from './index.less';
import Apply from '../subscribe/apply';

const Option = Select.Option;

const formItemLayout = {
  labelCol: { span: 6 },
  wrapperCol: { span: 16 },
};

class CaseDocument extends Component {
  state = { visible: false, subscribeVisible: false };

  mockColumns() {
    const columns = [
      {
        title: '案事件名称',
        dataIndex: 'name',
        key: 'name',
        render: text => <a>{text}</a>,
      },
      {
        title: '案事件类型',
        dataIndex: 'type',
        key: 'type',
      },
      {
        title: '建档日期',
        dataIndex: 'date',
        key: 'date',
      },
      {
        title: '负责人',
        dataIndex: 'owner',
        key: 'owner',
      },
      {
        title: '下次询问时间',
        dataIndex: 'nextdate',
        key: 'nextdate',
      },
      {
        title: 'Action',
        key: 'action',
        render: record => {
          return record.key % 2 ? (
            <Space size="middle">
              <a
                onClick={() => {
                  history.push('/case/detail');
                }}
              >
                浏览
              </a>
              <a>编辑</a>
            </Space>
          ) : (
            <Space size="middle">
              <a onClick={this.showSubsribeDrawer}>调阅</a>
            </Space>
          );
        },
      },
    ];
    return columns;
  }

  mockData() {
    const data = [];
    for (var i = 0; i < 10; i++) {
      const item = {};
      item.key = i;
      item.name = '案件' + i;
      item.type = i % 2 ? '诈骗案' : '盗窃案';
      item.date = '2020-06-20';
      item.owner = i % 2 ? '张三' : '李四';
      item.nextdate = '2020-06-30';
      data.push(item);
    }
    return data;
  }

  showDrawer = () => {
    this.setState({ visible: true });
  };
  onClose = () => {
    this.setState({ visible: false });
  };

  showSubsribeDrawer = () => {
    this.setState({ subsribeVisible: true });
  };
  onSubsribeClose = () => {
    this.setState({ subsribeVisible: false });
  };

  render() {
    return (
      <div className={styles.wrapper}>
        <h2>案件档案</h2>
        <div className={styles.content}>
          <div className={styles.optbar}>
            <Input
              placeholder="请输入关键词，如案事件名称"
              suffix={<SearchOutlined className="site-form-item-icon" />}
              style={{ width: 248 }}
            />
            <Select
              style={{ width: 144, marginLeft: 10 }}
              placeholder="案事件类型"
            >
              <Option value="1">案件1</Option>
              <Option value="2">案件2</Option>
              <Option value="3">案件3</Option>
            </Select>
            <DatePicker style={{ marginLeft: 10 }} placeholder="请选择日期" />
            <Button
              style={{ marginLeft: 10 }}
              type="primary"
              onClick={this.showDrawer}
            >
              新增案事件档案
            </Button>
          </div>
          <Table columns={this.mockColumns()} dataSource={this.mockData()} />
        </div>
        <Drawer
          title="新增案事件档案"
          placement="right"
          width={640}
          visible={this.state.visible}
          onClose={this.onClose}
          footer={
            <div style={{ textAlign: 'left' }}>
              <Button
                onClick={this.onClose}
                type="primary"
                style={{ marginLeft: 10, marginRight: 10 }}
              >
                确定
              </Button>
              <Button onClick={this.onClose}>取消</Button>
            </div>
          }
        >
          <Form.Item name="name" label="案事件名称" {...formItemLayout}>
            <Input placeholder="请输入案事件名称" />
          </Form.Item>
          <Form.Item name="type" label="案事件类型" {...formItemLayout}>
            <Select placeholder="请选择案事件类型">
              <Option>诈骗案</Option>
              <Option>盗窃案</Option>
            </Select>
          </Form.Item>
          <Form.Item name="owner" label="案事件责任人" {...formItemLayout}>
            <Select mode="multiple" placeholder="请选择案事件责任人">
              <Option value="1">张三</Option>
              <Option value="2">李四</Option>
              <Option value="3">王五</Option>
            </Select>
          </Form.Item>
          <Form.Item name="people" label="参与侦办人" {...formItemLayout}>
            <Select mode="multiple" placeholder="请选择参与侦办人">
              <Option value="1">张三</Option>
              <Option value="2">李四</Option>
              <Option value="3">王五</Option>
            </Select>
          </Form.Item>
          <Form.Item name="creator" label="建档人" {...formItemLayout}>
            <Input defaultValue="张三" value="张三" disabled />
          </Form.Item>
        </Drawer>
        <Apply
          visible={this.state.subsribeVisible}
          onClose={this.onSubsribeClose}
        />
      </div>
    );
  }
}

export default CaseDocument;
