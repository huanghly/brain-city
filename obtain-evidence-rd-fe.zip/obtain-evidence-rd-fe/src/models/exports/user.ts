import {
  ModelNamespaces,
  Effect,
  ImmerReducer,
  Subscription,
  InquiryIdentityTypes,
} from 'umi';

export interface UserInfoBase {
  userId: string;
  userAccount: string;
}

export interface UserInfo extends UserInfoBase {
  userName: string;
}

export interface UserInfoInquiry extends UserInfoBase {
  identityType: InquiryIdentityTypes;
}

export interface UserModelState {
  users: UserInfo[];
  currentUser?: UserInfo;
}

export interface UserModelType {
  namespace: ModelNamespaces.User;
  state: UserModelState;
  effects: {
    getUsers: Effect;
    getCurrentUser: Effect;
    logout: Effect;
  };
  reducers: {
    save: ImmerReducer<UserModelState>;
  };
  subscriptions: { setup: Subscription };
}
