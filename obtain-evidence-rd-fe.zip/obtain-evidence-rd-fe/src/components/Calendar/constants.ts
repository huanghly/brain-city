import { range, padStart } from 'lodash-es';
import { DAY_HOURS, DAY_SECTIONS } from '@/common/constants';

export enum CalendarTypes {
  Day = 'day',
  Week = 'week',
}

export const DaySectionsRange = range(0, DAY_SECTIONS);
export const DayItems = range(0, DAY_HOURS + 1).map(serial => {
  const hour = padStart(serial.toString(), 2, '0');
  return `${hour}:00`;
});
