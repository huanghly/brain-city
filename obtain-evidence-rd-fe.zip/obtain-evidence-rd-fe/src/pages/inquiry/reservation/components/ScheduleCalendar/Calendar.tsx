import React, { useState } from 'react';
import { Moment } from 'moment';
import { ReservationModelState } from 'umi';

import Calendar from '@/components/Calendar';
import { CalendarTypes } from '@/components/Calendar/constants';

import styles from './ScheduleCalendar.less';

interface ScheduleCalendarProps {
  date: Moment;
  reservations: ReservationModelState['reservations'];
}

const ScheduleCalendar: React.FC<ScheduleCalendarProps> = props => {
  const { date, reservations } = props;
  const [calendarType, setCalendarType] = useState(CalendarTypes.Day);
  const reservationCount =
    calendarType === CalendarTypes.Day
      ? reservations.day.length
      : reservations.week.length;
  return (
    <>
      <Calendar.Header
        type={calendarType}
        renderHeader={() => (
          <div className={styles.calendarHeader}>
            <span className={styles.count}>{reservationCount}</span>
            <span>预约</span>
            <span>{date.format('YYYY年M月D日 dddd')}</span>
          </div>
        )}
        onChange={setCalendarType}
      />
      {calendarType === CalendarTypes.Day && (
        <Calendar.Day date={date} value={reservations.day} />
      )}
      {calendarType === CalendarTypes.Week && (
        <Calendar.Week date={date} value={reservations.week} />
      )}
    </>
  );
};

export default ScheduleCalendar;
