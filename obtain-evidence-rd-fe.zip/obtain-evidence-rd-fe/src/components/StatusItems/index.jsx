import React from 'react';
import styles from './index.less';

const StatusItems = ({ items, className, style }) => {
  return (
    <div className={`${styles.container} ${className || ''}`} style={style}>
      {(items || []).map(item => {
        return (
          <div className={styles.item} key={item.value}>
            <div
              style={{ backgroundColor: item.color }}
              className={styles.itemColor}
            />
            <div className={styles.itemLabel}>{item.label}</div>
          </div>
        );
      })}
    </div>
  );
};

export default StatusItems;
