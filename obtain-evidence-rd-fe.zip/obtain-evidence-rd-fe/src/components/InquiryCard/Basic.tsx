import React from 'react';
import moment from 'moment';
import classnames from 'classnames';

import {
  EvidenceRecord,
  EvidenceRecordInquiree,
  InquiryIdentityTypes,
  InquiryMapIdentity,
  getInquireeIdentityIdByMapIdentity,
} from 'umi';

import { InfoCircleOutlined, EditOutlined } from '@ant-design/icons';
import { Spin, Row, Col, Popover } from 'antd';

import styles from './InquiryCard.less';

const cls = classnames({
  [styles.basic]: true,
  [styles.gap]: true,
});

interface InquiryBasicCardProps {
  record?: EvidenceRecord['detail'];
  mapIdentity: InquiryMapIdentity;
  canEdit?: boolean;
  renderHeader?: (record?: EvidenceRecord['detail']) => void;
  onEditInquiree?: () => void;
}

const InquiryBasicCard: React.FC<InquiryBasicCardProps> = props => {
  const { record, mapIdentity, canEdit, renderHeader, onEditInquiree } = props;
  if (!record) {
    return <Spin />;
  }

  const { basicInfo, inquirer, inquired } = record;
  const inquirerInfo = inquirer[mapIdentity[InquiryIdentityTypes.Inquirer]![0]];
  const recorderInfo = inquirer[mapIdentity[InquiryIdentityTypes.Recorder]![0]];
  const currentInquireeIdentityId = getInquireeIdentityIdByMapIdentity(
    mapIdentity,
  )!;
  const inquireeInfo = inquired[currentInquireeIdentityId];
  const guardianInfo =
    inquired[mapIdentity[InquiryIdentityTypes.Guardian]?.[0] || ''];

  return (
    <div className={cls}>
      {renderHeader ? (
        renderHeader(record)
      ) : (
        <Row justify="center" className={styles.title}>
          电子询问笔录
        </Row>
      )}

      <Row>
        <Col>询问时间：</Col>
        <Col flex={1} className={styles.underlined}>
          <span>
            {basicInfo.startTime &&
              moment(basicInfo.startTime).format('YYYY年M月D日 HH时mm分')}
          </span>
          {basicInfo.endTime && (
            <>
              <span>至</span>
              <span>
                {moment(basicInfo.endTime).format('YYYY年M月D日 HH时mm分')}
              </span>
            </>
          )}
        </Col>
      </Row>
      <Row>
        <Col>询问人所在地：</Col>
        <Col flex={1} className={styles.underlined}>
          {basicInfo.inquiryLocation}
        </Col>
      </Row>
      <Row>
        <Col>询问人：</Col>
        <Col flex={1} className={styles.underlined}>
          {inquirerInfo.userName}
        </Col>
        <Col>询问单位：</Col>
        <Col flex={2} className={styles.underlined}>
          {inquirerInfo.departmentName}
        </Col>
      </Row>
      <Row>
        <Col>记录人：</Col>
        <Col flex={1} className={styles.underlined}>
          {recorderInfo.userName}
        </Col>
        <Col>询问单位：</Col>
        <Col flex={2} className={styles.underlined}>
          {recorderInfo.userName}
        </Col>
      </Row>
      <InquireeFragment value={inquireeInfo} />
      {!!guardianInfo && (
        <Row>
          <Col>监护人资料：</Col>
          <Col>
            <Popover
              trigger="click"
              content={<InquireeFragment value={guardianInfo} />}
            >
              <InfoCircleOutlined />
            </Popover>
          </Col>
        </Row>
      )}
      {canEdit && (
        <label className={styles.edit} onClick={onEditInquiree}>
          <EditOutlined /> 被询问人编辑
        </label>
      )}
    </div>
  );
};

export default React.memo(InquiryBasicCard);

interface InquireeFragmentProps {
  value: EvidenceRecordInquiree;
}

const InquireeFragment: React.FC<InquireeFragmentProps> = props => {
  const { value } = props;
  return (
    <div className={styles.gap}>
      <Row>
        <Col>被询问人：</Col>
        <Col flex={1} className={styles.underlined}>
          {value.userName}
        </Col>
        <Col>性别：</Col>
        <Col flex={1} className={styles.underlined}>
          {value.gender}
        </Col>
      </Row>
      <Row>
        <Col>国籍：</Col>
        <Col flex={1} className={styles.underlined}>
          {value.nationality}
        </Col>
        <Col>民族：</Col>
        <Col flex={1} className={styles.underlined}>
          {value.nation}
        </Col>
      </Row>
      <Row>
        <Col>证件类型：</Col>
        <Col flex={1} className={styles.underlined}>
          {value.certType}
        </Col>
      </Row>
      <Row>
        <Col>证件号：</Col>
        <Col flex={1} className={styles.underlined}>
          {value.certNo}
        </Col>
      </Row>
      <Row>
        <Col>出生日期：</Col>
        <Col flex={1} className={styles.underlined}>
          {value.birth}
        </Col>
        <Col>联系电话：</Col>
        <Col flex={1} className={styles.underlined}>
          {value.phoneNo}
        </Col>
      </Row>
      <Row>
        <Col>是否人大代表：</Col>
        <Col flex={1} className={styles.underlined}>
          {value.isDeputy ? '是' : '否'}
        </Col>
        <Col>政治面貌：</Col>
        <Col flex={1} className={styles.underlined}>
          {value.political}
        </Col>
      </Row>
      {!!value.location && (
        <Row>
          <Col>被询问人所在地：</Col>
          <Col flex={1} className={styles.underlined}>
            {value.location}
          </Col>
        </Row>
      )}
      <Row>
        <Col>家庭住址：</Col>
        <Col flex={1} className={styles.underlined}>
          {value.householdAddress}
        </Col>
      </Row>
      <Row>
        <Col>工作单位：</Col>
        <Col flex={1} className={styles.underlined}>
          {value.workAddress}
        </Col>
      </Row>
      {!!value.virtualName && (
        <Row>
          <Col>虚拟身份：</Col>
          <Col flex={1} className={styles.underlined}>
            {value.virtualName}
          </Col>
        </Row>
      )}
    </div>
  );
};
