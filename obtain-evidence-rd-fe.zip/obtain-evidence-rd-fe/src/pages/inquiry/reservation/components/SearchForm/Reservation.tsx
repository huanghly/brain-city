import React from 'react';
import { debounce, omit } from 'lodash-es';
import { RoomLocation, RoomQueryParams } from 'umi';

import { SearchOutlined } from '@ant-design/icons';
import { Form, Input, Cascader, TimePicker, Button } from 'antd';
const { useForm } = Form;

import {
  MINUTE_STEP,
  DAY_SECTIONS,
  SEARCH_FORM_CHANGE_DEBOUNCE,
} from '@/common/constants';
import { getDaySectionFromStartTime } from '@/common/util';

interface ReservationProps {
  locations: RoomLocation[];
  onChange: (changedValues: Partial<RoomQueryParams>) => void;
}

const Reservation: React.FC<ReservationProps> = props => {
  const { locations, onChange } = props;
  const [form] = useForm();

  const valuesChange = debounce((_, values: Partial<RoomQueryParams>) => {
    const { startTime, endTime, locationIds } = values;
    if (startTime) {
      values.begin = getDaySectionFromStartTime(startTime);
    }
    if (endTime) {
      // 00:00 切换成第二天开始
      values.end = getDaySectionFromStartTime(endTime);
      if (
        !values.begin ||
        (values.end && values.begin > values.end && values.end === 0)
      ) {
        values.end = DAY_SECTIONS - 1;
      }
    }
    if (Array.isArray(locationIds)) {
      values.locationId = locationIds[locationIds.length - 1];
    }
    const changedValues = omit(values, [
      'startTime',
      'endTime',
      'locationIds',
    ] as Array<keyof RoomQueryParams>);
    onChange(changedValues);
  }, SEARCH_FORM_CHANGE_DEBOUNCE);

  const resetFields = () => {
    form.resetFields();
    valuesChange(null, {});
  };

  return (
    <Form
      form={form}
      layout="inline"
      className="g-form-search"
      onValuesChange={valuesChange}
    >
      <Form.Item name="roomKeyword">
        <Input
          className="g-input-keyword"
          suffix={<SearchOutlined />}
          placeholder="请输入询问室名称或编号"
        />
      </Form.Item>
      <Form.Item name="locationIds">
        <Cascader
          options={locations}
          fieldNames={{ label: 'name', value: 'id' }}
        />
      </Form.Item>
      <Form.Item name="startTime">
        <TimePicker
          minuteStep={MINUTE_STEP}
          format="HH:mm"
          inputReadOnly
          placeholder="开始时间"
        />
      </Form.Item>
      <Form.Item name="endTime">
        <TimePicker
          minuteStep={MINUTE_STEP}
          format="HH:mm"
          inputReadOnly
          placeholder="结束时间"
        />
      </Form.Item>
      <Form.Item>
        <Button onClick={resetFields}>重置</Button>
      </Form.Item>
    </Form>
  );
};

export default Reservation;
