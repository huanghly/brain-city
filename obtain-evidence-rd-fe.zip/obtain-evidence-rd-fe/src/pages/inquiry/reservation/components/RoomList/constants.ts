import { DAY_SECTIONS } from '@/common/constants';

export const DEFAULT_SECTION_WIDTH = 21;
export const SECTIONS_WIDTH = DAY_SECTIONS * DEFAULT_SECTION_WIDTH;
