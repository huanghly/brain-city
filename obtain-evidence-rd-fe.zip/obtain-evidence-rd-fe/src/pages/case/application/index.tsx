import React from 'react';
import { Moment } from 'moment';
import {
  connect,
  ConnectProps,
  RootModelState,
  Dispatch,
  ModelNamespaces,
  CaseApplicationQueryParams,
  WorkflowTypesLocale,
  WorkflowTypes,
  WorkflowStatus,
  WorkflowStatusSetting,
  CaseApplication,
  WorkflowApprovalOperations,
  Case,
} from 'umi';
import { getDispatchType } from '@/common/util';

import { Table, Button, Badge, Popconfirm, message } from 'antd';
const { Column } = Table;
import { ButtonProps } from 'antd/lib/button';
import { ColumnProps, TablePaginationConfig, TableProps } from 'antd/lib/table';

import ContentPage from '@/components/ContentPage';
import SearchForm from '@/pages/case/components/SearchForm';
import CaseSubscribeDrawer from '@/pages/case/components/CaseSubscribeDrawer';

type CaseApplicationPageProps = ConnectProps &
  CaseApplicationPageDispatchProps &
  CaseApplicationPageStateProps;

type CaseApplicationPageStates = {
  drawerVisible: boolean;
  editingCase?: Partial<Case>;
};

class CaseApplicationPage extends React.PureComponent<
  CaseApplicationPageProps,
  CaseApplicationPageStates
> {
  private applicationQueryParams: CaseApplicationQueryParams = {};

  state: Readonly<CaseApplicationPageStates> = { drawerVisible: false };

  constructor(props: CaseApplicationPageProps) {
    super(props);
    const { current, pageSize } = this.props.myApplications;
    this.applicationQueryParams = {
      current,
      pageSize,
    };
  }

  private queryMyApplications = (queryParams: CaseApplicationQueryParams) => {
    queryParams.current = 1;
    queryParams.pageSize = this.applicationQueryParams.pageSize;
    this.applicationQueryParams = queryParams;
    this.props.getMyPaginationApplications(this.applicationQueryParams);
  };

  private tableChange = (pagination?: TablePaginationConfig) => {
    const { pageSize, current } = pagination || this.applicationQueryParams;
    this.applicationQueryParams.pageSize = pageSize;
    this.applicationQueryParams.current = current;
    this.props.getMyPaginationApplications(this.applicationQueryParams);
  };

  private goToDetail = (caseId: string) => {
    const { history, getCaseLatestInquiryDate } = this.props;
    getCaseLatestInquiryDate(caseId, (latestDate?: Moment) => {
      if (latestDate) {
        // @TODO
        // history.push(`/case/subscription/${record.caseId}`);
        history.push(`/case/archive/${caseId}`);
        return;
      }
      message.warning('该案事件暂无询问数据！');
    });
  };

  private renderOperation: ColumnProps<CaseApplication>['render'] = (
    _,
    record,
  ) => {
    const buttonProps: ButtonProps = {
      size: 'small',
      type: 'link',
    };
    switch (record.status) {
      case WorkflowStatus.Approved:
        buttonProps.children = '浏览';
        buttonProps.onClick = () => {
          this.goToDetail(record.caseId);
        };
        break;
      case WorkflowStatus.New:
        buttonProps.children = '撤回';
        break;
      case WorkflowStatus.Rejected:
      case WorkflowStatus.Revoked:
        buttonProps.children = '申请';
        buttonProps.onClick = () => {};
        break;
    }

    let element = <Button {...buttonProps} />;
    if (record.status === WorkflowStatus.New) {
      element = (
        <Popconfirm
          title="确认要撤回吗？"
          onConfirm={() => {
            this.props.updateApplication(
              record.id,
              WorkflowApprovalOperations.Cancel,
              () => {
                message.info(
                  `案件 ${record.caseName} ${
                    WorkflowTypesLocale[record.type]
                  } 撤回成功！`,
                );
                this.tableChange();
              },
            );
          }}
        >
          {element}
        </Popconfirm>
      );
    }
    return element;
  };

  render() {
    const { myApplications } = this.props;
    const { list, ...paginationProps } = myApplications;
    const { drawerVisible, editingCase } = this.state;

    return (
      <ContentPage title="我发起的">
        <SearchForm.Application onChange={this.queryMyApplications} />
        <Table
          className="g-table-list"
          rowKey="id"
          pagination={{ ...paginationProps, showSizeChanger: true }}
          dataSource={list}
          onChange={this.tableChange}
        >
          <Column title="案事件名称" dataIndex="caseName" />
          <Column title="审批人" width={120} dataIndex="approver" />
          <Column
            title="申请日期"
            align="center"
            width={120}
            dataIndex="applicationDate"
          />
          <Column title="申请事由" dataIndex="reasons" />
          <Column
            title="申请类型"
            align="center"
            width={120}
            dataIndex="type"
            render={(value: WorkflowTypes) => WorkflowTypesLocale[value] || '-'}
          />
          <Column
            title="状态"
            dataIndex="status"
            width={150}
            render={(value: WorkflowStatus) => {
              const { color, text } = WorkflowStatusSetting[value];
              return <Badge color={color} text={text} />;
            }}
          />
          <Column
            title="操作"
            align="center"
            width={70}
            render={this.renderOperation}
          />
        </Table>
        {editingCase && (
          <CaseSubscribeDrawer
            visible={drawerVisible}
            caseInfo={editingCase}
            onOk={this.subscribeCase}
            onCancel={this.closeSubscribeDrawer}
          />
        )}
      </ContentPage>
    );
  }
}

const mapStateToProps = (state: RootModelState) => ({
  myApplications: state.workflow.myApplications,
});

const mapDispatchToProps = (dispatch: Dispatch) => ({
  getMyPaginationApplications: (queryParams: CaseApplicationQueryParams) =>
    dispatch({
      type: getDispatchType(
        ModelNamespaces.Workflow,
        'getMyPaginationApplications',
      ),
      payload: queryParams,
    }),
  updateApplication: (
    id: string,
    operation: WorkflowApprovalOperations,
    callback: () => void,
  ) =>
    dispatch({
      type: getDispatchType(ModelNamespaces.Workflow, 'updateApplication'),
      payload: { id, operation },
      callback,
    }),
  applyCaseSubscription: (caseId: string, callback: () => void) =>
    dispatch({
      type: getDispatchType(ModelNamespaces.Workflow, 'addApplication'),
      payload: { caseId, type: WorkflowTypes.Subscription },
      callback,
    }),
  getCaseLatestInquiryDate: (
    caseId: string,
    callback: (latestDate?: Moment) => void,
  ) =>
    dispatch({
      type: getDispatchType(ModelNamespaces.Case, 'getCaseLatestInquiryDate'),
      payload: { caseId },
      callback,
    }),
});

type CaseApplicationPageStateProps = ReturnType<typeof mapStateToProps>;
type CaseApplicationPageDispatchProps = ReturnType<typeof mapDispatchToProps>;

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(CaseApplicationPage);
