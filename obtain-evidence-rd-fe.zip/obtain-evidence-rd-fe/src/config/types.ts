export interface PathConfigItem {
  path: string;
  role?: string;
}

export interface PathConfig {
  [key: string]: PathConfigItem;
}

export interface LayoutConfigItem {
  name: string;
  className?: string;
  disabled?: boolean;
  icon?: string;
  pathConfig: PathConfigItem;
  sideMenus?: Array<{
    name: string;
    pathConfig: PathConfigItem;
    icon?: string;
  }>;
}
