import React, { useMemo, useState } from 'react';
import { downloadFile } from 'cool-utils';
import { EvidenceBase, EvidenceImage, EvidenceRecord } from 'umi';

import { Tabs, Card, Row, Col, Button } from 'antd';
const { TabPane } = Tabs;

import Showcase, { ShowcaseListProps } from '@/components/Showcase';
import styles from './CaseEvidence.less';

interface ImageEvidenceProps {
  inquiree?: EvidenceImage[];
  inquirer?: EvidenceImage[];
  record?: EvidenceRecord;
}

const ImageEvidence: React.FC<ImageEvidenceProps> = props => {
  const { inquiree, inquirer, record } = props;
  const [selectedIndexInquiree, setSelectedIndexInquiree] = useState(0);
  const [selectedIndexInquirer, setSelectedIndexInquirer] = useState(0);
  const [selectedIndexConfirm, setSelectedIndexConfirm] = useState(0);

  const inquireeImages = useMemo<ShowcaseListProps['mediaList']>(
    () =>
      (inquiree || []).map(({ detail }) => ({
        type: 'image',
        src: detail.file.ossFileName,
      })),
    [inquiree],
  );

  const inquirerImages = useMemo<ShowcaseListProps['mediaList']>(
    () =>
      (inquirer || []).map(({ detail }) => ({
        type: 'image',
        src: detail.file.ossFileName,
      })),
    [inquirer],
  );

  const confirmImages = useMemo<ShowcaseListProps['mediaList']>(() => {
    if (!record?.detail) {
      return [];
    }
    const inquireeInfo = Object.values(record.detail.inquired)[0];
    const images = [
      inquireeInfo.confirmImage?.ossFileName,
      inquireeInfo.fingerprintOrigin?.ossFileName,
      inquireeInfo.fingerprint?.ossFileName,
    ]
      .filter(image => !!image)
      .map<ShowcaseListProps['mediaList'][number]>(image => ({
        type: 'image',
        src: image!,
      }));
    return images;
  }, [record?.detail.inquired]);

  const signImage = useMemo(
    () =>
      record?.detail
        ? Object.values(record.detail.inquired)[0].signImage?.ossFileName
        : undefined,
    [record?.detail.inquired],
  );
  return (
    <div className={styles.imageEvidence}>
      <h3>现场示证类型</h3>
      <Tabs type="card" animated>
        <TabPane tab="被询问人示证" key="inquiree">
          <div className={styles.imageEvidenceItem}>
            <Showcase
              mediaList={inquireeImages}
              selectedIndex={selectedIndexInquiree}
              onSelect={setSelectedIndexInquiree}
            />
            {inquiree && inquiree.length > 0 && (
              <div>
                <EvidenceDescription
                  blockchainInfo={
                    inquiree[selectedIndexInquiree].blockchainInfo
                  }
                  signImage={
                    inquiree[selectedIndexInquiree].detail.inquiredSignImage
                      .ossFileName
                  }
                />
                <Button
                  className={styles.downloadButton}
                  onClick={() => {
                    downloadFile(inquireeImages[selectedIndexInquiree].src);
                  }}
                >
                  下载图片
                </Button>
              </div>
            )}
          </div>
        </TabPane>
        <TabPane tab="侦办人员示证" key="inquirer">
          <div className={styles.imageEvidenceItem}>
            <Showcase
              mediaList={inquirerImages}
              selectedIndex={selectedIndexInquirer}
              onSelect={setSelectedIndexInquirer}
            />
            {inquirer && inquirer.length > 0 && (
              <div>
                <EvidenceDescription
                  blockchainInfo={
                    inquirer[selectedIndexInquirer].blockchainInfo
                  }
                />
                <Button
                  className={styles.downloadButton}
                  onClick={() => {
                    downloadFile(inquirerImages[selectedIndexInquirer].src);
                  }}
                >
                  下载图片
                </Button>
              </div>
            )}
          </div>
        </TabPane>
        <TabPane tab="笔录确认" key="confirm">
          <div className={styles.imageEvidenceItem}>
            <Showcase
              mediaList={confirmImages}
              selectedIndex={selectedIndexConfirm}
              onSelect={setSelectedIndexConfirm}
            />
            {record && (
              <div>
                <EvidenceDescription
                  blockchainInfo={record.blockchainInfo}
                  signImage={signImage}
                />
                <Button
                  className={styles.downloadButton}
                  onClick={() => {
                    downloadFile(confirmImages[selectedIndexConfirm].src);
                  }}
                >
                  下载图片
                </Button>
              </div>
            )}
          </div>
        </TabPane>
      </Tabs>
    </div>
  );
};

export default ImageEvidence;

interface EvidenceDescriptionProps {
  blockchainInfo: EvidenceBase['blockchainInfo'];
  signImage?: string;
}

const EvidenceDescription: React.FC<EvidenceDescriptionProps> = props => {
  const { signImage, blockchainInfo } = props;

  return (
    <Card>
      {signImage && (
        <Row align="middle">
          <Col>签字</Col>
          <Col>
            <img src={signImage} height={60} />
          </Col>
        </Row>
      )}
      <Row>区块链认证记录</Row>
      <Row>
        <Col>文件哈希：</Col>
        <Col>{blockchainInfo?.txHash}</Col>
      </Row>
      <Row>
        <Col>签字文件上链时间：</Col>
        <Col>{blockchainInfo?.onlineTime}</Col>
      </Row>
    </Card>
  );
};
