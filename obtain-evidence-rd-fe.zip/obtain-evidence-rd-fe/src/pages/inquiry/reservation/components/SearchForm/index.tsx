import Reservation from './Reservation';
import MyReservation from './MyReservation';

export default {
  Reservation,
  MyReservation,
};
