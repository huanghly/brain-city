import React from 'react';
import { debounce, omit } from 'lodash-es';

import { ReservationQueryParams } from 'umi';
import { SEARCH_FORM_CHANGE_DEBOUNCE } from '@/common/constants';

import { SearchOutlined } from '@ant-design/icons';
import { Form, Input, DatePicker, Button } from 'antd';

interface MyReservationProps {
  onCreate: () => void;
  onChange: (changedValues: Partial<ReservationQueryParams>) => void;
}

const MyReservation: React.FC<MyReservationProps> = props => {
  const { onCreate, onChange } = props;
  const [form] = Form.useForm();

  const debouncedChange = debounce(
    (changedValues: Partial<ReservationQueryParams>) => {
      onChange(changedValues);
    },
    SEARCH_FORM_CHANGE_DEBOUNCE,
  );

  const valuesChange = (_: any, values: Partial<ReservationQueryParams>) => {
    const { keyword, dateTime } = values;

    values.roomKeyword = void 0;
    values.caseKeyword = void 0;
    values.date = dateTime ? dateTime.format('YYYY-MM-DD') : void 0;

    const changedValues: Partial<ReservationQueryParams> = omit(values, [
      'keyword',
      'dateTime',
    ] as Array<keyof ReservationQueryParams>);
    changedValues.current = 1;
    debouncedChange(changedValues);
  };

  const resetFields = () => {
    form.resetFields();
    valuesChange(null, {});
  };

  return (
    <Form
      form={form}
      layout="inline"
      className="g-form-search"
      onValuesChange={valuesChange}
    >
      <Form.Item name="keyword">
        <Input
          suffix={<SearchOutlined />}
          className="g-input-keyword"
          placeholder="请输入关键词，如案事件名称"
        />
      </Form.Item>
      <Form.Item name="dateTime">
        <DatePicker placeholder="请选择" />
      </Form.Item>
      <Form.Item>
        <Button onClick={resetFields}>重置</Button>
      </Form.Item>
      <Form.Item>
        <Button type="primary" onClick={onCreate}>
          新增预约
        </Button>
      </Form.Item>
    </Form>
  );
};

export default MyReservation;
