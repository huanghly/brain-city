import React from 'react';

import { MEETING_HTML_TAGS } from './constants';

const PublishTag: React.FC = () => {
  return (
    <>
      <video
        className="g-fit-contain"
        id={MEETING_HTML_TAGS.PUBLISH_VIDEO_ID}
        autoPlay
        muted
      />
      <label id={MEETING_HTML_TAGS.PUBLISH_STEAMID_ID}></label>
    </>
  );
};

export default React.memo(PublishTag);
