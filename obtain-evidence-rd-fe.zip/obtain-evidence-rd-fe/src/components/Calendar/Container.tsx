import React from 'react';
import classnames from 'classnames';
import { DayItems } from './constants';

import styles from './Calendar.less';

interface CalendarContainerProps {
  className?: string;
  header?: React.ReactNode;
}

const CalendarContainer: React.FC<CalendarContainerProps> = props => {
  const { className, header } = props;

  const cls = classnames({
    [className as string]: !!className,
    [styles.container]: true,
  });
  return (
    <div className={cls}>
      {header && <div className={styles.header}>{header}</div>}
      <div className={styles.content}>
        <div className={styles.left}>
          {DayItems.map(item => (
            <div key={item}>
              <label>{item}</label>
            </div>
          ))}
        </div>
        <div className={styles.right}>{props.children}</div>
      </div>
    </div>
  );
};

export default CalendarContainer;
