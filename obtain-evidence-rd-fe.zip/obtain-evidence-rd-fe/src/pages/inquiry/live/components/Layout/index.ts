import { Layout } from 'antd';

import styles from './Layout.less';
import Sider from 'antd/lib/layout/Sider';

export { default as Layout } from './Layout';
export { default as Header } from './Header';
export { default as Left } from './Left';
export { default as Footer } from './Footer';
export const Content = Layout.Content;

export const Right = Layout.Sider;
