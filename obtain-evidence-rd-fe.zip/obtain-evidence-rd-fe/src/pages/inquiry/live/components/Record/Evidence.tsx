import React, { useState } from 'react';
import { debounce } from 'lodash-es';
import { EvidenceImage } from 'umi';

import {
  PlusOutlined,
  EyeInvisibleOutlined,
  EyeOutlined,
} from '@ant-design/icons';
import { Spin, Upload, Row, Col, Modal, Tag } from 'antd';

import styles from './Record.less';
import { UploadProps } from 'antd/lib/upload';

interface RecordEvidenceProps {
  value?: EvidenceImage[];
  onChange: (files: File[]) => void;
}

const RecordEvidence: React.FC<RecordEvidenceProps> = props => {
  const { value, onChange } = props;
  if (!value) {
    return <Spin />;
  }

  const debouncedChange = debounce(onChange, 300);

  const beforeUpload: UploadProps['beforeUpload'] = (_, fileList) => {
    debouncedChange(fileList);
    return false;
  };

  const [modalVisible, setModalVisible] = useState(false);
  const [selectedEvidence, setSelectedEvidence] = useState<
    EvidenceImage['detail']
  >();

  const selectEvidence = (detail: EvidenceImage['detail']) => {
    setSelectedEvidence(detail);
    setModalVisible(true);
  };

  return (
    <div className={styles.evidence}>
      <div className={styles.upload}>
        <Upload
          showUploadList={false}
          multiple
          accept=".jpg, .jpeg, .png, .bmp"
          beforeUpload={beforeUpload}
        >
          <div className={styles.uploadContent}>
            <PlusOutlined />
            <label>点击上传图片</label>
          </div>
        </Upload>
      </div>
      <div>
        <Row align="middle" justify="space-between">
          <div className={styles.evidenceListTitle}>已发送图片：</div>
          <div>
            <Tag icon={<EyeOutlined />} color="success">
              已读
            </Tag>
            <Tag icon={<EyeInvisibleOutlined />} color="warning">
              未读
            </Tag>
          </div>
        </Row>
        <Row gutter={4}>
          {value.map(({ detail }, idx) => (
            <Col key={idx}>
              <div className={styles.evidenceItem}>
                <img
                  src={detail.file.ossFileName}
                  className={styles.evidenceImage}
                  onClick={() => {
                    selectEvidence(detail);
                  }}
                />
                {detail.confirmedList.length > 0 ? (
                  <Tag icon={<EyeOutlined />} color="success" />
                ) : (
                  <Tag icon={<EyeInvisibleOutlined />} color="warning" />
                )}
              </div>
            </Col>
          ))}
        </Row>
      </div>
      <Modal
        width="50%"
        visible={modalVisible}
        footer={null}
        onCancel={() => {
          setModalVisible(false);
        }}
      >
        <img
          className={styles.evidenceImage}
          src={selectedEvidence?.file?.ossFileName}
        />
      </Modal>
    </div>
  );
};

export default React.memo(RecordEvidence);
