import React from 'react';
import { range, padStart } from 'lodash-es';

import { Row, Col, Popover, Button } from 'antd';
import Cell from './Cell';

import { RoomInfo } from 'umi';
import { DAY_HOURS, DAY_SECTIONS } from '@/common/constants';
import { SECTIONS_WIDTH } from './constants';
const dayHours = range(0, DAY_HOURS + 1);
const daySections = range(0, DAY_SECTIONS);
import { getTimespanFromDaySection } from '@/common/util';

import styles from './index.less';

export type SelectionReservings = [string, number[]];

interface RoomListItemProps {
  room: RoomInfo;
  date: string;
  startIndex?: number;
  periods?: SelectionReservings[1];
  setReservings: (value: SelectionReservings) => void;
  onReserve: (value: SelectionReservings) => void;
}

class RoomListItem extends React.PureComponent<RoomListItemProps> {
  private refUlElem = React.createRef<HTMLUListElement>();

  componentDidMount() {
    this.refUlElem.current?.addEventListener(
      'mousedown',
      this.startSelect,
      false,
    );
    this.refUlElem.current?.addEventListener('click', this.itemClick, false);
  }

  componentWillUnmount() {
    this.refUlElem.current?.removeEventListener(
      'mousedown',
      this.startSelect,
      false,
    );
    this.refUlElem.current?.removeEventListener('click', this.itemClick, false);
  }

  private itemClick = (e: MouseEvent) => {
    e.stopPropagation();
  };

  private computeIndex = (clientX: number) => {
    const left = this.refUlElem.current?.getBoundingClientRect().left || 0;
    const liWidth =
      this.refUlElem.current?.querySelector('li')?.getBoundingClientRect()
        .width || 1;
    const index = Math.floor((clientX - left) / liWidth);
    return index;
  };

  private startSelect = (e: MouseEvent) => {
    console.log('startSelect');
    e.stopImmediatePropagation();
    e.preventDefault();
    const idx = this.computeIndex(e.clientX);
    const { startIndex, room } = this.props;
    if (room.reservedPeriods[idx]) {
      return;
    }
    if (startIndex && idx <= startIndex) {
      return;
    }

    const { setReservings } = this.props;
    this.refUlElem.current?.addEventListener(
      'mousemove',
      this.selectRange,
      false,
    );
    this.refUlElem.current?.addEventListener(
      'mouseup',
      this.finishSelect,
      false,
    );
    console.log('idx: ', idx);
    setReservings([this.props.room.roomId, [idx]]);
  };

  private selectRange = (e: MouseEvent) => {
    console.log('selectRange');
    e.stopImmediatePropagation();
    e.stopPropagation();
    const { periods, setReservings } = this.props;
    let rightIdx = this.computeIndex(e.clientX);
    rightIdx = Math.max(rightIdx, periods ? periods[0] : -Infinity);
    const leftIdx = Math.min(rightIdx, periods ? periods[0] : Infinity);
    const selectedRange = range(leftIdx, rightIdx + 1);
    console.log(selectedRange);
    setReservings([this.props.room.roomId, selectedRange]);
  };

  private finishSelect = (e: MouseEvent) => {
    console.log('finishSelect');
    e.stopImmediatePropagation();
    e.preventDefault();
    this.refUlElem.current?.removeEventListener(
      'mousemove',
      this.selectRange,
      false,
    );
    this.refUlElem.current?.removeEventListener(
      'mouseup',
      this.finishSelect,
      false,
    );
  };

  private confirmReserve = (e: React.MouseEvent) => {
    e.preventDefault();
    const { room, periods: periods, onReserve } = this.props;
    onReserve([room.roomId, periods as number[]]);
  };

  private renderReserving = (idx: number) => {
    const { periods } = this.props;
    if (!periods || periods[0] !== idx) {
      return null;
    }

    const { room, date } = this.props;
    return (
      <Popover
        visible={true}
        placement="topLeft"
        content={
          <div className={styles.popover}>
            <div>已选：{room.roomName}</div>
            <div>
              {date} {getTimespanFromDaySection(periods[0])[0]} -{' '}
              {getTimespanFromDaySection(periods[periods.length - 1])[1]}
            </div>
            <div className="button-group">
              <Button>取消</Button>
              <Button type="primary" onClick={this.confirmReserve}>
                确定
              </Button>
            </div>
          </div>
        }
      >
        <span></span>
      </Popover>
    );
  };

  render() {
    const { startIndex, periods } = this.props;
    const { roomName, reservedPeriods } = this.props.room;

    const ulStyle: React.CSSProperties = { minWidth: SECTIONS_WIDTH };
    return (
      <Row align="middle" className={styles.item}>
        <Col className={styles.name}>{roomName}</Col>
        <Col flex={1} className={styles.schedule}>
          <ul ref={this.refUlElem} className={styles.rects} style={ulStyle}>
            {daySections.map(sectionIdx => (
              <Cell
                key={sectionIdx}
                index={sectionIdx}
                disabled={!!startIndex && sectionIdx <= startIndex}
                reserving={!!periods && periods.includes(sectionIdx)}
                schedule={reservedPeriods[sectionIdx]}
                renderReserving={this.renderReserving}
              />
            ))}
          </ul>
          <ul
            className={styles.labels}
            style={{
              ...ulStyle,
              transform: `translateX(${(-0.5 / DAY_SECTIONS) * 100}%)`,
            }}
          >
            {dayHours.map(idx => (
              <React.Fragment key={idx}>
                <li>{padStart(idx.toString(), 2, '0')}</li>
                {idx < dayHours.length - 2 && <li />}
              </React.Fragment>
            ))}
          </ul>
        </Col>
      </Row>
    );
  }
}

export default RoomListItem;
