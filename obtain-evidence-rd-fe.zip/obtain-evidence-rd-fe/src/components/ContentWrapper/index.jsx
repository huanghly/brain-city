import React from 'react';
import styles from './index.less';

const ContentWrapper = ({
  title,
  children,
  bodyClassName,
  bodyStyle,
  className,
  style,
}) => {
  return (
    <div className={`${styles.container} ${className || ''}`} style={style}>
      <div className={styles.title}>{title}</div>
      <div
        className={`${styles.body} ${bodyClassName || ''}`}
        style={bodyStyle}
      >
        {children}
      </div>
    </div>
  );
};

export default ContentWrapper;
