import React, { useState } from 'react';
import { InquiryRecordLine, InquiryRecordTypes } from 'umi';

import {
  PictureOutlined,
  DeleteOutlined,
  PlusCircleOutlined,
} from '@ant-design/icons';
import { Card, Row, Col, Tooltip, Input, Popover } from 'antd';

import styles from './InquiryCard.less';

interface InquiryNoteCardProps {
  value?: InquiryRecordLine[];
  canEdit?: boolean;
  onEdit?: (value: Partial<InquiryRecordLine>) => void;
  onRemove?: (timestamp: number) => void;
  onAddNewPair?: () => void;
  renderImagePopover?: (lineIdx: number, simple?: boolean) => React.ReactNode;
}

const InquiryNoteCard: React.FC<InquiryNoteCardProps> = props => {
  const {
    value,
    canEdit,
    onEdit,
    onRemove,
    onAddNewPair,
    renderImagePopover,
  } = props;
  const [editingLine, setEditingLine] = useState<number>(-1);
  const [showingIdx, setShowingIdx] = useState<number>(-1);
  const [popoverIdx, setPopoverIdx] = useState(-1);
  const [originLineValue, setOriginLineValue] = useState('');

  const saveRecordLine = (e: any) => {
    if (e.target.value !== originLineValue) {
      const content = e.target.value;
      setEditingLine(-1);
      onEdit && onEdit({ timestamp: editingLine, content });
    }
  };

  const saveOriginLine = (e: any) => {
    setOriginLineValue(e.target.value);
  };

  const pasteAsrMessage = () => {
    document.execCommand('paste');
  };

  const editRecordLine = (timestamp: number) => {
    if (!canEdit) {
      return;
    }
    setEditingLine(timestamp);
  };

  return (
    <Card
      size="small"
      className={styles.record}
      bordered={false}
      title={
        <div>
          <label className={styles.noteTitle}>问答环节</label>
        </div>
      }
    >
      {(value || []).map((record, idx) => (
        <Row key={idx} align="top" className={styles.note}>
          <Col className={styles.mark}>
            {record.type === InquiryRecordTypes.Ask ? '问' : '答'}：
          </Col>
          <Col
            className={styles.noteContent}
            onClick={() => {
              editRecordLine(record.timestamp);
            }}
          >
            {record.timestamp === editingLine ? (
              <Input.TextArea
                autoFocus
                autoSize
                defaultValue={record.content}
                onFocus={saveOriginLine}
                onBlur={saveRecordLine}
                onPressEnter={saveRecordLine}
                onDoubleClick={pasteAsrMessage}
              />
            ) : (
              record.content || <span></span>
            )}
            {!!record.images?.length && (
              <label
                onClick={e => {
                  e.stopPropagation();
                  setShowingIdx(idx);
                }}
              >
                {showingIdx !== idx ? (
                  <>
                    <PictureOutlined />
                    <span>({record.images.length})</span>
                  </>
                ) : (
                  <Popover
                    content={renderImagePopover?.(idx, true)}
                    defaultVisible={true}
                    placement="rightTop"
                    trigger="click"
                    onVisibleChange={visible => !visible && setShowingIdx(-1)}
                  >
                    <>
                      <PictureOutlined />
                      <span>({record.images.length})</span>
                    </>
                  </Popover>
                )}
              </label>
            )}
          </Col>
          {canEdit && (
            <Col className={styles.noteBtn}>
              {popoverIdx !== idx ? (
                <Tooltip title="点击选择关联已上传的示证">
                  <PictureOutlined
                    onClick={() => {
                      setPopoverIdx(idx);
                    }}
                  />
                </Tooltip>
              ) : (
                <Popover
                  content={renderImagePopover?.(idx)}
                  defaultVisible={true}
                  placement="rightTop"
                  trigger="click"
                  onVisibleChange={visible => {
                    !visible && setPopoverIdx(-1);
                  }}
                >
                  <PictureOutlined />
                </Popover>
              )}
              <Tooltip title="删除">
                <DeleteOutlined
                  onClick={() => {
                    onRemove && onRemove(record.timestamp);
                  }}
                />
              </Tooltip>
            </Col>
          )}
        </Row>
      ))}
      {canEdit && (
        <Row justify="end" className={`${styles.note} ${styles.noteBtn}`}>
          <Tooltip title="点击新增一组问答">
            <PlusCircleOutlined onClick={onAddNewPair} />
          </Tooltip>
        </Row>
      )}
    </Card>
  );
};

export default React.memo(InquiryNoteCard);
