import Tabs from './Tabs';
import ImageEvidence from './ImageEvidence';
import VideoEvidence from './VideoEvidence';

export default {
  Tabs,
  ImageEvidence,
  VideoEvidence,
};
