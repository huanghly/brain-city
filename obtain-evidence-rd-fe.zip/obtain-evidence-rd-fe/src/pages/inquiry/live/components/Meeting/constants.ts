import { MeetingRoomConfigParams } from '@/utils/meeting';

export const PUBLISH_VIDEO_ID = 'publish_video_1';
export const PUBLISH_STEAMID_ID = 'publish_streamid_1';
export const PUBLISH_TAG = 'publish_tag_1';

export const SUBSCRIBE_VIDEO_ID = 'subscribe_video_1';
export const SUBSCRIBE_AUDIO_ID = 'subscribe_audio_1';
export const SUBSCRIBE_STREAM_ID = 'subscribe_streamId_1';
export const FEEDID_ID = 'feedid_1';

export const SUBSCRIBE_VIDEO_ID_2 = 'subscribe_video_2';
export const SUBSCRIBE_AUDIO_ID_2 = 'subscribe_audio_2';
export const SUBSCRIBE_STREAM_ID_2 = 'subscribe_streamId_2';
export const FEEDID_ID_2 = 'feedid_1';

export const MEETING_HTML_TAGS = {
  PUBLISH_VIDEO_ID,
  PUBLISH_STEAMID_ID,
  PUBLISH_TAG,

  SUBSCRIBE_VIDEO_ID,
  SUBSCRIBE_AUDIO_ID,
  SUBSCRIBE_STREAM_ID,
  FEEDID_ID,

  SUBSCRIBE_VIDEO_ID_2,
  SUBSCRIBE_AUDIO_ID_2,
  SUBSCRIBE_STREAM_ID_2,
  FEEDID_ID_2,
};

export const DEFAULT_ROOM_CONFIG_PARAMS: Pick<
  MeetingRoomConfigParams,
  'initPublish' | 'initSubscribe'
> = {
  initPublish: [
    {
      publish_video_id: PUBLISH_VIDEO_ID,
      publish_stream_id: PUBLISH_STEAMID_ID,
      publish_tag: PUBLISH_TAG,
    },
  ],
  initSubscribe: [
    {
      subscribe_video_id: SUBSCRIBE_VIDEO_ID,
      subscribe_audio_id: SUBSCRIBE_AUDIO_ID,
      subscribe_streamId_id: SUBSCRIBE_STREAM_ID,
      feedId_id: FEEDID_ID,
    },

    {
      subscribe_video_id: SUBSCRIBE_VIDEO_ID_2,
      subscribe_audio_id: SUBSCRIBE_AUDIO_ID_2,
      subscribe_streamId_id: SUBSCRIBE_STREAM_ID_2,
      feedId_id: FEEDID_ID_2,
    },
  ],
};
