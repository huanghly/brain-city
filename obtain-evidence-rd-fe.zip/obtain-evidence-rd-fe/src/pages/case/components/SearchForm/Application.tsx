import React from 'react';
import { debounce, omit } from 'lodash-es';
import {
  CaseApplicationQueryParams,
  WorkflowTypes,
  WorkflowTypesLocale,
} from 'umi';
import { SEARCH_FORM_CHANGE_DEBOUNCE } from '@/common/constants';

import { SearchOutlined } from '@ant-design/icons';
import { Form, Input, DatePicker, Button, Select } from 'antd';
const { Option } = Select;

interface SearchFormProps {
  onChange: (changedValues: Partial<CaseApplicationQueryParams>) => void;
}

const SearchForm: React.FC<SearchFormProps> = props => {
  const { onChange } = props;
  const [form] = Form.useForm();

  const valuesChange = debounce(
    (_, values: Partial<CaseApplicationQueryParams>) => {
      const { date } = values;
      if (date) {
        values.applicationDate = date.format('YYYY-MM-DD');
      }
      const changedValues = omit(values, ['date'] as Array<
        keyof CaseApplicationQueryParams
      >);
      onChange(changedValues);
    },
    SEARCH_FORM_CHANGE_DEBOUNCE,
  );

  const resetFields = () => {
    form.resetFields();
    valuesChange(null, {});
  };

  return (
    <Form
      className="g-form-search"
      form={form}
      layout="inline"
      onValuesChange={valuesChange}
    >
      <Form.Item name="keyword">
        <Input
          className="g-input-keyword"
          suffix={<SearchOutlined />}
          placeholder="请输入关键词，如案事件名称"
        />
      </Form.Item>
      <Form.Item name="type">
        <Select placeholder="申请类型">
          <Option value={WorkflowTypes.Subscription}>
            {WorkflowTypesLocale[WorkflowTypes.Subscription]}
          </Option>
          <Option value={WorkflowTypes.Merging}>
            {WorkflowTypesLocale[WorkflowTypes.Merging]}
          </Option>
        </Select>
      </Form.Item>
      <Form.Item name="date">
        <DatePicker />
      </Form.Item>
      <Form.Item>
        <Button onClick={resetFields}>重置</Button>
      </Form.Item>
    </Form>
  );
};

export default SearchForm;
