import React, { useState } from 'react';
import { Drawer, Button } from 'antd';

import Signature from '@/components/Signature';

interface SignatureDrawerProps {
  visible: boolean;
  onOk: (blob: Blob) => void;
  onCancel: () => void;
}

const SignatureDrawer: React.FC<SignatureDrawerProps> = props => {
  const { visible, onOk, onCancel } = props;
  const [saveSignal, setSaveSignal] = useState(false);

  const save = () => {
    setSaveSignal(!saveSignal);
  };

  return (
    <Drawer
      title="签名"
      width="100%"
      visible={visible}
      bodyStyle={{ display: 'flex', justifyContent: 'stretch' }}
      footer={
        <div className="button-group">
          <Button type="primary" onClick={save}>
            确定
          </Button>
          <Button onClick={onCancel}>取消</Button>
        </div>
      }
    >
      <Signature
        containerStyle={{ background: '#fff' }}
        finish={saveSignal}
        onOk={onOk}
      />
    </Drawer>
  );
};

export default SignatureDrawer;
