export enum RoomStatus {
  Available,
  Unavailable,
  Reserved,
}

export enum ModelNamespaces {
  User = 'user',
  Reservation = 'reservation',
  Inquiry = 'inquiry',
  Case = 'case',
  Evidence = 'evidence',
  OSS = 'OSS',
  Download = 'download',
  Workflow = 'workflow',
  Analysis = 'analysis',
}

export enum ReservationStatus {
  NotStarted = 0,
  Finished = -1,
  Inquiring = 0b111,
  // 记录人、询问人、被询问人
  RecorderEntered = 0b100,
  InquirerEntered = 0b010,
  InquireeEntered = 0b001,
}

export const ReservationStatusSetting = {
  [ReservationStatus.NotStarted]: {
    text: '未开始',
    color: null,
  },
  [ReservationStatus.Inquiring]: {
    text: '询问中',
    color: '#1e8e3e',
  },
  [ReservationStatus.Finished]: {
    text: '已结束',
    color: '#ccc',
  },
  [ReservationStatus.RecorderEntered]: {
    text: '准备中',
    color: '#d93026',
  },
  [ReservationStatus.InquirerEntered]: {
    text: '准备中',
    color: '#d93026',
  },
  [ReservationStatus.InquireeEntered]: {
    text: '准备中',
    color: '#d93026',
  },
};

export const DefaultReservationStatus = { text: '准备中', color: '#d93026' };

export enum CaseQueryTypes {
  All = 'all',
  My = 'my',
  Subscription = 'subscription',
}

export enum CaseAuthTypes {
  NoAuth = 0b0001,
  LookUp = 0b0010,
  Edit = 0b0110,
  Delete = 0b1110,
}

export enum InquiryIdentityTypes {
  None = 0,
  Inquirer = 1,
  Recorder = 2,
  WomanInquirer = 3,
  Victim = 4,
  Witness = 5,
  Suspect = 6,
  Guardian = 7,
}

export const InquirerIdentityTypesLocale = {
  [InquiryIdentityTypes.Inquirer]: '询问人',
  [InquiryIdentityTypes.Recorder]: '记录人',
  [InquiryIdentityTypes.WomanInquirer]: '女性询问人',
};

export const InquiredIdentityTypesLocale = {
  [InquiryIdentityTypes.Victim]: '受害人',
  [InquiryIdentityTypes.Witness]: '证人',
  [InquiryIdentityTypes.Suspect]: '嫌疑人',
};

export enum InquirerRoles {
  None = 0,
  Inquirer = 1,
  Recorder = 2,
  InquirerRecorder = 3,
}

export enum InquiryRecordTypes {
  Ask = 1,
  Answer = 2,
}

export enum EvidenceFrom {
  Inquiree = 1,
  Inquirer = 2,
}

export enum EvidenceTypes {
  Image = 1,
  Record = 2,
  Video = 3,
  Screen = 4,
}

export enum RecordDownloadStatus {
  NotFound = 1,
  Fail = 2,
  Building = 3,
  Done = 4,
}

export enum WorkflowTypes {
  Subscription = 1,
  Merging = 2,
}

export const WorkflowTypesLocale = {
  [WorkflowTypes.Subscription]: '调阅',
  [WorkflowTypes.Merging]: '并案',
};

export enum WorkflowStatus {
  New = 1,
  Approved,
  Rejected,
  Revoked,
  Canceled,
}

export const WorkflowStatusSetting = {
  [WorkflowStatus.New]: {
    text: '待审批',
    color: '#e9883b',
  },
  [WorkflowStatus.Approved]: {
    text: '已同意',
    color: '#43a566',
  },
  [WorkflowStatus.Rejected]: {
    text: '已拒绝',
    color: '#e12c2c',
  },
  [WorkflowStatus.Revoked]: {
    text: '已撤回',
    color: '#e12c2c',
  },
  [WorkflowStatus.Canceled]: {
    text: '已撤回',
    color: '#e12c2c',
  },
};

export enum WorkflowApprovalOperations {
  Resolve,
  Reject,
  Revoke,
  Cancel,
  Restart,
}
