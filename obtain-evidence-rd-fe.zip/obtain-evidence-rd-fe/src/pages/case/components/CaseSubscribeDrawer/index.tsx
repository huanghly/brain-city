import React from 'react';
import { Case } from 'umi';

import { Drawer, Button, Form, Input } from 'antd';
import DescriptionCard from '@/components/DescriptionCard';

import styles from './CaseSubscribeDrawer.less';

interface CaseSubscribeDrawerProps {
  visible: boolean;
  caseInfo: Partial<Case>;
  onOk: () => void;
  onCancel: () => void;
}

const CaseSubscribeDrawer: React.FC<CaseSubscribeDrawerProps> = props => {
  const { visible, caseInfo, onOk, onCancel } = props;
  const [form] = Form.useForm();

  const resetFields = (isOpen: boolean) => {
    if (!isOpen) {
      form.resetFields();
    }
  };

  return (
    <Drawer
      visible={visible}
      title="案事件卷宗调阅申请"
      width={640}
      onClose={onCancel}
      afterVisibleChange={resetFields}
      footer={
        <div className="button-group">
          <Button type="primary" onClick={form.submit}>
            确定
          </Button>
          <Button onClick={onCancel}>取消</Button>
        </div>
      }
    >
      <DescriptionCard className={styles.gap}>
        <DescriptionCard.Title>{caseInfo.title}</DescriptionCard.Title>
        <DescriptionCard.Subtitle>
          申请时间：{caseInfo.createDate}
        </DescriptionCard.Subtitle>
        <DescriptionCard.Subtitle>
          审批人：{caseInfo.dutyUserName}
        </DescriptionCard.Subtitle>
      </DescriptionCard>

      <Form form={form} onFinish={onOk}>
        <Form.Item
          label="申请事由"
          name="reasons"
          rules={[{ required: true }]}
          labelCol={{ span: 24 }}
        >
          <Input.TextArea placeholder="请输入..." rows={5} />
        </Form.Item>
      </Form>
    </Drawer>
  );
};

export default CaseSubscribeDrawer;
