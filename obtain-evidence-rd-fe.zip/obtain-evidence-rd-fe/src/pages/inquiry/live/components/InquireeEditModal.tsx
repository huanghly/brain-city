import React, { useEffect, useState } from 'react';
import moment, { Moment } from 'moment';
import { v4 as uuidv4 } from 'uuid';
import {
  EvidenceRecord,
  InquiryIdentityTypes,
  InquiryMapIdentity,
  InquireeCertificateType,
  InquiredIdentityTypesLocale,
  EvidenceRecordInquiree,
  getInquireeIdentityIdByMapIdentity,
} from 'umi';

import {
  Modal,
  Form,
  Input,
  Select,
  Checkbox,
  Row,
  Col,
  DatePicker,
} from 'antd';
const { Option } = Select;
import { FormItemProps, FormProps } from 'antd/lib/form';
import { SelectProps } from 'antd/lib/select';

const modalWidth = 360;
const formItemLayout: Partial<FormItemProps> = {
  labelCol: { span: 8 },
  wrapperCol: { span: 16 },
};

const certificationTypes: InquireeCertificateType[] = [
  '居民身份证',
  '士官证',
  '学生证',
  '驾驶证',
  '护照',
  '港澳通行证',
];
const certificationTypeOptions: SelectProps<
  InquireeCertificateType
>['options'] = certificationTypes.map(type => ({ label: type, value: type }));

const identityTypeOptions: SelectProps<
  InquiryIdentityTypes
>['options'] = Object.entries(
  InquiredIdentityTypesLocale,
).map(([value, text]) => ({ label: text, value: +value }));

const generateFormItemName = (
  modelIndex: number,
  fieldName: keyof EvidenceRecordInquiree,
) => ['models', modelIndex, fieldName];

interface InquireeEditModalProps {
  visible: boolean;
  value?: EvidenceRecord['detail']['inquired'];
  mapIdentity: InquiryMapIdentity;
  onSave: (value: EvidenceRecord['detail']['inquired']) => void;
  onCancel: () => void;
}

const InquireeEditModal: React.FC<InquireeEditModalProps> = props => {
  const { visible, value, mapIdentity, onSave, onCancel } = props;
  const [form] = Form.useForm();
  const currentInquireeIdentityId = getInquireeIdentityIdByMapIdentity(
    mapIdentity,
  )!;
  const currentGuardianIdentityId =
    mapIdentity[InquiryIdentityTypes.Guardian]?.[0];
  const [additionInfoVisible, setAdditionInfoVisible] = useState(false);

  useEffect(() => {
    setAdditionInfoVisible(
      !value ? false : value[currentInquireeIdentityId].adult === '未成年',
    );
  }, [value, currentInquireeIdentityId]);

  useEffect(() => {
    if (visible && value) {
      const fieldsValue = {
        models: [
          {
            ...value[currentInquireeIdentityId],
            birth:
              value[currentInquireeIdentityId].birth &&
              moment(value[currentInquireeIdentityId].birth),
          },
        ],
      };
      if (currentGuardianIdentityId) {
        fieldsValue.models.push({
          ...value[currentGuardianIdentityId],
          birth:
            value[currentGuardianIdentityId] &&
            moment(value[currentGuardianIdentityId].birth),
        });
      }
      form.setFieldsValue(fieldsValue);
    }
  }, [
    visible,
    additionInfoVisible,
    value,
    currentInquireeIdentityId,
    currentGuardianIdentityId,
  ]);

  const finish: FormProps['onFinish'] = (value: {
    models: EvidenceRecordInquiree[];
  }) => {
    value.models.forEach(val => {
      if (val.birth) {
        // @ts-ignore
        val.birth = (val.birth as Moment).format('YYYY-MM-DD');
      }
      if (!val.identityId) {
        val.identityId = uuidv4();
      }
    });
    const partialValue = value.models.reduce<{
      [identityId: string]: EvidenceRecordInquiree;
    }>((obj, val) => {
      obj[val.identityId] = val;
      return obj;
    }, {});
    onSave(partialValue);
  };

  return (
    <Modal
      title="修改被询问人信息"
      visible={visible}
      maskClosable={false}
      width={additionInfoVisible ? modalWidth * 2 : modalWidth}
      afterClose={form.resetFields}
      onOk={form.submit}
      onCancel={onCancel}
    >
      <Form labelAlign="right" form={form} onFinish={finish}>
        <Row gutter={16}>
          <Col span={additionInfoVisible ? 12 : 24}>
            <Form.Item hidden name={generateFormItemName(0, 'identityId')}>
              <Input />
            </Form.Item>
            <Form.Item
              name={generateFormItemName(0, 'userName')}
              label="姓名"
              rules={[{ required: true }]}
              {...formItemLayout}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name={generateFormItemName(0, 'gender')}
              label="性别"
              initialValue="男"
              {...formItemLayout}
            >
              <Select>
                <Option value="男">男</Option>
                <Option value="女">女</Option>
              </Select>
            </Form.Item>
            <Form.Item
              name={generateFormItemName(0, 'adult')}
              label="是否成年"
              initialValue="成年"
              {...formItemLayout}
            >
              <Select
                onChange={value => setAdditionInfoVisible(value === '未成年')}
              >
                <Option value="成年">成年</Option>
                <Option value="未成年">未成年</Option>
              </Select>
            </Form.Item>
            <Form.Item
              name={generateFormItemName(0, 'birth')}
              label="出生日期"
              {...formItemLayout}
            >
              <DatePicker
                disabledDate={current =>
                  current && current >= moment().endOf('day')
                }
              />
            </Form.Item>
            <Form.Item
              name={generateFormItemName(0, 'nationality')}
              label="国籍"
              {...formItemLayout}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name={generateFormItemName(0, 'nation')}
              label="民族"
              {...formItemLayout}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name={generateFormItemName(0, 'certType')}
              label="证件类型"
              rules={[{ required: true }]}
              initialValue="居民身份证"
              {...formItemLayout}
            >
              <Select options={certificationTypeOptions} />
            </Form.Item>
            <Form.Item
              name={generateFormItemName(0, 'certNo')}
              label="证件号"
              {...formItemLayout}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name={generateFormItemName(0, 'education')}
              label="教育程度"
              rules={[{ required: true }]}
              {...formItemLayout}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name={generateFormItemName(0, 'political')}
              label="政治面貌"
              rules={[{ required: true }]}
              {...formItemLayout}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name={generateFormItemName(0, 'isDeputy')}
              label="是否人大代表"
              valuePropName="checked"
              {...formItemLayout}
            >
              <Checkbox />
            </Form.Item>
            <Form.Item
              name={generateFormItemName(0, 'phoneNo')}
              label="联系电话"
              rules={[{ required: true }]}
              {...formItemLayout}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name={generateFormItemName(0, 'householdAddress')}
              label="家庭住址"
              rules={[{ required: true }]}
              {...formItemLayout}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name={generateFormItemName(0, 'workAddress')}
              label="工作单位"
              {...formItemLayout}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name={generateFormItemName(0, 'identityType')}
              label="涉案身份"
              rules={[{ required: true }]}
              {...formItemLayout}
            >
              <Select options={identityTypeOptions} />
            </Form.Item>
          </Col>
          {additionInfoVisible && (
            <Col span={12}>
              <Form.Item hidden name={generateFormItemName(0, 'identityId')}>
                <Input />
              </Form.Item>
              <Form.Item
                name={generateFormItemName(1, 'userName')}
                label="姓名"
                rules={[{ required: true }]}
                {...formItemLayout}
              >
                <Input />
              </Form.Item>
              <Form.Item
                name={generateFormItemName(1, 'gender')}
                label="性别"
                initialValue="男"
                rules={[{ required: true }]}
                {...formItemLayout}
              >
                <Select>
                  <Option value="男">男</Option>
                  <Option value="女">女</Option>
                </Select>
              </Form.Item>
              <Form.Item
                name={generateFormItemName(1, 'adult')}
                label="是否成年"
                initialValue="成年"
                {...formItemLayout}
              >
                <Select>
                  <Option value="成年">成年</Option>
                  <Option value="未成年">未成年</Option>
                </Select>
              </Form.Item>
              <Form.Item
                name={generateFormItemName(1, 'birth')}
                label="出生日期"
                {...formItemLayout}
              >
                <DatePicker
                  disabledDate={current =>
                    current && current >= moment().endOf('day')
                  }
                />
              </Form.Item>
              <Form.Item
                name={generateFormItemName(1, 'nationality')}
                label="国籍"
                {...formItemLayout}
              >
                <Input />
              </Form.Item>
              <Form.Item
                name={generateFormItemName(1, 'nation')}
                label="民族"
                {...formItemLayout}
              >
                <Input />
              </Form.Item>
              <Form.Item
                name={generateFormItemName(1, 'certType')}
                label="证件类型"
                rules={[{ required: true }]}
                initialValue="居民身份证"
                {...formItemLayout}
              >
                <Select options={certificationTypeOptions} />
              </Form.Item>
              <Form.Item
                name={generateFormItemName(1, 'certNo')}
                label="证件号"
                rules={[{ required: true }]}
                {...formItemLayout}
              >
                <Input />
              </Form.Item>
              <Form.Item
                name={generateFormItemName(1, 'education')}
                label="教育程度"
                rules={[{ required: true }]}
                {...formItemLayout}
              >
                <Input />
              </Form.Item>
              <Form.Item
                name={generateFormItemName(1, 'political')}
                label="政治面貌"
                rules={[{ required: true }]}
                {...formItemLayout}
              >
                <Input />
              </Form.Item>
              <Form.Item
                name={generateFormItemName(1, 'isDeputy')}
                label="是否人大代表"
                valuePropName="checked"
                {...formItemLayout}
              >
                <Checkbox />
              </Form.Item>
              <Form.Item
                name={generateFormItemName(1, 'phoneNo')}
                label="联系电话"
                rules={[{ required: true }]}
                {...formItemLayout}
              >
                <Input />
              </Form.Item>
              <Form.Item
                name={generateFormItemName(1, 'householdAddress')}
                label="家庭住址"
                rules={[{ required: true }]}
                {...formItemLayout}
              >
                <Input />
              </Form.Item>
              <Form.Item
                name={generateFormItemName(1, 'workAddress')}
                label="工作单位"
                {...formItemLayout}
              >
                <Input />
              </Form.Item>
              <Form.Item
                name={generateFormItemName(1, 'identityType')}
                label="涉案身份"
                rules={[{ required: true }]}
                initialValue={InquiryIdentityTypes.Guardian}
                {...formItemLayout}
              >
                <Select>
                  <Option value={InquiryIdentityTypes.Guardian}>监护人</Option>
                </Select>
              </Form.Item>
            </Col>
          )}
        </Row>
      </Form>
    </Modal>
  );
};

export default InquireeEditModal;
