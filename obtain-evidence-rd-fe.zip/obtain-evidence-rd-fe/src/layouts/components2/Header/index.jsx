import { Divider, Dropdown, Menu } from 'antd';
import PropTypes from 'prop-types';
import { history } from 'umi';
import layoutConfig from 'config/layoutConfig';
import styles from './index.less';

const Header = ({ userType, handleClick, activePath, onLogout, nickName }) => {
  return (
    <div className={styles.header}>
      <div className={styles.left}>
        <div
          className={styles.title}
          role="button"
          onClick={() => {
            history.push('/interrogationManagement');
          }}
        >
          <img src={`${process.env.PUBLIC_PATH}logo.svg`} alt="" />
          <span>云上询问</span>
        </div>
        <Divider type="vertical" className={styles.divider} />
        <div className={styles.nav}>
          {layoutConfig().map(({ name, path: { path } }) => {
            return (
              <span
                role="button"
                key={path}
                className={`${styles.item} ${
                  path === activePath ||
                  history.location.pathname.startsWith(path)
                    ? styles.itemActive
                    : ''
                }`}
                onClick={() => {
                  handleClick(path);
                }}
              >
                {name}
              </span>
            );
          })}
        </div>
      </div>
      <div className={styles.right}>
        <Dropdown
          overlay={
            <Menu theme="dark">
              <div
                className={styles.menu}
                onClick={() => {
                  console.log(1234);
                }}
                role="button"
              >
                修改密码
              </div>
              <div className={styles.menu} onClick={onLogout} role="button">
                退出登录
              </div>
            </Menu>
          }
          placement="bottomLeft"
          getPopupContainer={triggerNode => triggerNode.parentNode}
        >
          <div className={styles.user}>
            <span>办案人员：张三</span>
            <i className={`iconfont icon-sort-down ${styles.icon}`} />
          </div>
        </Dropdown>
      </div>
    </div>
  );
};

Header.propTypes = {
  userType: PropTypes.string,
  activePath: PropTypes.string,
  handleClick: PropTypes.func,
  onLogout: PropTypes.func,
  nickName: PropTypes.string,
};

export default Header;
