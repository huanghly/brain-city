import { ModelNamespaces, Effect, ImmerReducer, Subscription } from 'umi';

export interface AnalysisModelState {
  pieData: { type: string; value: number }[];
  mapData: { x: number; y: number; x1: number; y1: number }[];
  statisticData: { [key: string]: number };
}

export interface AnalysisModelType {
  namespace: ModelNamespaces.Analysis;
  state: AnalysisModelState;
  effects: {
    getSatisticsResult: Effect;
    getPieData: Effect;
    getMapData: Effect;
  };
  reducers: {
    save: ImmerReducer<AnalysisModelState>;
  };
  subscriptions: { setup: Subscription };
}
