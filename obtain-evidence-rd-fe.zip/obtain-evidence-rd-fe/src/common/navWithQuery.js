import history from 'utils/history';

export default path => {
  const { query } = history.location;
  history.push(
    typeof path === 'object'
      ? {
          ...path,
          query: {
            appId: query.appId,
            ...path.query,
          },
        }
      : { pathname: path, query: { appId: query.appId } },
  );
};
