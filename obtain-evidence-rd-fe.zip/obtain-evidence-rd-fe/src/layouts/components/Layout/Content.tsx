import React from 'react';

import { Layout } from 'antd';
const { Content } = Layout;

const PortalContent: React.FC = props => {
  return <Content>{props.children}</Content>;
};

export default PortalContent;
