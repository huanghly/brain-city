import React, { useEffect, useRef, useState } from 'react';
import { padStart } from 'lodash-es';
import styles from './Layout.less';

import { CloseOutlined } from '@ant-design/icons';
import { Layout, Badge } from 'antd';
const { Header } = Layout;

interface LiveHeaderProps {
  caseName?: string;
  started?: boolean;
  onClose: () => void;
}

const LiveHeader: React.FC<LiveHeaderProps> = props => {
  const { caseName, started, onClose } = props;
  const timer = useRef<number>();
  const [durationSeconds, setDurationSeconds] = useState(0);

  useEffect(() => {
    if (timer.current) {
      clearInterval(timer.current);
    }
    if (started) {
      timer.current = window.setInterval(() => {
        setDurationSeconds(d => d + 1);
      }, 1000);
    }
  }, [started]);

  useEffect(() => {
    return () => {
      if (timer.current) {
        window.clearInterval(timer.current);
      }
    };
  }, []);

  return (
    <Header className={styles.header}>
      <div className={styles.title}>
        <i className="iconfont icon-meeting" />
        <h1>{caseName}</h1>
      </div>
      <div className={styles.recorder}>
        <label>同步录音录像</label>
        <Badge color={durationSeconds === 0 ? 'red' : 'green'} />
        <label>
          {padStart(Math.floor(durationSeconds / 60).toString(), 2, '0')}:
          {padStart((durationSeconds % 60).toString(), 2, '0')}
        </label>
      </div>
      <div className={styles.close}>
        <CloseOutlined onClick={onClose} />
      </div>
    </Header>
  );
};

export default React.memo(LiveHeader);
