import React from 'react';
import moment from 'moment';
import { omit } from 'lodash-es';
import { UserInfo, ReservationSubmit, CaseBase } from 'umi';

import { ClockCircleOutlined } from '@ant-design/icons';
import { Drawer, Button, Form, Row, Input, Select } from 'antd';
const { Option } = Select;
import { FormItemProps, FormProps } from 'antd/lib/form';

import { DEFAULT_SPLITTER } from '@/common/constants';
import { getTimespanFromDaySection } from '@/common/util';

import styles from './ReservationDrawer.less';

interface ReservationDrawerProps {
  visible: boolean;
  reservation?: Partial<ReservationSubmit>;
  users: UserInfo[];
  cases: CaseBase[];
  onSearchCase: (caseName: string) => void;
  onSearchCaseUsers: (caseId: string) => void;
  onCreateCase: () => void;
  onClose: () => void;
  onSave: (values: Partial<ReservationSubmit>) => void;
}

const formItemLayout: Partial<FormItemProps> = {
  labelCol: { span: 6 },
  wrapperCol: { span: 18 },
};

const ReservationDrawer: React.FC<ReservationDrawerProps> = props => {
  const {
    visible,
    reservation,
    users,
    cases,
    onSearchCase,
    onSearchCaseUsers,
    onCreateCase,
    onClose,
    onSave,
  } = props;
  const [form] = Form.useForm();

  const resetFields = (isOpen: boolean) => {
    if (!isOpen) {
      form.resetFields();
    }
  };

  const save: FormProps['onFinish'] = values => {
    const [caseId, caseName] = values.caseInfo.split(DEFAULT_SPLITTER);
    const [inquirerId, inquirerName] = values.inquirer.split(DEFAULT_SPLITTER);
    const [recorderId, recorderName] = values.recorder.split(DEFAULT_SPLITTER);
    values = {
      ...values,
      caseId,
      caseName,
      inquirerId,
      inquirerName,
      recorderId,
      recorderName,
    };
    const reservationValues = omit(values, [
      'caseInfo',
      'inquirer',
      'recorder',
    ]);
    onSave(reservationValues);
  };

  const userOptions = users.map(({ userId, userName }) => {
    return (
      <Option key={userId} value={`${userId}${DEFAULT_SPLITTER}${userName}`}>
        {userName}
      </Option>
    );
  });

  const selectCase = (value: string) => {
    const caseId = value.split(DEFAULT_SPLITTER)[0];
    onSearchCaseUsers(caseId);
  };

  return (
    <Drawer
      title="预定询问室"
      width={640}
      visible={visible}
      afterVisibleChange={resetFields}
      footer={
        <div className="button-group">
          <Button type="primary" onClick={form.submit}>
            确定
          </Button>
          <Button onClick={onClose}>取消</Button>
        </div>
      }
      onClose={onClose}
    >
      {reservation && (
        <div className={styles.info}>
          <div className={styles.title}>{reservation.roomName}</div>
          <div className={styles.duration}>
            <ClockCircleOutlined />
            <label>
              {moment(reservation.date).format('YYYY年MM月DD日')}（
              {getTimespanFromDaySection(reservation.periods![0])[0]}-
              {
                getTimespanFromDaySection(
                  reservation.periods![reservation.periods!.length - 1],
                )[1]
              }
              ）
            </label>
          </div>
        </div>
      )}
      <Form form={form} labelAlign="left" onFinish={save}>
        <Form.Item
          label="案事件名称"
          name="caseInfo"
          {...formItemLayout}
          rules={[{ required: true, message: '请选择所负责案事件' }]}
        >
          <Select
            placeholder="输入关键词搜索"
            showSearch
            onSearch={onSearchCase}
            onSelect={selectCase}
            notFoundContent={
              <Row align="middle" justify="start">
                <Button size="small" type="link" onClick={onCreateCase}>
                  未找到案事件？点击新建
                </Button>
              </Row>
            }
          >
            {cases.map(({ id, title }) => (
              <Select.Option
                key={id}
                value={`${id}${DEFAULT_SPLITTER}${title}`}
                label={title}
              >
                {title}
              </Select.Option>
            ))}
          </Select>
        </Form.Item>
        <Form.Item
          label="被询问人"
          name="inquiredName"
          {...formItemLayout}
          rules={[{ required: true, message: '请填写被询问人' }]}
        >
          <Input placeholder="请填写被询问人" />
        </Form.Item>
        <Form.Item
          label="被询问人手机号"
          name="inquiredPhone"
          {...formItemLayout}
          rules={[{ required: true, message: '请填写被询问人手机号' }]}
        >
          <Input placeholder="请填写被询问人手机号" />
        </Form.Item>
        <Form.Item
          label="询问人"
          name="inquirer"
          {...formItemLayout}
          rules={[{ required: true, message: '请选择询问人' }]}
        >
          <Select placeholder="请选择">{userOptions}</Select>
        </Form.Item>
        <Form.Item
          label="记录人"
          name="recorder"
          {...formItemLayout}
          rules={[{ required: true, message: '请选择记录人' }]}
        >
          <Select placeholder="请选择">{userOptions}</Select>
        </Form.Item>
      </Form>
    </Drawer>
  );
};

export default ReservationDrawer;
