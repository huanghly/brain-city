import React, { useMemo, useState } from 'react';
import { EvidenceVideo } from 'umi';
import { downloadFile } from 'cool-utils';
import { Button } from 'antd';
import ShowcaseList, { ShowcaseListProps } from '@/components/Showcase';
import styles from './CaseEvidence.less';

interface VideoEvidenceProps {
  value?: EvidenceVideo | EvidenceVideo[];
}

const VideoEvidence: React.FC<VideoEvidenceProps> = props => {
  const [selectedIndex, setSelectedIndex] = useState(0);
  const videos = useMemo<ShowcaseListProps['mediaList']>(
    () =>
      !props.value
        ? []
        : Array.isArray(props.value)
        ? props.value.map(val => ({ type: 'video', src: val.detail.fileName }))
        : [{ type: 'video', src: props.value?.detail.fileName }],
    [props.value],
  );

  return (
    <div className={styles.videoEvidenceItem}>
      <ShowcaseList
        mediaList={videos}
        selectedIndex={selectedIndex}
        onSelect={setSelectedIndex}
      />
      {videos[selectedIndex]?.src && (
        <Button
          className={styles.downloadButton}
          onClick={() => {
            downloadFile(videos[selectedIndex].src);
          }}
        >
          下载视频
        </Button>
      )}
    </div>
  );
};

export default VideoEvidence;
