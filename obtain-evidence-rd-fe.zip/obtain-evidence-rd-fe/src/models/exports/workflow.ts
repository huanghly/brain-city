import {
  ModelNamespaces,
  Effect,
  ImmerReducer,
  Subscription,
  WorkflowTypes,
  WorkflowStatus,
} from 'umi';
import { Moment } from 'moment';

export type CaseApplication = {
  id: string;
  caseId: string;
  caseName: string;
  applicant: string;
  approver: string;
  applicationDate: string;
  reasons: string;
  type: WorkflowTypes;
  status: WorkflowStatus;
};

export type CaseApplicationQueryParams = {
  keyword?: string;
  type?: WorkflowTypes;
  status?: WorkflowStatus;
  applicationDate?: string;
  date?: Moment;
  pageSize?: number;
  current?: number;
};

export interface WorkflowModelState {
  newApplications: PaginationModel<CaseApplication>;
  handledApplications: PaginationModel<CaseApplication>;
  myApplications: PaginationModel<CaseApplication>;
}

export interface WorkflowModelType {
  namespace: ModelNamespaces.Workflow;
  state: WorkflowModelState;
  effects: {
    getNewPaginationApplications: Effect;
    getHandledPaginationApplications: Effect;
    getMyPaginationApplications: Effect;

    addApplication: Effect;
    updateApplication: Effect;
  };
  reducers: {
    save: ImmerReducer<WorkflowModelState>;
  };
  subscriptions: { setup: Subscription };
}
