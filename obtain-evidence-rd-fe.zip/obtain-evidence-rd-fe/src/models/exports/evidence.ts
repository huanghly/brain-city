import {
  Effect,
  ImmerReducer,
  Subscription,
  ModelNamespaces,
  OSSFileInfo,
  EvidenceTypes,
  EvidenceFrom,
  InquiryIdentityTypes,
  InquiryRecordLine,
  InquirerRoles,
} from 'umi';

export interface EvidenceBase {
  id: string;
  inquiryId: number;
  type: EvidenceTypes;
  evidenceFrom: EvidenceFrom;
  gmtCreate?: string;

  blockchainInfo?: {
    txHash: string;
    onlineTime: string;
  };
}

export interface EvidenceVideo extends EvidenceBase {
  detail: { fileName: string; ossFileName: string; recordId: string };
}

export interface EvidenceImage extends EvidenceBase {
  detail: {
    file: OSSFileInfo;
    inquiredSignImage: OSSFileInfo;
    confirmedList: Array<{
      userId: string;
      userName: string;
      confirmedTime: string;
    }>;
  };
}

export type EvidenceRecordBasicInfo = {
  date: string;
  startTime: string;
  endTime: string;

  inquiryLocation: string;
  caseName: string;
  reservationId: string;

  inquirerId: string;
  inquirerName: string;
  inquirerDepartment: string;

  recorderId: string;
  recorderName: string;
  recorderDepartment: string;
};

export type InquireeCertificateType =
  | '居民身份证'
  | '士官证'
  | '学生证'
  | '驾驶证'
  | '护照'
  | '港澳通行证';

export interface EvidenceRecordPerson {
  userId: string;
  userName: string;

  identityId: string;
  identityType: InquiryIdentityTypes;
}

export interface EvidenceRecordInquiree extends EvidenceRecordPerson {
  virtualName: string;
  phoneNo: string;
  province: string;
  city: string;
  adult: '成年' | '未成年';
  gender: '男' | '女';
  birth: string;
  nationality: string;
  nation: string;
  education: string;
  isDeputy: boolean;
  political: string;
  location: string;
  householdAddress: string;
  workAddress: string;

  certType: InquireeCertificateType;
  certNo: string;

  confirmImage: OSSFileInfo;
  signImage: OSSFileInfo;
  fingerprint: OSSFileInfo;
  fingerprintOrigin: OSSFileInfo;
  confirmBeginTime: string;
  confirmEndTime: string;
}

export interface EvidenceRecordInquirer extends EvidenceRecordPerson {
  userId: string;
  userName: string;
  departmentId: number;
  departmentName: string;

  signImage: OSSFileInfo;
}

export interface EvidenceRecord extends EvidenceBase {
  detail: {
    title: string;
    inquiryDate: string;
    basicInfo: EvidenceRecordBasicInfo;
    inquired: { [identityId: string]: EvidenceRecordInquiree };
    inquirer: { [identityId: string]: EvidenceRecordInquirer };
    lines: InquiryRecordLine[];
  };
}

export type InquiryEvidence = {
  inquirer: EvidenceImage[];
  inquiree: EvidenceImage[];
  record?: EvidenceRecord;
  video?: EvidenceVideo;
  screen?: EvidenceVideo[];
};

export type InquiryMapIdentity = Partial<
  { [identityType in InquiryIdentityTypes]: string[] }
>;

export interface EvidenceModelState {
  currentInquiryEvidence: InquiryEvidence;
  currentEvidenceStatus: {
    inquireeDirty: boolean;
  };
  currentRole: InquirerRoles;
  mapIdentity: InquiryMapIdentity;
  caseInquiriesEvidences: {
    [inquiryId: string]: {
      evidence: InquiryEvidence;
      mapIdentity: InquiryMapIdentity;
    };
  };
}

export interface EvidenceModelType {
  namespace: ModelNamespaces.Evidence;
  state: EvidenceModelState;
  effects: {
    getInquiryEvidences: Effect;
    getInquiryRecordEvidence: Effect;
    updateInquiryEvidence: Effect;
    updateInquiryEvidenceFromWs: Effect;
    setCurrentEvidenceStatus: Effect;
    editEvidenceCategoryPersons: Effect;
    editEvidencePerson: Effect;

    uploadImageEvidences: Effect;
    getCaseInquiryEvidences: Effect;
  };
  reducers: {
    save: ImmerReducer<EvidenceModelState>;
    updateEvidencePersonConfirmFromWs: ImmerReducer<EvidenceModelState>;
  };
  subscriptions: { setup: Subscription };
}

export type EvidencePersonType = keyof Pick<
  EvidenceRecord['detail'],
  'inquirer' | 'inquired'
>;

export type EvidencePersonPayload = Array<{
  type: EvidencePersonType;
  file: File;
  filekey: keyof EvidenceRecordInquiree;
  identityId: string;
}>;

export type EvidenceScreenshotType = 'fingerprint' | 'imageEvidence';
