import React from 'react';
import { InquiryIdentityTypes, EvidenceScreenshotType } from 'umi';

import { Layout, Dropdown, Menu, Button, Modal } from 'antd';
const { Footer } = Layout;
import { MenuProps } from 'antd/lib/menu';

import styles from './Layout.less';

interface LiveFooterProps {
  withGuardian: boolean;
  onConfirmRecord: () => void;
  onStartSign: (identityType: InquiryIdentityTypes) => void;
  onStartScreenshot: (type: EvidenceScreenshotType) => void;
  onHangup: () => void;
}

const LiveFooter: React.FC<LiveFooterProps> = props => {
  const startSign = (type: InquiryIdentityTypes) => {
    Modal.confirm({
      title: '你确定向询问人发起签印吗？',
      onOk: () => {
        props.onStartSign(type);
      },
    });
  };

  const confirmMenuClick: MenuProps['onClick'] = params => {
    switch (params.key) {
      case 'confirm2':
        props.onConfirmRecord();
        break;
    }
  };

  const signMenuClick: MenuProps['onClick'] = params => {
    startSign(+params.key);
  };

  return (
    <Footer className={styles.footer}>
      <div className="button-group-lg">
        <Dropdown
          placement="topLeft"
          overlay={
            <Menu onClick={confirmMenuClick}>
              {/* @TODO */}
              <Menu.Item key="confirm1" disabled>
                宣读确认
              </Menu.Item>
              <Menu.Item key="confirm2">浏览确认</Menu.Item>
            </Menu>
          }
        >
          <Button size="large" icon={<i className="iconfont icon-note" />}>
            笔录确认
          </Button>
        </Dropdown>
        {!props.withGuardian ? (
          <Dropdown
            placement="topLeft"
            overlay={
              <Menu onClick={signMenuClick}>
                <Menu.Item key={InquiryIdentityTypes.Guardian}>
                  监护人签字
                </Menu.Item>
                <Menu.Item key={InquiryIdentityTypes.None}>
                  被询问人签字
                </Menu.Item>
              </Menu>
            }
          >
            <Button size="large" icon={<i className="iconfont icon-sign" />}>
              发起签印
            </Button>
          </Dropdown>
        ) : (
          <>
            <Button
              size="large"
              onClick={() => startSign(InquiryIdentityTypes.None)}
              icon={<i className="iconfont icon-sign" />}
            >
              发起签印
            </Button>
          </>
        )}
        <Button
          size="large"
          type="primary"
          danger
          icon={<i className="iconfont icon-hangup" />}
          onClick={props.onHangup}
        >
          挂断
        </Button>
        <Button
          size="large"
          icon={<i className="iconfont icon-fingerprint" />}
          onClick={() => props.onStartScreenshot('fingerprint')}
        >
          发起捺印
        </Button>
        <Button
          size="large"
          icon={<i className="iconfont icon-fingerprint" />}
          onClick={() => props.onStartScreenshot('imageEvidence')}
        >
          画面截图
        </Button>
        {/* @TODO */}
        {/* <Button size="large" icon={<i className="iconfont icon-supervisor" />}>
          督导信息
        </Button> */}
      </div>
    </Footer>
  );
};

export default React.memo(LiveFooter);
