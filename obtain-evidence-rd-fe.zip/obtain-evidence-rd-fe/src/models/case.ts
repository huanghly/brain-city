import moment, { Moment } from 'moment';
import { set } from 'lodash-es';
import {
  CaseModelType,
  RootModelState,
  CaseModelState,
  Effect,
  CaseSimple,
  CaseType,
  matchPath,
} from 'umi';
import { ModelNamespaces, CaseQueryTypes } from './constants';
import { RouteParams } from '@/common/route';
import api from '@/services';
import {
  getDefaultPaginationModel,
  parseRequestPagination,
  parseResponsePagination,
  handleError,
  getDispatchType,
} from '@/common/util';

const CaseModel: CaseModelType = {
  namespace: ModelNamespaces.Case,
  state: {
    cases: getDefaultPaginationModel(10),
    caseTypes: [],

    monthInquiryDates: [],
    dayInquiries: [],
    selectedDate: moment().add(1, 'day'),
  },
  effects: {
    *getCaseTypes(_, { call, put }) {
      const caseTypes: CaseType[] = yield call(api.getCaseTypes);
      yield put({
        type: 'save',
        payload: { value: caseTypes, path: ['caseTypes'] },
      });
    },
    *getPaginationCases({ payload }, { call, select, put }) {
      const { caseQueryType, ...restPayload } = payload;
      const { pageSize, current }: PaginationModel<CaseSimple> = yield select(
        (state: RootModelState) => state.case.cases,
      );
      try {
        const requestParams = parseRequestPagination({
          pageSize,
          current,
          ...restPayload,
        });
        let requestUrl;
        switch (caseQueryType) {
          case CaseQueryTypes.All:
            requestUrl = api.getPaginationCases;
            break;
          case CaseQueryTypes.My:
            requestUrl = api.getMyPaginationCases;
            break;
          case CaseQueryTypes.Subscription:
            requestUrl = api.getMySubscriptionPaginationCases;
            break;
          default:
            return;
        }
        const asyncData = yield call(requestUrl, requestParams);
        const result = parseResponsePagination(asyncData);
        yield put({
          type: 'save',
          payload: { value: result, path: ['cases'] },
        });
      } catch (err) {
        handleError(err);
      }
    },
    *getSuggestedCases({ payload, callback }, { call }) {
      try {
        const cases = yield call(api.getSuggestedCases, payload);
        callback(cases);
      } catch (err) {
        callback([]);
        handleError(err);
      }
    },

    *getCaseLatestInquiryDate({ payload, callback }, { call, put }) {
      const { caseId } = payload;
      try {
        const dates: string[] = yield call(api.getCaseInquiryCalendar, {
          caseId,
        });
        if (!dates.length) {
          callback();
          return;
        }
        const momentDate = moment(dates[0]);
        yield put({
          type: 'save',
          payload: {
            path: 'selectedCase',
            value: { lastInquiryDate: momentDate, caseId },
          },
        });
        callback(momentDate);
      } catch (err) {
        handleError(err);
      }
    },
    *getCaseDetail({ payload, callback }, { call, put }) {
      const { caseId } = payload;
      try {
        const caseDetail = yield call(api.getCaseDetail, { caseId });
        callback && callback(caseDetail);
        yield put({
          type: 'save',
          payload: { path: 'currentCase', value: caseDetail },
        });
      } catch (err) {
        handleError(err);
      }
    },

    *getCaseInquiryCalendar({ payload }, { select, call, put }) {
      let { caseId, yearMonth } = payload;
      const selectedDate: Moment = yield select(
        (state: RootModelState) => state.case.selectedDate,
      );
      if (!yearMonth) {
        yearMonth = selectedDate.format('YYYY-MM');
      }
      try {
        const dates: string[] = yield call(api.getCaseInquiryCalendar, {
          caseId,
          yearMonth,
        });
        const momentDates = (dates || [])
          .sort((d1, d2) => (d1 < d2 ? 1 : -1))
          .map(date => moment(date));
        yield put({
          type: 'save',
          payload: {
            value: momentDates,
            path: ['monthInquiryDates'],
          },
        });
        if (momentDates.length) {
          yield put({
            type: 'setSelectedDate',
            payload: { date: momentDates[0] },
          });
        }
      } catch (err) {
        handleError(err);
      }
    },
    *setSelectedDate({ payload }, { select, call, put }) {
      const [caseId, selectedDate]: [
        number,
        Moment,
      ] = yield select((state: RootModelState) => [
        state.case.selectedCase?.caseId,
        state.case.selectedDate,
      ]);
      const { date } = payload;
      yield put({
        type: 'save',
        payload: { value: date, path: ['selectedDate'] },
      });
      yield put({
        type: 'getCaseDayInquiries',
        payload: { date },
      });

      if (!selectedDate.isSame(date, 'month')) {
        yield put({
          type: 'getCaseInquiryCalendar',
          payload: { caseId, yearMonth: date.format('YYYY-MM') },
        });
      }
    },
    *getCaseDayInquiries({ payload }, { select, call, put }) {
      const { date } = payload;
      const caseId: number = yield select(
        (state: RootModelState) => state.case.selectedCase?.caseId,
      );
      try {
        const result = yield call(api.getCaseDayInquiries, {
          date: date.format('YYYY-MM-DD'),
          caseId,
        });
        if (result.length) {
          yield put({
            type: getDispatchType(
              ModelNamespaces.Evidence,
              'getCaseInquiryEvidences',
            ),
            payload: { inquiryId: result[0].inquiryId },
          });
        }
        yield put({
          type: 'save',
          payload: { value: result, path: ['dayInquiries'] },
        });
      } catch (err) {
        handleError(err);
      }
    },

    *getEvidenceQRCode({ payload, callback }, { call }) {
      const { uuid } = payload;
      try {
        const base64 = yield call(api.getEvidenceQRCode, { uuid });
        callback(base64);
      } catch (err) {
        handleError(err);
      }
    },

    *saveCase({ payload, callback }, { call, put }) {
      const { id: caseId } = payload;
      let requestEffect: Effect;
      if (caseId) {
        requestEffect = call(api.editCase, payload);
      } else {
        requestEffect = call(api.addCase, payload);
      }
      try {
        yield requestEffect;
        callback && callback();
      } catch (err) {
        handleError(err);
      }
    },

    *removeCase({ payload, callback }, { call }) {
      const { caseId } = payload;
      try {
        yield call(api.removeCase, { caseId });
        callback();
      } catch (err) {
        handleError(err);
      }
    },

    *interceptCaseDetail({ payload, callback }, { select, all, put }) {
      const { caseId } = payload;
      const selectedCase: CaseModelState['selectedCase'] = yield select(
        (state: RootModelState) => state.case.selectedCase,
      );
      if (!selectedCase || selectedCase.caseId !== caseId) {
        // 直接路由进入的案件详情
        yield put({
          type: 'getCaseLatestInquiryDate',
          payload: { caseId },
          callback,
        });
      } else {
        callback(selectedCase.lastInquiryDate);
      }
    },

    *initializeCaseDetail(_, { select, all, put }) {
      const {
        caseId,
        lastInquiryDate,
      }: Exclude<CaseModelState['selectedCase'], undefined> = yield select(
        (state: RootModelState) => state.case.selectedCase,
      );
      yield all([
        put({ type: 'getCaseDetail', payload: { caseId } }),
        put({
          type: 'getCaseInquiryCalendar',
          payload: { caseId, yearMonth: lastInquiryDate.format('YYYY-MM') },
        }),
      ]);
    },
  },
  reducers: {
    save(state, action) {
      const { value, path } = action.payload;
      set(state, path, value);
    },
  },
  subscriptions: {
    setup({ dispatch, history }) {
      return history.listen(({ pathname }) => {
        const matchCaseList = matchPath<RouteParams>(pathname, {
          path: '/case/:caseQueryType',
          exact: true,
        });
        if (matchCaseList) {
          const { caseQueryType } = matchCaseList.params;
          if (
            caseQueryType === CaseQueryTypes.All ||
            caseQueryType === CaseQueryTypes.My ||
            caseQueryType === CaseQueryTypes.Subscription
          ) {
            dispatch({
              type: 'getPaginationCases',
              payload: { caseQueryType },
            });
            if (caseQueryType == CaseQueryTypes.All) {
              dispatch({ type: 'getCaseTypes' });
            }
          }
          return;
        }

        const matchCaseDetail = matchPath<RouteParams>(pathname, {
          path: '/case/archive/:caseId',
          exact: true,
        });
        if (matchCaseDetail) {
          const caseId = +matchCaseDetail.params.caseId;
          if (!caseId) {
            return;
          }
          dispatch({
            type: 'interceptCaseDetail',
            payload: { caseId },
            callback: (lastInquiryDate?: Moment) => {
              if (!lastInquiryDate) {
                if (history.length) {
                  history.goBack();
                } else {
                  history.replace(`/case/${CaseQueryTypes.All}`);
                }
                return;
              }
              dispatch({ type: 'initializeCaseDetail' });
            },
          });
        }
      });
    },
  },
};

export default CaseModel;
