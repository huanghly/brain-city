import React, { useState } from 'react';

import { DoubleLeftOutlined, DoubleRightOutlined } from '@ant-design/icons';
import { Empty, Modal } from 'antd';
import Item, { ShowcaseItemProps } from './Item';

import styles from './Showcase.less';

export interface ShowcaseListProps {
  size?: number;
  mediaList: Array<Pick<ShowcaseItemProps, 'type' | 'src'>>;
  selectedIndex: number;
  onSelect: (idx: number) => void;
}

const ShowcaseList: React.FC<ShowcaseListProps> = props => {
  const { size, mediaList, selectedIndex, onSelect } = props;
  if (!mediaList.length) {
    return <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />;
  }

  const sizePercentage = (1 / size!) * 100;
  const [slideStep, setSlideStep] = useState(0);
  const [modalVisible, setModalVisible] = useState(false);

  const changeSlideStep = (step: 1 | -1) => {
    let nextStep = slideStep + step;
    if (nextStep < 0) {
      nextStep = Math.max(mediaList.length - size!, 0);
    } else if (nextStep > mediaList.length - size!) {
      nextStep = 0;
    }
    setSlideStep(nextStep);
  };

  const navStyle: React.CSSProperties = {};
  if (mediaList.length > size!) {
    navStyle.visibility = 'visible';
  }

  const listStyle: React.CSSProperties = {
    transform: `translateX(-${slideStep * sizePercentage}%)`,
  };
  const itemStyle: React.CSSProperties = {
    width: `${sizePercentage}%`,
    paddingBottom: `${sizePercentage}%`,
  };

  const content = (
    <>
      {mediaList[selectedIndex].type === 'image' && (
        <img
          className="g-fit-contain"
          src={mediaList[selectedIndex].src}
          onClick={() => setModalVisible(true)}
        />
      )}
      {mediaList[selectedIndex].type === 'video' && (
        <video
          className="g-fit-contain"
          controls
          src={mediaList[selectedIndex].src}
          onClick={() => setModalVisible(true)}
        />
      )}
    </>
  );

  return (
    <div className={styles.showcase}>
      <div className={styles.top}>
        <div
          className={styles.nav}
          style={navStyle}
          onClick={() => changeSlideStep(-1)}
        >
          <DoubleLeftOutlined />
        </div>
        <div className={styles.list} style={listStyle}>
          {mediaList.map(({ type, src }, index) => (
            <Item
              className={index === selectedIndex ? styles.itemSelected : null}
              style={itemStyle}
              key={index}
              index={index}
              type={type}
              src={src}
              onSelect={onSelect}
            />
          ))}
        </div>
        <div
          className={styles.nav}
          style={navStyle}
          onClick={() => changeSlideStep(1)}
        >
          <DoubleRightOutlined />
        </div>
      </div>
      <div className={styles.current}>{content}</div>
      <Modal
        visible={modalVisible}
        width={640}
        closable={false}
        footer={null}
        onCancel={() => setModalVisible(false)}
      >
        {content}
      </Modal>
    </div>
  );
};

ShowcaseList.defaultProps = {
  size: 5,
};

export default ShowcaseList;
