import React, { useRef } from 'react';
import { range, isNil, some } from 'lodash-es';
import styles from './index.less';

const TimeSpanSelector = ({
  title,
  className,
  selectedTimesRanges,
  currentSelectedTimesRanges,
  onChange,
  onSelected,
}) => {
  const thisRef = useRef({});
  return (
    <div className={`${styles.container} ${className || ''}`}>
      {title && <div className={styles.title}>{title}</div>}
      <div
        className={styles.itemWrapper}
        onMouseLeave={() => {
          if (!thisRef.current.beginSelect) return;
          thisRef.current.beginSelect = false;
          thisRef.current.beginTime = undefined;
          onSelected(currentSelectedTimesRanges);
        }}
      >
        {range(0, 24).map(time => {
          const label = `${time}`;
          return (
            <div className={styles.item}>
              {range(0, 2).map(index => {
                const isSecond = index === 1;
                const selected = some(
                  selectedTimesRanges,
                  selectedTimesRange => {
                    selectedTimesRange;
                    const rTime = isSecond ? time + 1 : time + 0.5;
                    return (
                      selectedTimesRange[0] < rTime &&
                      rTime <= selectedTimesRange[1]
                    );
                  },
                );
                const currentSelected = some(
                  currentSelectedTimesRanges,
                  currentSelectedTimesRange => {
                    currentSelectedTimesRange;
                    const rTime = isSecond ? time + 1 : time + 0.5;
                    return (
                      currentSelectedTimesRange[0] < rTime &&
                      rTime <= currentSelectedTimesRange[1]
                    );
                  },
                );
                return (
                  <div
                    className={`${styles.itemPart} ${
                      selected ? styles.selected : ''
                    } ${currentSelected ? styles.currentSelected : ''}`}
                    style={
                      isSecond
                        ? { borderRight: 'none', width: 20 }
                        : { width: 21 }
                    }
                    onMouseDown={() => {
                      if (selected) {
                        return;
                      }
                      thisRef.current.beginSelect = true;
                      thisRef.current.beginTime = isSecond ? time + 0.5 : time;
                      onChange([
                        [
                          thisRef.current.beginTime,
                          thisRef.current.beginTime + 0.5,
                        ].sort((a, b) => (a < b ? -1 : 1)),
                      ]);
                    }}
                    onMouseEnter={() => {
                      if (
                        selected ||
                        !thisRef.current.beginSelect ||
                        isNil(thisRef.current.beginTime)
                      ) {
                        if (!thisRef.current.beginSelect) return;
                        thisRef.current.beginSelect = false;
                        thisRef.current.beginTime = undefined;
                        onSelected(currentSelectedTimesRanges);
                        return;
                      }
                      const endTime = isSecond ? time + 1 : time + 0.5;
                      if (endTime <= thisRef.current.beginTime) {
                        onChange([
                          [endTime - 0.5, thisRef.current.beginTime + 0.5],
                        ]);
                        return;
                      }
                      onChange([
                        [thisRef.current.beginTime, endTime].sort((a, b) =>
                          a < b ? -1 : 1,
                        ),
                      ]);
                    }}
                    onMouseUp={() => {
                      if (!thisRef.current.beginSelect) return;
                      thisRef.current.beginSelect = false;
                      thisRef.current.beginTime = undefined;
                      onSelected(currentSelectedTimesRanges);
                    }}
                  />
                );
              })}
              <div className={styles.itemLeftLable}>{`${
                label.length < 2 ? `0${label}` : label
              }`}</div>
              {time === 23 && <div className={styles.itemRightLable}>24</div>}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default TimeSpanSelector;
