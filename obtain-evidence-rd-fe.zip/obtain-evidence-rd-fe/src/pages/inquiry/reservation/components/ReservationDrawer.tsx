import React, { useEffect, useState } from 'react';
import moment, { Moment } from 'moment';
import { range } from 'lodash-es';
import {
  UserInfo,
  CaseBase,
  InquiryIdentityTypes,
  ReservationSubmit,
  InquiredIdentityTypesLocale,
} from 'umi';
import { DEFAULT_SPLITTER, MINUTE_STEP } from '@/common/constants';
import { getDaySectionFromStartTime } from '@/common/util';

import {
  SwapRightOutlined,
  InfoCircleOutlined,
  UploadOutlined,
} from '@ant-design/icons';
import {
  Drawer,
  Row,
  Col,
  Form,
  Button,
  Select,
  Input,
  DatePicker,
  TimePicker,
  Upload,
  Radio,
  Popconfirm,
  Empty,
} from 'antd';
const { Option } = Select;
import { FormItemProps, FormProps } from 'antd/lib/form';
import { UploadProps } from 'antd/lib/upload';

const longFormItemLayout: Partial<FormItemProps> = {
  labelCol: { span: 6 },
  wrapperCol: { span: 18 },
};

const shortFormItemLayout: Partial<FormItemProps> = {
  labelCol: { span: 12 },
  wrapperCol: { span: 12 },
};

interface ReservationDrawerProps {
  visible: boolean;
  users: UserInfo[];
  cases: CaseBase[];
  onSearchCase: (caseName: string) => void;
  onSearchCaseUsers: (caseId: string) => void;
  onCreateCase: () => void;
  onDownloadTemplate: () => void;
  onClose: () => void;
  onSave: (reservation: ReservationSubmit) => void;
}

const ReservationDrawer: React.FC<ReservationDrawerProps> = props => {
  const {
    visible,
    users,
    cases,
    onSearchCase,
    onSearchCaseUsers,
    onCreateCase,
    onDownloadTemplate,
    onClose,
    onSave,
  } = props;
  const [form] = Form.useForm();
  const [womanFieldHidden, setWomanFieldHidden] = useState(true);

  useEffect(() => {
    ['inquirer', 'recorder', 'womanInquirer'].forEach(userKey => {
      const fieldValue: string = form.getFieldValue(userKey);
      if (!fieldValue) {
        return;
      }
      const userId = fieldValue.split(DEFAULT_SPLITTER)[0];
      const userExisted = users.findIndex(user => user.userId == userId) >= 0;
      if (!userExisted) {
        form.resetFields([userKey]);
      }
    });
  }, [users]);

  const resetFields = (isOpen: boolean) => {
    if (!isOpen) {
      form.resetFields();
    }
  };

  const save: FormProps['onFinish'] = values => {
    const [caseId, caseName] = values.caseInfo.split(DEFAULT_SPLITTER);
    const [inquirerId, inquirerName] = values.inquirer.split(DEFAULT_SPLITTER);
    const [recorderId, recorderName] = values.recorder.split(DEFAULT_SPLITTER);

    const reservation: ReservationSubmit = {
      caseId,
      caseName,
      date: values.date.format('YYYY-MM-DD 00:00:00'),
      periods: range(
        getDaySectionFromStartTime(values.startTime)!,
        getDaySectionFromStartTime(values.endTime),
      ).join(),
      file: (values.file as UploadProps['fileList'])?.[0].originFileObj as File,
      inquireds: [
        {
          identityType: values.identityType,
          userName: values.inquiredName,
          phoneNo: values.inquiredPhone,
          gender: values.gender,
          adult: values.adult,
        },
      ],
      inquirers: [
        {
          identityType: InquiryIdentityTypes.Inquirer,
          userId: inquirerId,
          userName: inquirerName,
        },
        {
          identityType: InquiryIdentityTypes.Recorder,
          userId: recorderId,
          userName: recorderName,
        },
      ],
    };
    if (values.womanInquirer) {
      const [womanInquirerId, womanInquirerName] = values.womanInquirer.split(
        DEFAULT_SPLITTER,
      );

      reservation.inquirers.push({
        identityType: InquiryIdentityTypes.WomanInquirer,
        userId: womanInquirerId,
        userName: womanInquirerName,
      });
    }
    onSave(reservation);
  };

  const userOptions = users.map(({ userId, userName }) => {
    return (
      <Option key={userId} value={`${userId}${DEFAULT_SPLITTER}${userName}`}>
        {userName}
      </Option>
    );
  });

  const selectCase = (value: string) => {
    const caseId = value.split(DEFAULT_SPLITTER)[0];
    onSearchCaseUsers(caseId);
  };

  const selectedDate: Moment = form.getFieldValue('date');
  const isCurrentDate =
    selectedDate &&
    selectedDate.format('YYYY-MM-DD') === moment().format('YYYY-MM-DD');
  const disabledHours = isCurrentDate ? range(0, moment().get('hour')) : [];

  return (
    <Drawer
      title="新增预约"
      width={640}
      visible={visible}
      afterVisibleChange={resetFields}
      footer={
        <div className="button-group">
          <Button type="primary" onClick={form.submit}>
            确定
          </Button>
          <Button onClick={onClose}>取消</Button>
        </div>
      }
      onClose={onClose}
    >
      <Form form={form} labelAlign="left" onFinish={save}>
        <Form.Item
          label="案事件名称"
          name="caseInfo"
          {...longFormItemLayout}
          rules={[{ required: true, message: '请选择所负责案事件' }]}
        >
          <Select
            placeholder="输入关键词搜索"
            showSearch
            onSearch={onSearchCase}
            onSelect={selectCase}
            notFoundContent={
              <Row align="middle" justify="start">
                <Button size="small" type="link" onClick={onCreateCase}>
                  未找到案事件？点击新建
                </Button>
              </Row>
            }
          >
            {cases.map(({ id, title }) => (
              <Select.Option
                key={id}
                value={`${id}${DEFAULT_SPLITTER}${title}`}
                label={title}
              >
                {title}
              </Select.Option>
            ))}
          </Select>
        </Form.Item>
        <Form.Item
          label="日期"
          name="date"
          {...longFormItemLayout}
          rules={[{ required: true }]}
        >
          <DatePicker disabledDate={date => date <= moment().startOf('day')} />
        </Form.Item>
        <Form.Item label="开始结束时间" {...longFormItemLayout}>
          <Form.Item
            name="startTime"
            rules={[{ required: true, message: '请选择开始时间' }]}
            style={{ display: 'inline-block', marginBottom: 0 }}
          >
            <TimePicker
              placeholder="开始时间"
              minuteStep={MINUTE_STEP}
              disabledHours={() => disabledHours}
              format="HH:mm"
              inputReadOnly
            />
          </Form.Item>
          <SwapRightOutlined
            style={{
              display: 'inline-block',
              width: '24px',
              lineHeight: '32px',
              textAlign: 'center',
            }}
          />
          <Form.Item
            name="endTime"
            rules={[{ required: true, message: '请选择结束时间' }]}
            style={{ display: 'inline-block', marginBottom: 0 }}
          >
            <TimePicker
              placeholder="结束时间"
              minuteStep={MINUTE_STEP}
              format="HH:mm"
              inputReadOnly
            />
          </Form.Item>
        </Form.Item>
        <Row justify="space-between">
          <Col span={12}>
            <Form.Item
              label="被询问人"
              name="inquiredName"
              {...shortFormItemLayout}
              rules={[{ required: true }]}
            >
              <Input placeholder="请填写被询问人" />
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              label="被询问人手机号"
              labelAlign="right"
              name="inquiredPhone"
              {...shortFormItemLayout}
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
          </Col>
        </Row>
        <Form.Item
          label="涉案身份"
          name="identityType"
          {...longFormItemLayout}
          rules={[{ required: true }]}
          initialValue={InquiryIdentityTypes.Victim}
        >
          <Select
            options={Object.entries(
              InquiredIdentityTypesLocale,
            ).map(([value, text]) => ({ label: text, value: +value }))}
          />
        </Form.Item>

        <Row justify="space-between">
          <Col span={12}>
            <Form.Item
              label="被询问人性别"
              name="gender"
              {...shortFormItemLayout}
              rules={[{ required: true }]}
              initialValue="男"
            >
              <Radio.Group
                onChange={e => {
                  setWomanFieldHidden(e.target.value !== '女');
                  form.resetFields(['womanInquirer']);
                }}
              >
                <Radio value="男">男性</Radio>
                <Radio value="女">女性</Radio>
              </Radio.Group>
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              label="是否成年"
              labelAlign="right"
              name="adult"
              {...shortFormItemLayout}
              rules={[{ required: true }]}
              initialValue="成年"
            >
              <Radio.Group>
                <Radio value="成年">成年</Radio>
                <Radio value="未成年">未成年</Radio>
              </Radio.Group>
            </Form.Item>
          </Col>
        </Row>
        <Form.Item
          label={
            <span onClick={e => e.preventDefault()}>
              <span>问题模板</span>
              <Popconfirm
                title={
                  <div>
                    <div>点击下载，获取问题模板固定文件格式。</div>
                    <div>填充并上传文件后，作为该询问的初始笔录内容。</div>
                  </div>
                }
                okText="下载"
                cancelText="关闭"
                onConfirm={onDownloadTemplate}
              >
                <InfoCircleOutlined
                  style={{ cursor: 'pointer', marginLeft: 8 }}
                />
              </Popconfirm>
            </span>
          }
          name="file"
          valuePropName="fileList"
          {...longFormItemLayout}
          getValueFromEvent={e => (Array.isArray(e) ? e : e?.fileList)}
        >
          <Upload beforeUpload={() => false}>
            <Button icon={<UploadOutlined />}>上传文件</Button>
          </Upload>
        </Form.Item>
        <Form.Item
          label="询问人"
          name="inquirer"
          {...longFormItemLayout}
          rules={[{ required: true }]}
        >
          <Select
            placeholder="请选择"
            notFoundContent={
              <Empty
                image={Empty.PRESENTED_IMAGE_SIMPLE}
                description="请先选择案事件"
              />
            }
          >
            {userOptions}
          </Select>
        </Form.Item>
        <Form.Item
          label="记录人"
          name="recorder"
          {...longFormItemLayout}
          rules={[{ required: true }]}
        >
          <Select
            placeholder="请选择"
            notFoundContent={
              <Empty
                image={Empty.PRESENTED_IMAGE_SIMPLE}
                description="请先选择案事件"
              />
            }
          >
            {userOptions}
          </Select>
        </Form.Item>
        {!womanFieldHidden && (
          <Form.Item
            label="女性办案人员"
            name="womanInquirer"
            {...longFormItemLayout}
            rules={[{ required: true }]}
          >
            <Select
              placeholder="请选择"
              notFoundContent={
                <Empty
                  image={Empty.PRESENTED_IMAGE_SIMPLE}
                  description="请先选择案事件"
                />
              }
            >
              {userOptions}
            </Select>
          </Form.Item>
        )}
      </Form>
    </Drawer>
  );
};

export default ReservationDrawer;
