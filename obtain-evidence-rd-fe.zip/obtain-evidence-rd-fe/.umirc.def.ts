const PUBLIC_PATH =
  'https://dev.g.alicdn.com/police-brain-fe/obtain-evidence-fe/0.0.1/';

export default {
  base: PUBLIC_PATH,
  history: { type: 'hash' },
  define: {
    'process.env.PUBLIC_PATH': PUBLIC_PATH,
  },
  publicPath: PUBLIC_PATH,
};
