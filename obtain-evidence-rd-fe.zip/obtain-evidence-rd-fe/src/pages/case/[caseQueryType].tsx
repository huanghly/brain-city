import React from 'react';
import moment, { Moment } from 'moment';
import {
  connect,
  ConnectProps,
  RootModelState,
  Case,
  CaseAuthTypes,
  CaseQueryParams,
  ModelNamespaces,
  Dispatch,
  WorkflowTypes,
  CaseQueryTypes,
} from 'umi';
import { getDispatchType } from '@/common/util';
import { RouteParams } from '@/common/route';

import { Table, Button, Popconfirm, message } from 'antd';
const { Column } = Table;
import { ButtonProps } from 'antd/lib/button';
import { ColumnProps, TablePaginationConfig } from 'antd/lib/table';

import ContentPage from '@/components/ContentPage';
import SearchForm from './components/SearchForm';
import CaseDrawer from './components/CaseDrawer';
import CaseSubscribeDrawer from '@/pages/case/components/CaseSubscribeDrawer';

type CaseArchiveProps = ConnectProps<RouteParams> &
  CaseArchiveStateProps &
  CaseArchiveDispatchProps;
type CaseArchiveStates = {
  caseQueryParams: CaseQueryParams;
  drawerVisible: boolean;
  subscribeDrawVisible: boolean;
  editingCase?: Partial<Case>;
};

class CaseArchive extends React.PureComponent<
  CaseArchiveProps,
  CaseArchiveStates
> {
  constructor(props: CaseArchiveProps) {
    super(props);
    const { cases, match } = props;
    const { current, pageSize } = cases;
    const caseQueryType = match?.params.caseQueryType as CaseQueryTypes;
    this.state = {
      drawerVisible: false,
      subscribeDrawVisible: false,
      caseQueryParams: {
        current,
        pageSize,
        caseQueryType,
      },
    };
  }

  public static getDerivedStateFromProps: React.GetDerivedStateFromProps<
    CaseArchiveProps,
    CaseArchiveStates
  > = (nextProps, prevState) => {
    const { caseQueryParams } = prevState;
    return {
      caseQueryParams: {
        ...caseQueryParams,
        caseQueryType: nextProps.match?.params.caseQueryType as CaseQueryTypes,
      },
    };
  };

  private queryUsers = () => {
    const { users, getUsers } = this.props;
    if (!users.length) {
      getUsers();
    }
  };

  private queryCases = (queryParams: Partial<CaseQueryParams>) => {
    queryParams.current = 1;
    queryParams.pageSize = this.state.caseQueryParams.pageSize;
    queryParams.caseQueryType = this.state.caseQueryParams.caseQueryType;

    this.setState({ caseQueryParams: queryParams });
    this.props.getPaginationCases(queryParams);
  };

  private tableChange = (pagination?: TablePaginationConfig) => {
    const { pageSize, current } = pagination || this.state.caseQueryParams;
    const queryParams = {
      ...this.state.caseQueryParams,
      pageSize,
      current,
    };
    this.setState({ caseQueryParams: queryParams });
    this.props.getPaginationCases(queryParams);
  };

  private saveCase = (value: Case) => {
    const { editingCase } = this.state;
    const updatedCase = value; // { ...editingCase, ...value };
    this.props.saveCase(updatedCase, () => {
      this.setState({ drawerVisible: false });
      message.info(`${updatedCase.id ? '编辑' : '新增'}案事件成功！`);
      this.tableChange();
    });
  };

  private removeCase = (caseId: string) => {
    this.props.removeCase(caseId, () => {
      this.props.getPaginationCases(this.state.caseQueryParams);
      message.info('案事件删除成功！');
    });
  };

  private openDrawer = () => {
    this.queryUsers();
    const { currentUser } = this.props;
    this.setState({
      editingCase: {
        creatorId: currentUser?.userId,
        creatorName: currentUser?.userName,
      },
      drawerVisible: true,
    });
  };

  private closeDrawer = () => {
    this.setState({ drawerVisible: false });
  };

  private closeSubscribeDrawer = () => {
    this.setState({ subscribeDrawVisible: false });
  };

  private subscribeCase = () => {
    this.props.applyCaseSubscription(this.state.editingCase?.id!, () => {
      this.closeSubscribeDrawer();
    });
  };

  private openSubscribeDrawer = (caseSimple: Case) => {
    const { id, title, dutyUserName } = caseSimple;
    this.setState({
      editingCase: {
        id,
        title,
        dutyUserName,
        createDate: moment().format('YYYY-MM-DD HH:mm'),
      },
      subscribeDrawVisible: true,
    });
  };

  private goToDetail = (caseId: string) => {
    const { history, getCaseLatestInquiryDate } = this.props;
    getCaseLatestInquiryDate(caseId, (latestDate?: Moment) => {
      if (latestDate) {
        history.push(`/case/archive/${caseId}`);
        return;
      }
      message.warning('该案事件暂无询问数据！');
    });
  };

  private editCase = (caseId: string) => {
    this.queryUsers();
    this.props.getCaseDetail(caseId, (editingCase: Case) => {
      this.setState({ editingCase, drawerVisible: true });
    });
  };

  private renderOperation: ColumnProps<Case>['render'] = (value, record) => {
    const { authType } = record;
    const buttonPropsList: ButtonProps[] = [
      {
        size: 'small',
        type: 'link',
      },
    ];
    switch (authType) {
      case CaseAuthTypes.NoAuth:
        buttonPropsList[0].children = '调阅';
        buttonPropsList[0].onClick = () => {
          this.openSubscribeDrawer(record);
        };
        break;
      case CaseAuthTypes.LookUp:
        buttonPropsList[0].children = '浏览';
        buttonPropsList[0].onClick = () => {
          this.goToDetail(record.id);
        };
        break;
      case CaseAuthTypes.Edit:
      case CaseAuthTypes.Delete:
        buttonPropsList[0].children = '浏览';
        buttonPropsList[0].onClick = () => {
          this.goToDetail(record.id);
        };
        buttonPropsList.push({
          ...buttonPropsList[0],
          children: '编辑',
          onClick: () => {
            this.editCase(record.id);
          },
        });
        if (authType === CaseAuthTypes.Delete) {
          buttonPropsList.push({
            ...buttonPropsList[0],
            children: '删除',
            onClick: undefined,
          });
        }
        break;
      default:
        if (
          this.state.caseQueryParams.caseQueryType ===
          CaseQueryTypes.Subscription
        ) {
          buttonPropsList[0].children = '浏览';
          buttonPropsList[0].onClick = () => {
            this.goToDetail(record.id);
          };
        }
        break;
    }

    return buttonPropsList.map((buttonProps, idx) => {
      let content = <Button {...buttonProps} />;
      if (!buttonProps.onClick) {
        content = (
          <Popconfirm
            title="确认要删除吗？"
            onConfirm={() => this.removeCase(record.id)}
          >
            {content}
          </Popconfirm>
        );
      }
      return (
        <React.Fragment key={idx}>
          {content}
          {idx !== buttonPropsList.length - 1 && <span>|</span>}
        </React.Fragment>
      );
    });
  };

  render() {
    const { caseTypes, cases, users } = this.props;
    const { list, ...paginationProps } = cases;
    const {
      drawerVisible,
      subscribeDrawVisible,
      editingCase,
      caseQueryParams,
    } = this.state;

    return (
      <ContentPage title="案件档案">
        <SearchForm.Case
          simple={caseQueryParams.caseQueryType !== CaseQueryTypes.All}
          caseTypes={caseTypes}
          onChange={this.queryCases}
          onAdd={this.openDrawer}
        />
        <Table
          className="g-table-list"
          rowKey="id"
          pagination={{ ...paginationProps, showSizeChanger: true }}
          dataSource={list}
          onChange={this.tableChange}
        >
          <Column title="案事件名称" dataIndex="title" />
          <Column
            title="案事件类型"
            dataIndex="typeName"
            render={(_, record: Case) =>
              [record.typeName, record.subTypeName].join('-')
            }
          />
          <Column title="建档日期" dataIndex="createDate" align="center" />
          <Column title="负责人" align="center" dataIndex="dutyUserName" />
          {caseQueryParams.caseQueryType !== CaseQueryTypes.Subscription && (
            <Column
              title="下次询问时间"
              align="center"
              dataIndex="nextTime"
              render={value => value || '-'}
            />
          )}
          <Column
            title="操作"
            align="center"
            width={200}
            dataIndex="id"
            render={this.renderOperation}
          />
        </Table>
        {editingCase && (
          <CaseDrawer
            visible={drawerVisible}
            value={editingCase}
            caseTypes={caseTypes}
            users={users}
            onSave={this.saveCase}
            onCancel={this.closeDrawer}
          />
        )}
        {editingCase && (
          <CaseSubscribeDrawer
            visible={subscribeDrawVisible}
            caseInfo={editingCase}
            onOk={this.subscribeCase}
            onCancel={this.closeSubscribeDrawer}
          />
        )}
      </ContentPage>
    );
  }
}

const mapStateToProps = (state: RootModelState) => ({
  caseTypes: state.case.caseTypes,
  cases: state.case.cases,
  currentUser: state.user.currentUser,
  users: state.user.users,
});

const mapDispatchToProps = (dispatch: Dispatch) => ({
  getUsers: () =>
    dispatch({ type: getDispatchType(ModelNamespaces.User, 'getUsers') }),
  getPaginationCases: (queryParams: Partial<CaseQueryParams>) =>
    dispatch({
      type: getDispatchType(ModelNamespaces.Case, 'getPaginationCases'),
      payload: queryParams,
    }),
  saveCase: (updatedCase: Partial<Case>, callback: () => void) =>
    dispatch({
      type: getDispatchType(ModelNamespaces.Case, 'saveCase'),
      payload: updatedCase,
      callback,
    }),
  removeCase: (caseId: string, callback: () => void) =>
    dispatch({
      type: getDispatchType(ModelNamespaces.Case, 'removeCase'),
      payload: { caseId },
      callback,
    }),
  getCaseLatestInquiryDate: (
    caseId: string,
    callback: (latestDate?: Moment) => void,
  ) =>
    dispatch({
      type: getDispatchType(ModelNamespaces.Case, 'getCaseLatestInquiryDate'),
      payload: { caseId },
      callback,
    }),
  getCaseDetail: (caseId: string, callback: (caseDetail: Case) => void) =>
    dispatch({
      type: getDispatchType(ModelNamespaces.Case, 'getCaseDetail'),
      payload: {
        caseId,
      },
      callback,
    }),
  applyCaseSubscription: (caseId: string, callback: () => void) =>
    dispatch({
      type: getDispatchType(ModelNamespaces.Workflow, 'addApplication'),
      payload: { caseId, type: WorkflowTypes.Subscription },
      callback,
    }),
});

type CaseArchiveStateProps = ReturnType<typeof mapStateToProps>;
type CaseArchiveDispatchProps = ReturnType<typeof mapDispatchToProps>;

export default connect(mapStateToProps, mapDispatchToProps)(CaseArchive);
