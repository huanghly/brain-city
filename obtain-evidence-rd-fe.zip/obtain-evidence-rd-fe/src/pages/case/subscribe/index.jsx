import React, { Component, useState } from 'react';
import {
  Input,
  Select,
  DatePicker,
  Button,
  Table,
  Space,
  Drawer,
  Form,
  Tabs,
  Badge,
} from 'antd';
import { history } from 'umi';
import { SearchOutlined } from '@ant-design/icons';
import styles from './index.less';
import Apply from './apply';

const Option = Select.Option;
const TabPane = Tabs.TabPane;

const formItemLayout = {
  labelCol: { span: 6 },
  wrapperCol: { span: 16 },
};

class CaseSubscribe extends Component {
  state = { visible: false };

  showDrawer = () => {
    this.setState({ visible: true });
  };
  onClose = () => {
    this.setState({ visible: false });
  };

  mockColumns() {
    const columns = [
      {
        title: '案事件名称',
        dataIndex: 'name',
        key: 'name',
        render: text => <a>{text}</a>,
      },
      {
        title: '申请类型',
        dataIndex: 'type',
        key: 'type',
      },
      {
        title: '申请日期',
        dataIndex: 'date',
        key: 'date',
      },
      {
        title: '审批状态',
        dataIndex: 'status',
        render: text => {
          let color = 'green';
          if (text == '未审批') {
            color = 'yellow';
          } else if (text == '已拒绝') {
            color = 'red';
          }
          return (
            <span>
              <Badge color={color} text={text} />
            </span>
          );
        },
      },
      {
        title: 'Action',
        key: 'action',
        render: record => {
          if (record.status == '已通过') {
            return (
              <Space size="middle">
                <a
                  onClick={() => {
                    history.push('/case/detail?novideo=1');
                  }}
                >
                  浏览
                </a>
              </Space>
            );
          }
        },
      },
    ];

    return columns;
  }

  mockData() {
    const data = [];
    for (var i = 0; i < 10; i++) {
      const item = {};
      item.key = i;
      item.name = '案件' + i;
      item.type = i % 2 ? '诈骗案' : '盗窃案';
      item.date = '2020-06-20';
      item.status = i % 3 === 0 ? '未审批' : i % 3 === 1 ? '已通过' : '已拒绝';
      item.nextdate = '2020-06-30';
      data.push(item);
    }
    return data;
  }

  showDrawer = () => {
    this.setState({ visible: true });
  };
  onClose = () => {
    this.setState({ visible: false });
  };

  render() {
    return (
      <div className={styles.wrapper}>
        <h2>我的调阅</h2>
        <div className={styles.content}>
          <Tabs defaultActiveKey="1">
            <TabPane tab="我的调阅" key="1">
              <div className={styles.optbar}>
                <Input
                  placeholder="请输入关键词，如案事件名称"
                  suffix={<SearchOutlined className="site-form-item-icon" />}
                  style={{ width: 248 }}
                />
              </div>
              <Table
                columns={this.mockColumns()}
                dataSource={this.mockData()}
              />
            </TabPane>
            <TabPane tab="我的审批(2)" key="2">
              我的审批
            </TabPane>
          </Tabs>
        </div>
        <Apply visible={this.state.visible} onClose={this.onClose} />
      </div>
    );
  }
}

export default CaseSubscribe;
