import {
  InquiryModelType,
  ReservationDisplay,
  InquiryInfo,
  InquiryRecordLine,
  RootModelState,
  InquiryModelState,
  EvidenceImage,
  InquireeWsPayload,
  EvidenceRecord,
  UserInfo,
  matchPath,
} from 'umi';
import moment from 'moment';
import { set } from 'lodash-es';
import api from '@/services';
import {
  ModelNamespaces,
  EvidenceFrom,
  EvidenceTypes,
  ReservationStatus,
} from './constants';
import { setTheme, resetTheme } from '@/utils/theme';

import { RouteParams } from '@/common/route';
import {
  getDefaultPaginationModel,
  parseRequestPagination,
  parseResponsePagination,
  handleError,
  getDispatchType,
} from '@/common/util';
import { NotificationActions } from '@/common/constants';

const initialState: InquiryModelState = {
  reservations: {
    today: [],
    week: getDefaultPaginationModel(12),
  },

  inquiryInfo: undefined,
  live: {
    currentInquiryId: 0,
    meetingParams: {
      bizName: '',
      signature: '',
      subBiz: '',
      uid: '',
    },
    recordStatus: {
      confirmed: false,
    },
    recordLines: [],
  },
};

const InquiryModel: InquiryModelType = {
  namespace: ModelNamespaces.Inquiry,
  state: initialState,
  effects: {
    *getTodayReservations(_, { call, put }) {
      try {
        const { datas: reservations } = yield call(api.getTodayReservations);
        yield put({
          type: 'save',
          payload: { value: reservations, path: ['reservations', 'today'] },
        });
      } catch (err) {
        handleError(err);
      }
    },
    *getWeekPaginationReservations({ payload }, { call, select, put }) {
      const {
        pageSize,
        current,
      }: PaginationModel<ReservationDisplay> = yield select(
        (state: RootModelState) => state.inquiry.reservations.week,
      );
      const requestParams = parseRequestPagination({
        pageSize,
        current,
        ...payload,
      });
      try {
        const asyncData = yield call(
          api.getWeekPaginationReservations,
          requestParams,
        );
        const reservations = parseResponsePagination(asyncData);
        yield put({
          type: 'save',
          payload: { value: reservations, path: ['reservations', 'week'] },
        });
      } catch (err) {
        handleError(err);
      }
    },
    *editReservation({ payload }, { call, put }) {
      try {
        const asyncData = yield call(api.editReservation, payload);
      } catch (err) {
        handleError(err);
      }
    },

    *getInquiryInfo({ payload }, { call, put }) {
      try {
        const inquiryInfo: InquiryInfo = yield call(
          api.getInquiryInfo,
          payload,
        );
        yield put({
          type: 'save',
          payload: { value: inquiryInfo, path: ['inquiryInfo'] },
        });
      } catch (err) {
        handleError(err);
      }
    },
    *editInquiree({ payload, wsHelper }, { put }) {
      const { models } = payload;
      try {
        yield put({
          type: 'editInquireeRecord',
          payload: models,
        });
        const wsPayload: InquireeWsPayload = {
          action: NotificationActions.recordEdited,
          info: {
            inquiredModels: models,
            updatedTimestamp: moment().valueOf(),
          },
        };
        wsHelper?.send(JSON.stringify(wsPayload));
      } catch (err) {
        handleError(err);
      }
    },

    *uploadRecordLines({ callback }, { select, call, put }) {
      const [currentInquiryId, evidenceId, recordLines]: [
        number,
        number,
        InquiryRecordLine[],
      ] = yield select((state: RootModelState) => [
        state.inquiry.live.currentInquiryId,
        state.inquiry.live.recordStatus.evidenceId,
        state.inquiry.live.recordLines,
      ]);
      const formData = new FormData();
      formData.append('inquiryId', currentInquiryId.toString());
      formData.append('type', EvidenceTypes.Record.toString());
      formData.append('evidenceFrom', EvidenceFrom.Inquirer.toString());
      if (evidenceId) {
        formData.append('evidenceId', evidenceId.toString());
      }
      const updatedRecordDetail: Pick<EvidenceRecord['detail'], 'lines'> = {
        lines: recordLines,
      };
      formData.append('records', JSON.stringify(updatedRecordDetail));
      try {
        const evidenceId = yield call(api.uploadEvidence, formData);
        yield put({
          type: 'save',
          payload: {
            value: {
              confirmed: true,
              evidenceId,
            },
            path: ['live', 'recordStatus'],
          },
        });
        callback && callback();
      } catch (err) {
        handleError(err);
      }
    },

    *getConvertedFingerprint({ payload, callback }, { call }) {
      try {
        const convertedFingerprint = yield call(
          api.getConvertedFingerprint,
          payload,
        );
        callback(convertedFingerprint);
      } catch (err) {
        callback();
      }
    },

    *editInquiry({ payload, callback }, { call }) {
      try {
        yield call(api.editInquiry, payload);
        callback();
      } catch (err) {
        handleError(err);
      }
    },

    *enterInquiry({ payload, callback }, { put, call }) {
      try {
        const meetingParams = yield call(api.enterInquiry, payload);
        yield put({
          type: 'saveLiveModel',
          payload: {
            meetingParams,
          },
        });
        callback && callback(meetingParams);
      } catch (err) {
        handleError(err);
      }
    },
    *createMeeting({ payload }, { select, call }) {
      const currentInquiryId = yield select(
        (state: RootModelState) => state.inquiry.live.currentInquiryId,
      );
      try {
        yield call(api.createMeeting, {
          ...payload,
          inquiryId: currentInquiryId,
        });
      } catch (err) {
        handleError(err);
      }
    },
    *addScreenRecord({ payload }, { select, call }) {
      try {
        const { recordId } = payload;
        const currentInquiryId: number = yield select(
          (state: RootModelState) => state.inquiry.live.currentInquiryId,
        );
        const requestParams = {
          inquiryId: currentInquiryId,
          type: EvidenceTypes.Screen,
          evidenceFrom: EvidenceFrom.Inquiree,
          recordId,
        };
        yield call(api.uploadEvidence, requestParams);
      } catch (err) {
        handleError(err);
      }
    },
    *endMeeting({ callback }, { select, put, call }) {
      try {
        const currentInquiryId = yield select(
          (state: RootModelState) => state.inquiry.live.currentInquiryId,
        );
        yield call(api.endMeeting, { inquiryId: currentInquiryId });
        callback && callback();
      } catch (err) {
        handleError(err);
      }
    },

    *addLiveRecordLine({ payload, wsHelper }, { put }) {
      yield put({ type: 'saveLiveRecordLine', payload });
      const wsPayload: InquireeWsPayload = {
        action: NotificationActions.recordEdited,
        lines: payload,
      };
      wsHelper?.send(JSON.stringify(wsPayload));
    },
    *editRecord({ payload, wsHelper, updateLines }, { put }) {
      yield put({
        type: 'editSingleRecord',
        payload,
      });
      const wsPayload: InquireeWsPayload = {
        action: NotificationActions.recordEdited,
        lines: updateLines,
      };
      wsHelper?.send(JSON.stringify(wsPayload));
    },
    *removeRecord({ payload, wsHelper, updateLines }, { put }) {
      yield put({
        type: 'removeSingleRecord',
        payload,
      });
      const wsPayload: InquireeWsPayload = {
        action: NotificationActions.recordEdited,
        lines: updateLines,
      };
      wsHelper?.send(JSON.stringify(wsPayload));
    },

    *initializePageLive({ payload, callback }, { take, put, all, select }) {
      yield all([
        put({ type: 'user/getCurrentUser' }),
        put({ type: 'getInquiryInfo', payload }),
      ]);
      yield all([
        take('user/getCurrentUser/@@end'),
        take('getInquiryInfo/@@end'),
      ]);
      const [currentUser, inquiryInfo]: [
        UserInfo,
        InquiryInfo,
      ] = yield select((state: RootModelState) => [
        state.user.currentUser,
        state.inquiry.inquiryInfo,
      ]);
      if (
        (currentUser.userId !== inquiryInfo.inquirerId &&
          currentUser.userId !== inquiryInfo.recorderId) ||
        inquiryInfo.inquiryStatus === ReservationStatus.Finished
      ) {
        // 回调返回询问日程列表页面
        return callback();
      }

      const meetingParams = yield select(
        (state: RootModelState) => state.inquiry.live.meetingParams,
      );
      if (!meetingParams.bizName) {
        // 二次进入，没有通过列表 enterInquiry 而直接进入的询问页面
        yield put({
          type: 'enterInquiry',
          payload: { inquiryId: payload.inquiryId },
        });
        yield take('enterInquiry/@@end');
      }

      yield all([
        put({
          type: getDispatchType(
            ModelNamespaces.Evidence,
            'getInquiryEvidences',
          ),
          payload,
        }),
        put({
          type: getDispatchType(
            ModelNamespaces.Evidence,
            'getInquiryRecordEvidence',
          ),
          payload: { ...payload, init: true },
        }),
        put({
          type: 'save',
          payload: {
            value: payload.inquiryId,
            path: ['live', 'currentInquiryId'],
          },
        }),
      ]);

      yield take(
        `${getDispatchType(
          ModelNamespaces.Evidence,
          'getInquiryRecordEvidence',
        )}/@@end`,
      );

      const recordEvidenceId = yield select(
        (state: RootModelState) =>
          state.evidence.currentInquiryEvidence.record?.id,
      );

      yield put({
        type: 'save',
        payload: {
          value: recordEvidenceId,
          path: ['live', 'recordStatus', 'evidenceId'],
        },
      });
    },
  },
  reducers: {
    save(state, action) {
      const { value, path } = action.payload;
      set(state, path, value);
    },
    saveLiveModel(state, action) {
      state.live = {
        ...state.live,
        ...action.payload,
      };
    },
    editInquireeRecord(state, action) {
      // @@FIXME
      // let recordDetail = state.evidence.record?.detail.record;
      // if (!recordDetail) {
      //   return;
      // }
      // recordDetail.inquiredModels = action.payload;
    },
    saveLiveRecordLine(state, action) {
      state.live.recordLines = state.live.recordLines.concat(action.payload);
    },
    editSingleRecord(state, action) {
      const { timestamp, ...rest } = action.payload;
      const lineIdx = state.live.recordLines.findIndex(
        line => line.timestamp === timestamp,
      );
      if (~lineIdx) {
        state.live.recordLines.splice(lineIdx, 1, {
          ...state.live.recordLines[lineIdx],
          ...rest,
        });
      }
    },
    removeSingleRecord(state, action) {
      state.live.recordLines = state.live.recordLines.filter(
        ({ timestamp }) => timestamp !== action.payload.timestamp,
      );
    },
  },
  subscriptions: {
    setup({ dispatch, history }) {
      return history.listen(({ pathname }) => {
        const match = matchPath<RouteParams>(pathname, {
          path: '/inquiry/live/:inquiryId',
          exact: true,
        });
        if (match) {
          setTheme('dark');
          const inquiryId = +match.params.inquiryId;
          dispatch({
            type: 'initializePageLive',
            payload: { inquiryId },
            callback: () => {
              history.replace('/inquiry/schedule');
            },
          });
        } else {
          resetTheme();
          dispatch({
            type: 'save',
            payload: { value: initialState.live, path: ['live'] },
          });
        }
        if (pathname === '/inquiry/schedule') {
          dispatch({ type: 'getTodayReservations' });
          dispatch({ type: 'getWeekPaginationReservations' });
        }
      });
    },
  },
};

export default InquiryModel;
