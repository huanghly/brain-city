import React from 'react';
import { connect, RootModelState, withRouter, ConnectProps } from 'umi';
import styles from './analysis.less';
import {
  STATISTICS_ITEMS,
  DONUT_CONFIG,
  MAP_CONFIG,
  LINE_CONFIG,
  POINT_CONFIG,
  MARKER_CONFIG,
} from '@/common/constants';
import { RouteComponentWithParams } from '@/common/route';
import { Donut } from '@ant-design/charts';
import { AMapScene, LineLayer, PointLayer, Marker } from '@antv/l7-react';

type AnalysisProps = ConnectProps &
  RouteComponentWithParams &
  AnalysisStateProps;

class Analysis extends React.PureComponent<AnalysisProps> {
  render() {
    const {
      analysis: { pieData, mapData, statisticData },
    } = this.props;
    return (
      <div className={styles.analysis}>
        <div className={styles.summary}>
          <div className={styles.title}>概览</div>
          <div className={styles.statisticContainer}>
            {STATISTICS_ITEMS.map(item => {
              return (
                <div key={item.key} className={styles.statisticItem}>
                  <div className={styles.statisticIcon}>
                    <i className={`iconfont ${item.icon}`} />
                  </div>
                  <div className={styles.statisticText}>{item.title}</div>
                  <div className={styles.statisticCount}>
                    {statisticData[item.key] === undefined
                      ? '-'
                      : statisticData[item.key]}
                  </div>
                  <div className={styles.statisticText}>{item.unit}</div>
                </div>
              );
            })}
          </div>
        </div>
        <div className={styles.chartContainer}>
          <div className={styles.mapPart}>
            <div className={styles.mapHeader}>
              当前在线询问案件
              <div className={styles.mapCount}>
                {statisticData?.currentInquiryCount === undefined
                  ? '-'
                  : statisticData.currentInquiryCount}
              </div>
              起<div style={{ marginLeft: '60px' }}>节约出差里程 </div>
              <div className={styles.mapCount}>
                {statisticData?.travelSaved === undefined
                  ? '-'
                  : statisticData.travelSaved}
              </div>
              公里
            </div>
            <div className={styles.mapContainer}>
              <AMapScene {...MAP_CONFIG}>
                <LineLayer
                  {...LINE_CONFIG}
                  source={{
                    data: mapData,
                    parser: {
                      type: 'json',
                      x: 'x',
                      y: 'y',
                      x1: 'x1',
                      y1: 'y1',
                    },
                  }}
                />
                <PointLayer
                  {...POINT_CONFIG}
                  source={{
                    data: mapData,
                    parser: {
                      type: 'json',
                      x: 'x1',
                      y: 'y1',
                    },
                  }}
                />
                {mapData.map((item, index) => {
                  const found = mapData.findIndex(
                    element =>
                      element.x && element.x === item.x && element.y === item.y,
                  );
                  if (found === index) {
                    return (
                      <Marker
                        key={index}
                        lnglat={{
                          lng: item.x,
                          lat: item.y,
                        }}
                        {...MARKER_CONFIG}
                      />
                    );
                  }
                })}
              </AMapScene>
            </div>
          </div>
          <div className={styles.donutContainer}>
            <div className={styles.donutHeader}> 案件类型占比</div>
            <Donut
              {...DONUT_CONFIG}
              data={pieData}
              className={styles.donutChart}
            />
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state: RootModelState) => ({
  analysis: state.analysis,
});

type AnalysisStateProps = ReturnType<typeof mapStateToProps>;

export default connect(mapStateToProps)(Analysis);
