import React from 'react';

import { InquiryRecordLine } from 'umi';
