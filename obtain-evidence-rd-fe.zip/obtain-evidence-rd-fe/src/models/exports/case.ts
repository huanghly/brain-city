import { Moment } from 'moment';
import {
  Effect,
  ImmerReducer,
  Subscription,
  ModelNamespaces,
  CaseAuthTypes,
  CaseQueryTypes,
  InquiryInfoSimple,
} from 'umi';

export type CaseType = {
  id: string;
  name: string;
  children: Omit<CaseType, 'children'>[];
};

export interface CaseBase {
  id: string;
  title: string;
}

export interface CaseSimple extends CaseBase {
  id: string;
  title: string;
  typeName: string;
  subTypeName: string;
  dutyUserName: string;
  nextTime: string;
  authType: CaseAuthTypes;
  createDate: string;
}

export interface Case extends CaseSimple {
  typeId: string;
  subTypeId: string;
  dutyUserId: string;
  creatorId: string;
  creatorName: string;
  status: number;
  participants: Array<{
    userId: string;
    userName: string;
  }>;
}

export type CaseQueryParams = {
  keyword?: string;
  subType?: string;
  types?: string[];
  startDate?: string;
  endDate?: string;
  createDate?: [Moment, Moment];
  pageSize?: number;
  current?: number;
  caseQueryType?: CaseQueryTypes;
};

export interface CaseModelState {
  cases: PaginationModel<CaseSimple>;
  caseTypes: CaseType[];

  selectedCase?: {
    caseId: number;
    lastInquiryDate: Moment;
  };
  currentCase?: Case;

  selectedDate: Moment;
  monthInquiryDates: Moment[];
  dayInquiries: InquiryInfoSimple[];
}

export interface CaseModelType {
  namespace: ModelNamespaces.Case;
  state: CaseModelState;
  effects: {
    getCaseTypes: Effect;
    getPaginationCases: Effect;
    getSuggestedCases: Effect;
    saveCase: Effect;
    removeCase: Effect;

    getCaseLatestInquiryDate: Effect;
    getCaseDetail: Effect;
    getCaseInquiryCalendar: Effect;
    setSelectedDate: Effect;
    getCaseDayInquiries: Effect;

    getEvidenceQRCode: Effect;

    interceptCaseDetail: Effect;
    initializeCaseDetail: Effect;
  };
  reducers: {
    save: ImmerReducer<CaseModelState>;
  };
  subscriptions: { setup: Subscription };
}
