import { NotificationActions } from './constants';

export class WsHelper {
  private socket: WebSocket | null = null;
  private wsUrl: string;

  constructor(wsBaseUrl: string, params: string) {
    this.wsUrl = wsBaseUrl + params;
  }

  public onOpen?: (e: Event) => void;
  public onClose?: (e: CloseEvent) => void;
  public onError?: (e: Event) => void;
  public onMessage?: (e: MessageEvent) => void;

  public open = () => {
    this.socket = new WebSocket(this.wsUrl);
    this.socket.addEventListener('open', e => {
      this.onOpen && this.onOpen(e);
    });
    this.socket.addEventListener('close', e => {
      this.onClose && this.onClose(e);
    });
    this.socket.addEventListener('error', e => {
      this.onError && this.onError(e);
    });
    this.socket.addEventListener('message', e => {
      if (
        typeof e.data === 'string' &&
        e.data.indexOf(NotificationActions.keepAlive) >= 0
      ) {
        // ping pong 响应服务端
        this.send(e.data);
      }
      this.onMessage && this.onMessage(e);
    });
  };

  public send = (data: string) => {
    this.socket?.send(data);
  };

  public close = () => {
    this.socket?.close();
  };
}
