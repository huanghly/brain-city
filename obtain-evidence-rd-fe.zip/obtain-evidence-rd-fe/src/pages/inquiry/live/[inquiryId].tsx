import React from 'react';
import moment from 'moment';
import produce from 'immer';
import {
  withRouter,
  connect,
  ConnectProps,
  Dispatch,
  ModelNamespaces,
  RootModelState,
  MeetingSdkRoomParams,
  InquiryIdentityTypes,
  InquiryRecordLine,
  EvidenceModelState,
  EvidenceFrom,
  EvidenceRecord,
  EvidenceRecordPerson,
  EvidencePersonType,
  EvidencePersonPayload,
  EvidenceScreenshotType,
  EvidenceRecordInquiree,
  RawInquiryRecordLine,
  UpdateLines,
  InquiryRecordTypes,
  InquireeWsPayload,
  EvidenceTypes,
  InquiryRecordInquiree,
  InquirerRoles,
  getInquireeIdentityIdByMapIdentity,
} from 'umi';
import { RouteComponentWithParams } from '@/common/route';
import { WS_ADDRESS, NotificationActions } from '@/common/constants';
import { getDispatchType, getBlobsFromBase64Images } from '@/common/util';
import { WsHelper } from '@/common/ws';

import { CheckCircleFilled } from '@ant-design/icons';
import { Tabs, Row, Col, Modal, message, Badge, Empty, Skeleton } from 'antd';
const { TabPane } = Tabs;
import Collapser from '@/components/Collapser';
import InquiryCard from '@/components/InquiryCard';
import {
  Layout,
  Header,
  Left,
  Content,
  Right,
  Footer,
} from './components/Layout';
import Card from './components/Card';
import Record from './components/Record';
import Meeting, { PublishTag } from './components/Meeting';
import InquireeEditModal from './components/InquireeEditModal';
import FingerprintModal from './components/FingerprintModal';

import styles from './live.less';

type InquiryLiveProps = ConnectProps &
  InquiryLiveStateProps &
  InquiryLiveDispatchProps &
  RouteComponentWithParams;

interface InquiryLiveStates {
  leftCollapsed: boolean;
  contentCollapsed: boolean;
  editModalVisible: boolean;

  meetingStarted?: boolean;
  fingerprintBase64: string;
  convertedFingerprintBase64: string;
  fingerprintModalVisible: boolean;

  screenshotSignal: boolean;
  rawAsrMessages: RawInquiryRecordLine[];
}

const LEFT_SIDER_WIDTH = 260;
const RIGHT_SIDER_WIDTH = 460;

class InquiryLive extends React.PureComponent<
  InquiryLiveProps,
  InquiryLiveStates
> {
  private wsHelper?: WsHelper;
  private refRecords = React.createRef<Col>();
  private screenshotType: EvidenceScreenshotType = 'fingerprint';

  state: Readonly<InquiryLiveStates> = {
    leftCollapsed: false,
    contentCollapsed: false,
    editModalVisible: false,

    fingerprintModalVisible: false,
    fingerprintBase64: '',
    convertedFingerprintBase64: '',

    screenshotSignal: false,

    rawAsrMessages: [],
  };

  componentDidUpdate(prevProps: InquiryLiveProps) {
    if (
      (prevProps.recordLines || []).length <
      (this.props.recordLines || []).length
    ) {
      const elem = document.querySelector(
        `.${this.refRecords.current?.props?.className}`,
      );
      if (elem) {
        elem.scrollTop = elem.scrollHeight;
      }
    }

    if (
      !this.wsHelper &&
      this.props.currentInquiryId &&
      this.props.currentRole
    ) {
      this.initializeWs();
    }
  }

  componentWillUnmount() {
    this.wsHelper?.close();
  }

  initializeWs() {
    const { currentInquiryId, currentRole } = this.props;
    const params = new URLSearchParams();
    switch (currentRole) {
      case InquirerRoles.Inquirer:
        params.set('role', 'inquirer');
        break;
      case InquirerRoles.InquirerRecorder:
        params.set('role', 'inquirer_recorder');
        break;
      case InquirerRoles.Recorder:
        params.set('role', 'recorder');
        break;
    }
    params.set('id', currentInquiryId.toString());
    this.wsHelper = new WsHelper(WS_ADDRESS, params.toString());
    this.wsHelper.onOpen = this.onOpen;
    this.wsHelper.onClose = this.onClose;
    this.wsHelper.onError = this.onError;
    this.wsHelper.onMessage = this.onMessage;
    this.wsHelper.open();
  }

  onOpen = (e: Event) => {
    console.log('ws opened');
  };

  onClose = (e: CloseEvent) => {};

  onError = (e: Event) => {};

  onMessage = (e: MessageEvent) => {
    const responsePayload: InquireeWsPayload = JSON.parse(e.data);
    console.log('message data: ', responsePayload);
    if (responsePayload.action === NotificationActions.keepAlive) {
      return;
    }
    this.props.updateInquiryEvidenceFromWs(responsePayload);
  };

  private toggleLeft = (leftCollapsed: boolean) => {
    this.setState({ leftCollapsed });
  };

  private toggleContent = (contentCollapsed: boolean) => {
    this.setState({
      contentCollapsed,
      leftCollapsed: contentCollapsed,
    });
  };

  private showInquireeModal = () => {
    this.setState({ editModalVisible: true });
  };

  private closeInquireeModal = () => {
    this.setState({ editModalVisible: false });
  };

  private saveInquiree = (
    partialValue: EvidenceRecord['detail']['inquired'],
  ) => {
    this.props.editEvidenceCategoryPersons('inquired', partialValue);
    this.closeInquireeModal();
  };

  private selectTabPane = (activeKey: string) => {
    if (activeKey === 'receive') {
      this.props.setCurrentEvidenceStatus('inquireeDirty', false);
    }
  };

  private meetingCreated = (params: MeetingSdkRoomParams) => {
    this.props.createMeeting(params);
  };

  private startMeeting = () => {
    this.setState({ meetingStarted: true });
  };

  private stopMeeting = () => {
    this.setState({ meetingStarted: false });
  };

  private addRecordLine = (value: RawInquiryRecordLine) => {
    const { rawAsrMessages } = this.state;
    const updatedRawAsrMessages = produce(rawAsrMessages, draft => {
      if (
        draft.length &&
        value.asr.sentence_id === draft[draft.length - 1].asr.sentence_id
      ) {
        draft[draft.length - 1].asr.value = value.asr.value;
      } else {
        draft.push(value);
      }
    });

    this.setState({
      rawAsrMessages: updatedRawAsrMessages,
    });
  };

  private editRecord = (value: Partial<InquiryRecordLine>) => {
    const { recordLines } = this.props;
    const remains = recordLines.find(item => {
      if (item.timestamp === value.timestamp) {
        return item;
      }
    });
    const updateLines = [
      {
        content: value.content,
        timestamp: value.timestamp,
        isDeleted: 0,
        updatedTimestamp: moment().valueOf(),
        type: remains?.type,
        images: remains?.images,
      },
    ];
    this.props.editRecord(value, this.wsHelper, updateLines);
    this.notifyInquiree();
  };

  private removeRecord = (timestamp: number) => {
    const { recordLines } = this.props;
    const remains = recordLines.find(item => {
      if (item.timestamp === timestamp) {
        return item;
      }
    });
    const updateLines = [
      {
        isDeleted: 1,
        timestamp,
        updatedTimestamp: moment().valueOf(),
        content: '',
        images: [],
        type: remains?.type,
      },
    ];
    this.props.removeRecord(timestamp, this.wsHelper, updateLines);
    this.notifyInquiree();
  };

  private addNewPair = () => {
    const currentTime = moment();
    const emptyRecordLines: InquiryRecordLine[] = [
      {
        type: InquiryRecordTypes.Ask,
        content: '',
        timestamp: currentTime.valueOf(),
        images: [],
        isDeleted: 0,
        updatedTimestamp: currentTime.valueOf(),
      },
      {
        type: InquiryRecordTypes.Answer,
        content: '',
        timestamp: currentTime.add(1, 'millisecond').valueOf(),
        images: [],
        isDeleted: 0,
        updatedTimestamp: currentTime.add(1, 'millisecond').valueOf(),
      },
    ];
    this.props.addLiveRecordLine(emptyRecordLines, this.wsHelper);
  };

  private updateRecordImages = (
    record: InquiryRecordLine,
    { id, file }: { id: string; file: string },
    included: boolean,
  ) => {
    const { timestamp, images } = record;
    const newRecord = {
      timestamp,
      images: included
        ? images?.filter(img => img.id !== id)
        : (images || []).concat({ id, file }),
    };
    const { recordLines } = this.props;
    const remains = recordLines.find(item => {
      if (item.timestamp === newRecord.timestamp) {
        return item;
      }
    });
    const updateLines = [
      {
        timestamp: remains?.timestamp,
        content: remains?.content,
        type: remains?.type,
        isDeleted: 0,
        images: newRecord.images,
        updatedTimestamp: moment().valueOf(),
      },
    ];
    this.props.editRecord(newRecord, this.wsHelper, updateLines);
  };

  private renderImagePopover = (idx: number, simple?: boolean) => {
    const { recordLines, currentEvidence } = this.props;
    const { inquirer, inquiree } = currentEvidence;
    if (!inquirer.length && !inquiree.length) {
      return (
        <Empty
          image={Empty.PRESENTED_IMAGE_SIMPLE}
          description="暂无示证、接收图片"
        />
      );
    }
    const { images } = recordLines[idx];
    const imageEvidences = (inquirer || []).concat(inquiree || []);
    const recordImages = images || [];

    if (simple) {
      return (
        <Row gutter={[8, 8]} className={styles.imageContent}>
          {recordImages.map(image => {
            const evidence = imageEvidences.find(({ id }) => id === image.id);
            if (!evidence) {
              return null;
            }
            return (
              <Col span={4}>
                <img src={evidence.detail.file.ossFileName} />
              </Col>
            );
          })}
        </Row>
      );
    }

    return (
      <Tabs>
        {inquirer.length > 0 && (
          <TabPane key="1" tab="示证">
            <Row gutter={[8, 8]} className={styles.imageContent}>
              {inquirer.map(({ detail: { file }, id }) => {
                const included =
                  recordImages.findIndex(image => image.id === id) >= 0;
                return (
                  <Col
                    span={4}
                    onClick={() => {
                      this.updateRecordImages(
                        recordLines[idx],
                        { id, file },
                        included,
                      );
                    }}
                  >
                    <>
                      <img src={file} />
                      <CheckCircleFilled
                        className={included ? styles.selected : null}
                      />
                    </>
                  </Col>
                );
              })}
            </Row>
          </TabPane>
        )}
        {inquiree.length > 0 && (
          <TabPane key="2" tab="接收">
            <Row gutter={[8, 8]} className={styles.imageContent}>
              {inquiree.map(({ detail: { file }, id }) => {
                const included =
                  recordImages.findIndex(image => image.id === id) >= 0;
                return (
                  <Col
                    span={4}
                    onClick={() =>
                      this.updateRecordImages(
                        recordLines[idx],
                        { id, file },
                        included,
                      )
                    }
                  >
                    <>
                      <img src={file} />
                      <CheckCircleFilled
                        className={included ? styles.selected : null}
                      />
                    </>
                  </Col>
                );
              })}
            </Row>
          </TabPane>
        )}
      </Tabs>
    );
  };

  private notifyInquiree = () => {
    const { recordStatus } = this.props;
    if (recordStatus.confirmed) {
      // 通知服务端需要重新确认笔录
      const wsPayload: InquireeWsPayload = {
        action: NotificationActions.editRecord,
      };
      this.wsHelper?.send(JSON.stringify(wsPayload));
    }
  };

  private confirmRecord = () => {
    const { currentInquiryId, recordLines, confirmRecord } = this.props;
    confirmRecord(currentInquiryId, recordLines, () => {
      const wsPayload: InquireeWsPayload = {
        action: NotificationActions.startRecordConfirm,
      };
      this.wsHelper?.send(JSON.stringify(wsPayload));
    });
  };

  private startSign = (identityType: InquiryIdentityTypes) => {
    const { mapIdentity } = this.props;
    const wsPayload: InquireeWsPayload = {
      action: NotificationActions.startRecordSign,
      identityId:
        mapIdentity[identityType]?.[0] ||
        getInquireeIdentityIdByMapIdentity(mapIdentity)!,
    };
    this.wsHelper?.send(JSON.stringify(wsPayload));
  };

  private startScreenshot = (type: EvidenceScreenshotType) => {
    const { screenshotSignal } = this.state;
    this.screenshotType = type;
    this.setState({ screenshotSignal: !screenshotSignal });
  };

  private screenshotFinished = (base64: string) => {
    if (!base64) {
      message.error(
        `${
          this.screenshotType === 'fingerprint' ? '捺印' : '画面'
        }截取失败，请重试！`,
      );
      return;
    }
    switch (this.screenshotType) {
      case 'fingerprint':
        this.openFingerprintModal(base64);
        return;
      case 'imageEvidence':
        getBlobsFromBase64Images([base64]).then(blobs => {
          this.props.uploadImageEvidences(blobs);
        });
    }
  };

  private openFingerprintModal = (base64: string) => {
    this.setState({
      fingerprintBase64: base64,
      fingerprintModalVisible: true,
    });
    const { getConvertedFingerprint } = this.props;
    const startIndex = base64.indexOf(',') + 1;
    const prefix = base64.substring(0, startIndex);
    getConvertedFingerprint(
      base64.substring(startIndex),
      (convertedFingerprintBase64: string) => {
        if (!convertedFingerprintBase64) {
          message.error('生成指纹失败！关闭窗口后请重新发起捺印');
          setTimeout(() => {
            this.setState({
              fingerprintBase64: '',
              fingerprintModalVisible: false,
            });
          }, 2000);
          return;
        }
        this.setState({
          convertedFingerprintBase64: prefix + convertedFingerprintBase64,
        });
      },
    );
  };

  saveConvertedFingerprint = () => {
    const { mapIdentity, editEvidencePerson } = this.props;
    const { fingerprintBase64, convertedFingerprintBase64 } = this.state;
    getBlobsFromBase64Images([
      fingerprintBase64,
      convertedFingerprintBase64,
    ]).then(blobs => {
      const identityId = getInquireeIdentityIdByMapIdentity(mapIdentity)!;
      const fileNames: Array<keyof EvidenceRecordInquiree> = [
        'fingerprintOrigin',
        'fingerprint',
      ];
      const payload = blobs.map<EvidencePersonPayload[number]>((blob, idx) => ({
        type: 'inquired',
        identityId,
        file: new File([blob], `${fileNames[idx]}.png`),
        filekey: fileNames[idx],
      }));
      editEvidencePerson(payload, () => {
        this.closeFingerprintModal();
        message.info('上传指纹成功！');
      });
    });
  };

  private closeFingerprintModal = () => {
    this.setState({
      fingerprintBase64: '',
      convertedFingerprintBase64: '',
      fingerprintModalVisible: false,
    });
  };

  private uploadSign = (signBlob: Blob, identityId: string) => {
    const fileName: keyof EvidenceRecordInquiree = 'signImage';
    const payload: EvidencePersonPayload = [
      {
        type: 'inquirer',
        file: new File([signBlob], `${fileName}.png`),
        filekey: fileName,
        identityId,
      },
    ];
    this.props.editEvidencePerson(payload, () => {
      message.info('上传签名成功！');
    });
  };

  private goToInquirySchedule = () => {
    this.props.history.replace('/inquiry/schedule');
  };

  private hangup = () => {
    Modal.confirm({
      title: '结束询问',
      content: '确认要挂断吗？',
      onOk: () => {
        this.props.endMeeting(this.goToInquirySchedule);
      },
    });
  };

  private goToInquiry = () => {
    Modal.confirm({
      content: '确认要离开询问吗？',
      onOk: this.goToInquirySchedule,
    });
  };

  render() {
    if (!this.props.currentInquiryId) {
      return <Skeleton active paragraph={{ rows: 15 }} />;
    }

    const {
      currentRole,
      meetingParams,
      inquiryInfo,
      currentEvidence,
      currentEvidenceStatus,
      mapIdentity,
      recordLines,
      screenRecord,
    } = this.props;
    const {
      leftCollapsed,
      contentCollapsed,
      editModalVisible,
      meetingStarted,
      fingerprintModalVisible,
      fingerprintBase64,
      convertedFingerprintBase64,
      rawAsrMessages,
      screenshotSignal,
    } = this.state;
    const rightWidth = contentCollapsed
      ? document.body.clientWidth
      : RIGHT_SIDER_WIDTH;
    const recordDetail = currentEvidence.record?.detail;
    const isRecorder =
      currentRole === InquirerRoles.InquirerRecorder ||
      currentRole === InquirerRoles.Recorder;

    return (
      <Layout>
        <Header
          caseName={inquiryInfo?.caseName}
          started={meetingStarted}
          onClose={this.goToInquiry}
        />
        <Left
          collapsed={leftCollapsed}
          collapsedWidth={0}
          width={LEFT_SIDER_WIDTH}
        >
          <Card.Inquiree
            value={recordDetail?.inquired}
            mapIdentity={mapIdentity}
          />
          <Card.Inquirer
            value={recordDetail?.inquirer}
            mapIdentity={mapIdentity}
            currentRole={currentRole}
            publish={<PublishTag />}
          />
        </Left>
        <Content>
          <Collapser
            placement="left"
            collapsed={leftCollapsed}
            onToggle={this.toggleLeft}
          />
          {meetingParams.bizName && (
            <Meeting
              params={meetingParams}
              floating={contentCollapsed}
              screenshotSignal={screenshotSignal}
              onCreate={this.meetingCreated}
              onStart={this.startMeeting}
              onScreenRecord={screenRecord}
              onClose={this.stopMeeting}
              onScreenshot={this.screenshotFinished}
              onAsr={this.addRecordLine}
            />
          )}
        </Content>
        <Right width={rightWidth}>
          <Collapser
            placement="left"
            collapsed={contentCollapsed}
            onToggle={this.toggleContent}
          />
          <Tabs
            defaultActiveKey="record"
            className={styles.tabs}
            onTabClick={this.selectTabPane}
          >
            <TabPane key="record" tab="笔录" className={styles.records}>
              <Row>
                <Col
                  ref={this.refRecords}
                  className={styles.recordsCol1}
                  span={contentCollapsed ? 12 : 24}
                >
                  <InquiryCard.Basic
                    record={currentEvidence.record?.detail}
                    mapIdentity={mapIdentity}
                    canEdit={isRecorder}
                    onEditInquiree={this.showInquireeModal}
                  />
                  <InquiryCard.Note
                    value={recordLines}
                    canEdit={isRecorder}
                    onEdit={this.editRecord}
                    onRemove={this.removeRecord}
                    onAddNewPair={this.addNewPair}
                    renderImagePopover={this.renderImagePopover}
                  />
                  <InquiryCard.Signature
                    role={currentRole}
                    record={currentEvidence.record?.detail}
                    mapIdentity={mapIdentity}
                    onSign={this.uploadSign}
                  />
                </Col>
                <Col
                  className={styles.recordsCol2}
                  span={contentCollapsed ? 12 : 0}
                >
                  <Record.Dialog value={rawAsrMessages} />
                </Col>
              </Row>
              <InquireeEditModal
                visible={editModalVisible}
                value={recordDetail?.inquired}
                mapIdentity={mapIdentity}
                onSave={this.saveInquiree}
                onCancel={this.closeInquireeModal}
              />
              <FingerprintModal
                visible={fingerprintModalVisible}
                origin={fingerprintBase64}
                converted={convertedFingerprintBase64}
                onOk={this.saveConvertedFingerprint}
                onCancel={this.closeFingerprintModal}
              />
            </TabPane>
            <TabPane key="evidence" tab="示证">
              <Record.Evidence
                value={currentEvidence.inquirer}
                onChange={this.props.uploadImageEvidences}
              />
            </TabPane>
            <TabPane
              key="receive"
              tab={
                currentEvidenceStatus.inquireeDirty ? (
                  <Badge status="error" offset={[8, 0]}>
                    <span className={styles.receiveStatusText}>接收</span>
                  </Badge>
                ) : (
                  '接收'
                )
              }
            >
              <Record.Receive value={currentEvidence.inquiree} />
            </TabPane>
          </Tabs>
        </Right>
        {isRecorder && (
          <Footer
            withGuardian={!!mapIdentity[InquiryIdentityTypes.Guardian]}
            onConfirmRecord={this.confirmRecord}
            onStartSign={this.startSign}
            onStartScreenshot={this.startScreenshot}
            onHangup={this.hangup}
          />
        )}
      </Layout>
    );
  }
}

const mapStateToProps = ({ inquiry, evidence }: RootModelState) => ({
  currentInquiryId: inquiry.live.currentInquiryId,
  meetingParams: inquiry.live.meetingParams,
  inquiryInfo: inquiry.inquiryInfo,
  currentEvidence: evidence.currentInquiryEvidence,
  currentEvidenceStatus: evidence.currentEvidenceStatus,
  currentRole: evidence.currentRole,
  mapIdentity: evidence.mapIdentity,
  recordLines: inquiry.live.recordLines,
  recordStatus: inquiry.live.recordStatus,
});

const mapDispatchToProps = (dispatch: Dispatch) => ({
  createMeeting: (params: MeetingSdkRoomParams) =>
    dispatch({
      type: getDispatchType(ModelNamespaces.Inquiry, 'createMeeting'),
      payload: params,
    }),
  screenRecord: (recordId: string) =>
    dispatch({
      type: getDispatchType(ModelNamespaces.Inquiry, 'addScreenRecord'),
      payload: { recordId },
    }),
  //TODO 被询问人信息更新
  editInquiree: (
    wsHelper: WsHelper | undefined,
    models: InquiryRecordInquiree[],
  ) =>
    dispatch({
      type: `${ModelNamespaces.Inquiry}/editInquiree`,
      payload: { models },
      wsHelper,
    }),
  editEvidenceCategoryPersons: (
    type: EvidencePersonType,
    partialValue: { [identityId: string]: EvidenceRecordPerson },
  ) =>
    dispatch({
      type: getDispatchType(
        ModelNamespaces.Evidence,
        'editEvidenceCategoryPersons',
      ),
      payload: { type, partialValue },
    }),
  editEvidencePerson: (payload: EvidencePersonPayload, callback: () => void) =>
    dispatch({
      type: getDispatchType(ModelNamespaces.Evidence, 'editEvidencePerson'),
      payload,
      callback,
    }),
  addLiveRecordLine: (
    emptyRecordLines: InquiryRecordLine[],
    wsHelper: WsHelper | undefined,
  ) =>
    dispatch({
      type: `${ModelNamespaces.Inquiry}/addLiveRecordLine`,
      payload: emptyRecordLines,
      wsHelper,
    }),

  editRecord: (
    value: Partial<InquiryRecordLine>,
    wsHelper: WsHelper | undefined,
    updateLines: UpdateLines,
  ) =>
    dispatch({
      type: `${ModelNamespaces.Inquiry}/editRecord`,
      payload: value,
      wsHelper,
      updateLines,
    }),
  removeRecord: (
    timestamp: number,
    wsHelper: WsHelper | undefined,
    updateLines: UpdateLines,
  ) =>
    dispatch({
      type: `${ModelNamespaces.Inquiry}/removeRecord`,
      payload: { timestamp },
      wsHelper,
      updateLines,
    }),

  updateInquiryEvidenceFromWs: (responsePayload: InquireeWsPayload) =>
    dispatch({
      type: getDispatchType(
        ModelNamespaces.Evidence,
        'updateInquiryEvidenceFromWs',
      ),
      payload: responsePayload,
    }),
  uploadImageEvidences: (files: (File | Blob)[]) =>
    dispatch({
      type: getDispatchType(ModelNamespaces.Evidence, 'uploadImageEvidences'),
      payload: { files },
    }),

  confirmRecord: (
    inquiryId: number,
    recordLines: InquiryRecordLine[],
    callback: () => void,
  ) =>
    dispatch({
      type: getDispatchType(ModelNamespaces.Inquiry, 'uploadRecordLines'),
      payload: {
        inquiryId: inquiryId,
        records: recordLines,
      },
      callback,
    }),

  getConvertedFingerprint: (
    fingerprint: string,
    callback: (convertedBase64: string) => void,
  ) =>
    dispatch({
      type: getDispatchType(ModelNamespaces.Inquiry, 'getConvertedFingerprint'),
      payload: { fingerprint },
      callback: callback,
    }),

  setCurrentEvidenceStatus: (
    key: keyof EvidenceModelState['currentEvidenceStatus'],
    value: boolean,
  ) =>
    dispatch({
      type: getDispatchType(
        ModelNamespaces.Evidence,
        'setCurrentEvidenceStatus',
      ),
      payload: { key, value },
    }),

  endMeeting: (callback: () => void) =>
    dispatch({
      type: getDispatchType(ModelNamespaces.Inquiry, 'endMeeting'),
      callback,
    }),
});

type InquiryLiveStateProps = ReturnType<typeof mapStateToProps>;
type InquiryLiveDispatchProps = ReturnType<typeof mapDispatchToProps>;

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(InquiryLive),
);
