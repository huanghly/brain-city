import { RootModelState, UserModelType } from 'umi';
import { set } from 'lodash-es';
import { ModelNamespaces } from './constants';
import api from '@/services';
import { handleError } from '@/common/util';

const UserModel: UserModelType = {
  namespace: ModelNamespaces.User,
  state: {
    users: [],
  },
  effects: {
    *getUsers({ payload, callback }, { put, call }) {
      try {
        let users = yield call(api.getUsers, payload);
        // @FIXME
        users = (users as any[]).map(({ id: userId, userName }) => ({
          userId,
          userName,
        }));
        if (payload?.caseId) {
          callback?.(users);
        } else {
          yield put({
            type: 'save',
            payload: { value: users, path: ['users'] },
          });
        }
      } catch (err) {
        handleError(err);
      }
    },
    *getCurrentUser(_, { select, put, call }) {
      let currentUser = yield select(
        (state: RootModelState) => state.user.currentUser,
      );
      if (currentUser) {
        return;
      }
      try {
        currentUser = yield call(api.getCurrentUser);
        yield put({
          type: 'save',
          payload: { value: currentUser, path: ['currentUser'] },
        });
      } catch (err) {
        handleError(err);
      }
    },
    *logout(_, { call }) {
      try {
        const loginUrl = yield call(api.logout);
        window.location.href =
          loginUrl.split('?')[0] + `?redirectUrl=${window.location.href}`;
      } catch (err) {
        handleError(err);
      }
    },
  },
  reducers: {
    save(state, action) {
      const { value, path } = action.payload;
      set(state, path, value);
    },
  },
  subscriptions: {
    setup({ dispatch, history }) {
      return history.listen(({ pathname }) => {
        dispatch({ type: 'getCurrentUser' });
        if (pathname === '/logout') {
          dispatch({
            type: 'logout',
          });
        }
      });
    },
  },
};

export default UserModel;
