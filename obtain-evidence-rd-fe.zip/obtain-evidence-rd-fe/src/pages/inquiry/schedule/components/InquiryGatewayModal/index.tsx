import React from 'react';
import moment from 'moment';
import { ReservationDisplay, InquirerRoles, ReservationStatus } from 'umi';

import { Modal, Checkbox, Form, Tag, Row, Col } from 'antd';

import styles from './index.less';
import { FormProps } from 'antd/lib/form';

interface InquiryGatewayModalProps {
  visible: boolean;
  reservation: ReservationDisplay;
  onOk: (reservationId: string, roles: InquirerRoles[]) => void;
  onCancel: () => void;
}

const InquiryGatewayModal: React.FC<InquiryGatewayModalProps> = props => {
  const [form] = Form.useForm();
  const { visible, reservation, onOk, onCancel } = props;
  const {
    id,
    roomName,
    date,
    startTime,
    endTime,
    caseName,
    inquiredName,
    status,
  } = reservation;
  const momentDate = moment(date);
  const weekday = momentDate.format('ddd');
  const formattedDate = momentDate.format('YYYY/MM/DD');

  const ok: FormProps['onFinish'] = values => {
    const { roles } = values;
    console.log(roles);
    onOk(id, roles);
  };

  const inquirerEntered = !!(status & ReservationStatus.InquirerEntered);
  const recorderEntered = !!(status & ReservationStatus.RecorderEntered);

  return (
    <Modal
      title="询问角色"
      visible={visible}
      okButtonProps={{ children: '确定变更并进入云上询问室' }}
      onOk={form.submit}
      onCancel={onCancel}
    >
      <div className={styles.info}>
        <div className={styles.title}>{roomName}</div>
        <div className={styles.duration}>
          {startTime} - {endTime}（{weekday} {formattedDate}）
        </div>
        <div className={styles.subtitles}>
          <div>{caseName}</div>
          <div>被询问人：{inquiredName}</div>
        </div>
      </div>
      <Form form={form} onFinish={ok}>
        <Form.Item
          labelCol={{ span: 24 }}
          wrapperCol={{ span: 24 }}
          label="选择询问角色"
          name="roles"
          rules={[{ required: true, message: '请选择询问角色！' }]}
        >
          <Checkbox.Group>
            <Row gutter={[12, 12]}>
              <Col span={24}>
                <Checkbox
                  disabled={inquirerEntered}
                  value={InquirerRoles.Inquirer}
                >
                  <span>询问人</span>
                  {inquirerEntered && (
                    <Tag className={styles.tag} color="warning">
                      已进入
                    </Tag>
                  )}
                </Checkbox>
              </Col>
              <Col span={24}>
                <Checkbox
                  disabled={recorderEntered}
                  value={InquirerRoles.Recorder}
                >
                  <span>记录人</span>
                  {recorderEntered && (
                    <Tag className={styles.tag} color="warning">
                      已进入
                    </Tag>
                  )}
                </Checkbox>
              </Col>
            </Row>
          </Checkbox.Group>
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default InquiryGatewayModal;
