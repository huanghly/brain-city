import React from 'react';

import { Layout } from 'antd';

const { Sider } = Layout;
import { SiderProps } from 'antd/lib/layout';

import styles from './Layout.less';

const LiveLeft: React.FC<SiderProps> = props => {
  const { children, ...restProps } = props;
  return (
    <Sider className={styles.left} {...restProps}>
      <div>{children}</div>
    </Sider>
  );
};

export default React.memo(LiveLeft);
