import React from 'react';
import classnames from 'classnames';

import styles from './Showcase.less';

export interface ShowcaseItemProps {
  style: React.CSSProperties;
  className?: string;
  index: number;
  type: 'image' | 'video';
  src: string;
  onSelect: (index: number) => void;
}

const ShowcaseItem: React.FC<ShowcaseItemProps> = props => {
  const { style, className, index, type, src, onSelect } = props;

  const cls = classnames({
    [styles.item]: true,
    [className as string]: !!className,
  });

  return (
    <div className={cls} style={style}>
      <div className={styles.img}>
        {type === 'image' && <img src={src} onClick={() => onSelect(index)} />}
        {type === 'video' && (
          <video src={src} onClick={() => onSelect(index)} />
        )}
      </div>
    </div>
  );
};

export default ShowcaseItem;
