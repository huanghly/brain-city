import React from 'react';
import { Moment } from 'moment';
import { CalendarReservation } from 'umi';
import { DaySectionsRange } from './constants';

import { Row, Col } from 'antd';
import Container from './Container';

import styles from './Calendar.less';
import { getDaySectionFromStartTime } from '@/common/util';
import { DAY_SECTIONS, DAY_HOURS } from '@/common/constants';

interface CalendarDayProps {
  date: Moment;
  value: CalendarReservation[];
}

const CalendarDay: React.FC<CalendarDayProps> = props => {
  const { date, value } = props;

  return (
    <Container>
      <div className={styles.day}>
        <div className={styles.timeline}>
          {DaySectionsRange.map(idx => (
            <div key={idx}></div>
          ))}
          {value.map((reservation, idx) => {
            const {
              startTime,
              durationHours,
              roomName,
              caseName,
            } = reservation;
            const section = getDaySectionFromStartTime(startTime) as number;

            const style: React.CSSProperties = {
              top: `${(section / DAY_SECTIONS) * 100}%`,
              height: `calc(${(durationHours / DAY_HOURS) * 100}% + 1px)`,
            };

            return (
              <div
                key={`reservation_${idx}`}
                className={styles.calendarLine}
                style={style}
              >
                <span>{roomName}</span>
                <span>（{caseName}）</span>
              </div>
            );
          })}
        </div>
      </div>
    </Container>
  );
};

export default CalendarDay;
