import React from 'react';

import { Layout } from 'antd';

import styles from './index.less';

const PortalLayout: React.FC = props => {
  const [header, sider, content] = React.Children.toArray(props.children);
  return (
    <Layout className={styles.page}>
      {header}
      <Layout>
        {sider}
        {content}
      </Layout>
    </Layout>
  );
};

export default PortalLayout;
