export default {
  // User
  getUsers: '/users',
  getCurrentUser: '/users/info',
  logout: '/users/logout',

  // Case
  getCaseTypes: '/cases/types',
  getPaginationCases: '/cases',
  getMyPaginationCases: '/cases/me',
  getMySubscriptionPaginationCases: '/cases/myretrival',
  getSuggestedCases: '/cases/select',
  addCase: 'POST /cases',
  editCase: 'PUT /cases/:id',
  removeCase: 'DELETE /cases/:caseId',
  getCaseDetail: '/cases/:caseId',
  getCaseInquiryCalendar: '/cases/inquiries/calendar',
  getCaseDayInquiries: '/cases/inquiries/day',
  downloadCaseInquiryRecord: '/evidences/record/download',
  exportCaseInquiryRecord: '/evidences/record/export',

  // Reservation
  getLocations: '/locations',
  getRooms: '/rooms',
  addReservation: 'FORM /reservations',
  removeReservation: 'DELETE /reservations/:id',
  getRecordTemplate: '/record/template/example',

  getReservationCalendar: '/reservations/calendar',
  getMyPaginationReservations: 'GET /reservations/me',
  getMyDayReservations: '/reservations/me/day',
  getMyWeekReservations: '/reservations/me/week',

  // Inquiry
  getTodayReservations: '/reservations/today',
  getWeekPaginationReservations: '/reservations/week',
  editReservation: '/reservations/actions/modify/:id',

  enterInquiry: 'POST /inquiries/actions/enter',
  createMeeting: 'POST /inquiries/rtcroom/create',
  endMeeting: 'POST /inquiries/actions/end',

  editInquiry: 'POST /inquiries/update/:inquiryId',
  getInquiryInfo: '/inquiries/reservations',

  editInquiree: '/inquiries/inquired/:inquiryId',

  // Evidence
  getEvidences: '/evidences',
  uploadEvidence: 'FORM /evidences/upload/:inquiryId',
  getConvertedFingerprint: 'FORM /evidence/extractfingerprint',
  getEvidenceQRCode: '/evidences/qrcode',
  editEvidenceCategoryPersons: 'FORM /evidences/record/:evidenceId/people',
  editEvidencePerson: 'FORM /evidences/record/:evidenceId/people/:identityId',

  getOssFiles: '/resource/url/get',

  // Workflow
  addApplication: 'POST /approval',
  getPaginationApplications: '/approval/list',
  getMyPaginationApplications: '/approval/listmyrequest',
  getMyApplicationDetail: '/listmyrequest/:id/detail',
  resolveApplication: 'PUT /approval/:id/pass',
  rejectApplication: 'PUT /approval/:id/refuse',
  revokeApplication: 'PUT /approval/:id/revoke',
  cancelApplication: 'PUT /approval/:id/cancel',
  restartApplication: 'PUT /approval/:id/restart',

  // Statistics
  getSatisticsResult: '/statistics',
  getPieData: '/statistics/case',
  getMapData: '/statistics/map',
  // Check

  // Examples:
  // defaultGet: '/get',
  // get: 'GET /get',
  // post: 'POST /post',
  // form: 'FORM /form',
  // // For restful api, put 'type' and 'id' in data.
  // // For example: { type: 'type', id: 1 }, it will be replaced.
  // restfulGet: '/get/:type/:id',
  // restfulPost: 'POST /post/:type/:id',
  // restfulForm: 'FORM /post/:type/:id',
};
