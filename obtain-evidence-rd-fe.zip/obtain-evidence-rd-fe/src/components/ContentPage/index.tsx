export { default } from './ContentPage';

export { default as TabPage } from './TabPage';
