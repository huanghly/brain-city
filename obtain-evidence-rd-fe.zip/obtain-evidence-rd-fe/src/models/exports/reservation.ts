import {
  Effect,
  ImmerReducer,
  Subscription,
  ModelNamespaces,
  ReservationStatus,
  InquiryIdentityTypes,
} from 'umi';
import { Moment } from 'moment';

export type RoomLocation = {
  id: string;
  name: string;
  children?: RoomLocation[];
};

export type RoomQueryParams = {
  roomKeyword?: string;
  locationIds?: [string, string];
  locationId?: string;
  date: string;
  begin?: number;
  end?: number;
  startTime?: Moment;
  endTime?: Moment;
};

export type RoomSchedule = {
  reservedName: string;
  periods: number[];
};

export type ReservedPeriods = { [index: number]: RoomSchedule };

export type RoomInfo = {
  roomId: string;
  roomName: string;
  schedules: RoomSchedule[];
  reservedPeriods: ReservedPeriods;
};

export type ReservationQueryParams = {
  keyword?: string;
  roomKeyword?: string;
  caseKeyword?: string;
  date?: string;
  dateTime?: Moment;
  current?: number;
  pageSize?: number;
};

export interface ReservationBase {
  id: string;
  inquiryId: string;
  date: string;
  roomId: string;
  roomName: string;
  caseId: string;
  caseName: string;
}

export interface ReservationSimple extends ReservationBase {
  startTime: string;
  endTime: string;
  status: ReservationStatus;
}

export interface ReservationPerson {
  inquirerId: string;
  inquirerName: string;
  recorderId: string;
  recorderName: string;
  inquiredName: string;
  inquiredPhone: string;
}

export type ReservationDisplay = ReservationSimple & ReservationPerson;

export type ReservationSubmit = {
  caseId: string;
  caseName: string;
  date: string;
  periods: string;
  file?: File;
  inquireds: Array<{
    identityType: InquiryIdentityTypes;
    userName: string;
    phoneNo: string;
    gender: string;
    adult: string;
  }>;
  inquirers: Array<{
    identityType: InquiryIdentityTypes;
    userId: string;
    userName: string;
  }>;
};

export interface CalendarReservation {
  date: string;
  startTime: string;
  durationHours: number;
  roomId: string;
  roomName: string;
  caseName: string;
  locationName: string;
  status: ReservationStatus;
}

export interface ReservationModelState {
  locations: RoomLocation[];
  rooms: RoomInfo[];
  roomQueryParams: RoomQueryParams;

  myReservations: PaginationModel<ReservationSimple>;
  monthReservationDates: Moment[];
  selectedDate: Moment;
  reservations: {
    day: CalendarReservation[];
    week: CalendarReservation[];
  };
}

export interface ReservationModelType {
  namespace: ModelNamespaces.Reservation;
  state: ReservationModelState;
  effects: {
    getLocations: Effect;
    getRooms: Effect;

    downloadRecordTemplate: Effect;
    addReservation: Effect;
    releaseRoom: Effect;
    getMyPaginationReservations: Effect;

    getReservationCalendar: Effect;
    setSelectedDate: Effect;
    getMyDayReservations: Effect;
    getMyWeekReservations: Effect;

    initializePageCalendar: Effect;
  };
  reducers: {
    save: ImmerReducer<ReservationModelState>;
  };
  subscriptions: { setup: Subscription };
}
