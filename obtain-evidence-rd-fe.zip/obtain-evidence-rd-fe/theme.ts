export default {
  // theme normal

  '@primary-color': '#4068E2',
  '@error-color': '#ff9c05',
  '@font-size-base': '12px',

  '@layout-header-height': '48px',
  '@layout-header-padding': '0 24px 0 0',
  '@layout-header-background': '#1a1c1f',
  '@layout-header-color': '#FFF',

  '@tabs-title-font-size': '14px',
  '@tabs-horizontal-margin': '0',
  '@tabs-horizontal-padding': '15px 24px',
  '@tabs-bar-margin': '0',

  '@badge-dot-size': '8px',

  '@calendar-border-color': 'transparent',

  '@table-header-color': '#555',

  '@form-item-trailing-colon': 'false',

  '@page-header-padding-vertical': '14px',
  '@page-header-heading-title': '20px',

  '@border-radius-base': '0',

  // theme dark

  // '@theme': 'dark',
  // '@primary-color': '#4068E2',
  // '@text-color': '#acadae',
  // '@error-color': '#ff5502',
  // '@body-background': '#121213',

  // '@font-size-base': '12px',
  // "@font-size-lg": "14px",

  // '@layout-header-height': '48px',
  // '@layout-header-padding': '0 24px 0 0',
  // '@layout-header-background': '#1a1c1f',
  // '@layout-header-color': '#FFF',
  // '@layout-sider-background': '#212326',
  // '@layout-footer-background': '@layout-header-background',

  // '@btn-default-bg': '#23262a',
  // '@btn-border-width': '0',

  // '@tabs-title-font-size': '14px',
  // '@tabs-horizontal-margin': '0',
  // '@tabs-horizontal-padding': '15px 24px',
  // '@tabs-bar-margin': '0',

  // '@card-inner-head-padding': '16px',
  // '@card-padding-base-sm': '20px',
  // '@card-head-background': '#292b2e',
  // '@card-background': 'transparent',

  // '@popover-background': '#2e2e2e',

  // '@badge-dot-size': '8px',

  // '@calendar-border-color': 'transparent',

  // '@form-item-trailing-colon': 'false',

  // '@page-header-padding-vertical': '14px',
  // '@page-header-heading-title': '20px',

  // '@border-radius-base': '0',
};
