import { set } from 'lodash-es';
import { WorkflowModelType, CaseApplication, RootModelState } from 'umi';

import {
  ModelNamespaces,
  WorkflowApprovalOperations,
  WorkflowStatus,
} from './constants';
import api from '@/services';
import {
  handleError,
  getDefaultPaginationModel,
  parseRequestPagination,
  parseResponsePagination,
} from '@/common/util';

const WorkflowModel: WorkflowModelType = {
  namespace: ModelNamespaces.Workflow,
  state: {
    newApplications: getDefaultPaginationModel(10),
    handledApplications: getDefaultPaginationModel(10),
    myApplications: getDefaultPaginationModel(10),
  },
  effects: {
    *getNewPaginationApplications({ payload }, { call, select, put }) {
      const {
        pageSize,
        current,
      }: PaginationModel<CaseApplication> = yield select(
        (state: RootModelState) => state.workflow.newApplications,
      );
      try {
        const requestParams = parseRequestPagination({
          pageSize,
          current,
          ...payload,
        });
        requestParams.statuses = WorkflowStatus.New;
        const asyncData = yield call(
          api.getPaginationApplications,
          requestParams,
        );
        const result = parseResponsePagination(asyncData);
        yield put({
          type: 'save',
          payload: { value: result, path: ['newApplications'] },
        });
      } catch (err) {
        handleError(err);
      }
    },

    *getHandledPaginationApplications({ payload }, { call, select, put }) {
      const {
        pageSize,
        current,
      }: PaginationModel<CaseApplication> = yield select(
        (state: RootModelState) => state.workflow.handledApplications,
      );
      try {
        const requestParams = parseRequestPagination({
          pageSize,
          current,
          ...payload,
        });
        requestParams.statuses = [
          WorkflowStatus.Approved,
          WorkflowStatus.Rejected,
          WorkflowStatus.Revoked,
          WorkflowStatus.Canceled,
        ].join();
        const asyncData = yield call(
          api.getPaginationApplications,
          requestParams,
        );
        const result = parseResponsePagination(asyncData);
        yield put({
          type: 'save',
          payload: { value: result, path: ['handledApplications'] },
        });
      } catch (err) {
        handleError(err);
      }
    },

    *getMyPaginationApplications({ payload }, { call, select, put }) {
      const {
        pageSize,
        current,
      }: PaginationModel<CaseApplication> = yield select(
        (state: RootModelState) => state.workflow.myApplications,
      );
      try {
        const requestParams = parseRequestPagination({
          pageSize,
          current,
          ...payload,
        });
        const asyncData = yield call(
          api.getMyPaginationApplications,
          requestParams,
        );
        const result = parseResponsePagination(asyncData);
        yield put({
          type: 'save',
          payload: { value: result, path: ['myApplications'] },
        });
      } catch (err) {
        handleError(err);
      }
    },

    *addApplication({ payload, callback }, { call }) {
      const { type, ...restPayload } = payload;
      try {
        const applicationId = yield call(api.addApplication, {
          type,
          detail: restPayload,
        });
        callback(applicationId);
      } catch (err) {
        handleError(err);
      }
    },
    *updateApplication({ payload, callback }, { call }) {
      const operation: WorkflowApprovalOperations = payload.operation;
      let requestUrl: typeof api[string];
      switch (operation) {
        case WorkflowApprovalOperations.Resolve:
          requestUrl = api.resolveApplication;
          break;
        case WorkflowApprovalOperations.Reject:
          requestUrl = api.rejectApplication;
          break;
        case WorkflowApprovalOperations.Revoke:
          requestUrl = api.revokeApplication;
          break;
        case WorkflowApprovalOperations.Cancel:
          requestUrl = api.cancelApplication;
          break;
        case WorkflowApprovalOperations.Restart:
          requestUrl = api.restartApplication;
          break;
      }
      try {
        const success = yield call(requestUrl, { id: payload.id });
        callback(success);
      } catch (err) {
        handleError(err);
      }
    },
  },
  reducers: {
    save(state, action) {
      const { value, path } = action.payload;
      set(state, path, value);
    },
  },
  subscriptions: {
    setup({ dispatch, history }) {
      return history.listen(({ pathname }) => {
        switch (pathname) {
          case '/case/application':
            dispatch({ type: 'getMyPaginationApplications' });
            break;
          case '/case/audit':
            dispatch({ type: 'getNewPaginationApplications' });
            dispatch({ type: 'getHandledPaginationApplications' });
            break;
        }
      });
    },
  },
};

export default WorkflowModel;
