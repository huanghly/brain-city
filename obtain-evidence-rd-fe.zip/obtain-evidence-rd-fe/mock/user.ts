import { random } from 'lodash';
import api from '../src/services/api';
import { UserInfo } from 'umi';
import { wrapResponse } from './util';

export const users: UserInfo[] = [
  {
    userId: '001',
    userAccount: 'zhangsan',
    userName: '张三',
  },
  {
    userId: '002',
    userAccount: 'lisi',
    userName: '李四',
  },
  {
    userId: '003',
    userAccount: 'wangwu',
    userName: '王五',
  },
  {
    userId: '004',
    userAccount: 'qianliu',
    userName: '钱六',
  },
  {
    userId: '005',
    userAccount: 'zhaoqi',
    userName: '赵七',
  },
  {
    userId: '006',
    userAccount: 'zhuba',
    userName: '朱八',
  },
  {
    userId: '007',
    userAccount: 'sunjiu',
    userName: '孙九',
  },
];

export function getRandomUsers(count: number) {
  let validCount = Math.min(count, users.length);
  const result = [];
  const poolUsers = [...users];
  while (validCount) {
    const user = poolUsers[random(0, poolUsers.length - 1)];
    result.push({ ...user });
    validCount--;
  }
  return result;
}

export default {
  [api.getCurrentUser]: wrapResponse({
    userId: '001',
    userAccount: 'zhangsan',
    userName: '张三',
  }),
  [api.getUsers]: wrapResponse(users),
};
