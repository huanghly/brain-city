import Case from './Case';
import Application from './Application';

export default {
  Case,
  Application,
};
