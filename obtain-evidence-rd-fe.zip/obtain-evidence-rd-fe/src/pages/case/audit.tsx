import React from 'react';
import {
  connect,
  ConnectProps,
  RootModelState,
  Dispatch,
  ModelNamespaces,
  CaseApplicationQueryParams,
  WorkflowTypesLocale,
  WorkflowTypes,
  WorkflowStatus,
  WorkflowStatusSetting,
  CaseApplication,
  WorkflowApprovalOperations,
} from 'umi';
import { getDispatchType } from '@/common/util';

import { Tabs, Table, Button, Badge, Popconfirm, message } from 'antd';
const { TabPane } = Tabs;
const { Column } = Table;
import { ColumnProps, TablePaginationConfig } from 'antd/lib/table';

import { TabPage } from '@/components/ContentPage';
import SearchForm from '@/pages/case/components/SearchForm';

type CaseAuditPageProps = ConnectProps &
  CaseAuditPageDispatchProps &
  CaseAuditPageStateProps;

class CaseAuditPage extends React.PureComponent<CaseAuditPageProps> {
  private newApplicationQueryParams: CaseApplicationQueryParams = {};
  private handledApplicationQueryParams: CaseApplicationQueryParams = {};

  constructor(props: CaseAuditPageProps) {
    super(props);
    const { newApplications, handledApplications } = props;
    this.newApplicationQueryParams = {
      current: newApplications.current,
      pageSize: newApplications.pageSize,
    };
    this.handledApplicationQueryParams = {
      current: handledApplications.current,
      pageSize: handledApplications.pageSize,
    };
  }

  private queryNewApplications = (queryParams: CaseApplicationQueryParams) => {
    queryParams.current = 1;
    queryParams.pageSize = this.newApplicationQueryParams.pageSize;
    this.newApplicationQueryParams = queryParams;
    this.props.getPaginationApplications(this.newApplicationQueryParams, 'new');
  };
  private queryHandledApplications = (
    queryParams: CaseApplicationQueryParams,
  ) => {
    queryParams.current = 1;
    queryParams.pageSize = this.handledApplicationQueryParams.pageSize;
    this.handledApplicationQueryParams = queryParams;
    this.props.getPaginationApplications(
      this.handledApplicationQueryParams,
      'handled',
    );
  };

  private tableNewChange = (pagination?: TablePaginationConfig) => {
    const { pageSize, current } = pagination || this.newApplicationQueryParams;
    this.newApplicationQueryParams.pageSize = pageSize;
    this.newApplicationQueryParams.current = current;
    this.props.getPaginationApplications(this.newApplicationQueryParams, 'new');
  };
  private tableHandledChange = (pagination?: TablePaginationConfig) => {
    const { pageSize, current } =
      pagination || this.handledApplicationQueryParams;
    this.handledApplicationQueryParams.pageSize = pageSize;
    this.handledApplicationQueryParams.current = current;
    this.props.getPaginationApplications(
      this.handledApplicationQueryParams,
      'handled',
    );
  };

  private auditApplication = (
    id: string,
    operation: WorkflowApprovalOperations,
  ) => {
    this.props.updateApplication(id, operation, () => {
      message.info('审批成功！');
      this.tableNewChange();
      this.tableHandledChange();
    });
  };

  private renderOperation: ColumnProps<CaseApplication>['render'] = (
    _,
    record,
  ) => {
    switch (record.status) {
      case WorkflowStatus.New:
        return (
          <React.Fragment>
            <Popconfirm
              title={`确认同意${WorkflowTypesLocale[record.type]}申请？`}
              onConfirm={() =>
                this.auditApplication(
                  record.id,
                  WorkflowApprovalOperations.Resolve,
                )
              }
            >
              <Button size="small" type="link">
                同意
              </Button>
            </Popconfirm>
            <span>|</span>
            <Popconfirm
              title={`确认拒绝${WorkflowTypesLocale[record.type]}申请？`}
              onConfirm={() =>
                this.auditApplication(
                  record.id,
                  WorkflowApprovalOperations.Reject,
                )
              }
            >
              <Button size="small" type="link">
                拒绝
              </Button>
            </Popconfirm>
          </React.Fragment>
        );
      case WorkflowStatus.Approved:
        const title = `撤销${WorkflowTypesLocale[record.type]}许可`;
        return (
          <Popconfirm
            title={`确认${title}？`}
            onConfirm={() =>
              this.auditApplication(
                record.id,
                WorkflowApprovalOperations.Revoke,
              )
            }
          >
            <Button size="small" type="link">
              {title}
            </Button>
          </Popconfirm>
        );
      default:
        return null;
    }
  };

  render() {
    const { newApplications, handledApplications } = this.props;

    return (
      <TabPage title="我的审批">
        <Tabs defaultActiveKey="applicationNew">
          <TabPane
            tab={`待审批(${newApplications.total || 0})`}
            key="applicationNew"
          >
            <AuditTabContent
              pagination={newApplications}
              renderOperation={this.renderOperation}
              onQuery={this.queryNewApplications}
              onTableChange={this.tableNewChange}
            />
          </TabPane>
          <TabPane
            tab={`已审批(${handledApplications.total || 0})`}
            key="applicationApproved"
          >
            <AuditTabContent
              pagination={handledApplications}
              renderOperation={this.renderOperation}
              onQuery={this.queryHandledApplications}
              onTableChange={this.tableNewChange}
            />
          </TabPane>
        </Tabs>
      </TabPage>
    );
  }
}

const mapStateToProps = (state: RootModelState) => ({
  newApplications: state.workflow.newApplications,
  handledApplications: state.workflow.handledApplications,
});

const mapDispatchToProps = (dispatch: Dispatch) => ({
  getPaginationApplications: (
    queryParams: CaseApplicationQueryParams,
    type: 'new' | 'handled',
  ) =>
    dispatch({
      type: getDispatchType(
        ModelNamespaces.Workflow,
        type === 'new'
          ? 'getNewPaginationApplications'
          : 'getHandledPaginationApplications',
      ),
      payload: queryParams,
    }),
  updateApplication: (
    id: string,
    operation: WorkflowApprovalOperations,
    callback: () => void,
  ) =>
    dispatch({
      type: getDispatchType(ModelNamespaces.Workflow, 'updateApplication'),
      payload: { id, operation },
      callback,
    }),
  applyCaseSubscription: (caseId: string, callback: () => void) =>
    dispatch({
      type: getDispatchType(ModelNamespaces.Workflow, 'addApplication'),
      payload: { caseId, type: WorkflowTypes.Subscription },
      callback,
    }),
});

type CaseAuditPageStateProps = ReturnType<typeof mapStateToProps>;
type CaseAuditPageDispatchProps = ReturnType<typeof mapDispatchToProps>;

export default connect(mapStateToProps, mapDispatchToProps)(CaseAuditPage);

interface AuditTabContentProps {
  pagination: PaginationModel<CaseApplication>;
  renderOperation: ColumnProps<CaseApplication>['render'];
  onQuery: (queryParams: Partial<CaseApplicationQueryParams>) => void;
  onTableChange: (paginationConfig?: TablePaginationConfig) => void;
}

const AuditTabContent: React.FC<AuditTabContentProps> = props => {
  const { pagination, renderOperation, onQuery, onTableChange } = props;
  const { list, ...paginationProps } = pagination;

  return (
    <>
      <SearchForm.Application onChange={onQuery} />
      <Table
        className="g-table-list"
        rowKey="id"
        pagination={{ ...paginationProps, showSizeChanger: true }}
        dataSource={list}
        onChange={onTableChange}
      >
        <Column title="案事件名称" dataIndex="caseName" />
        <Column title="申请人" width={120} dataIndex="applicant" />
        <Column
          title="申请日期"
          align="center"
          width={120}
          dataIndex="applicationDate"
        />
        <Column title="申请事由" dataIndex="reasons" />
        <Column
          title="申请类型"
          align="center"
          width={120}
          dataIndex="type"
          render={(value: WorkflowTypes) => WorkflowTypesLocale[value] || '-'}
        />
        <Column
          title="状态"
          dataIndex="status"
          width={150}
          render={(value: WorkflowStatus) => {
            const { color, text } = WorkflowStatusSetting[value];
            return <Badge color={color} text={text} />;
          }}
        />
        <Column
          title="操作"
          align="center"
          width={120}
          render={renderOperation}
        />
      </Table>
    </>
  );
};
