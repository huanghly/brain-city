import React, { useState } from 'react';
import moment from 'moment';
import classnames from 'classnames';
import {
  EvidenceRecord,
  InquirerRoles,
  InquiryMapIdentity,
  InquiryIdentityTypes,
  getInquireeIdentityIdByMapIdentity,
} from 'umi';

import { EditOutlined } from '@ant-design/icons';
import { Row, Col, Spin } from 'antd';
import SignatureDrawer from './Drawer';

import styles from '../InquiryCard.less';

interface InquirySignatureCardProps {
  role: InquirerRoles;
  record?: EvidenceRecord['detail'];
  mapIdentity: InquiryMapIdentity;
  onSign?: (blob: Blob, identityId: string) => void;
}

const InquirySignatureCard: React.FC<InquirySignatureCardProps> = props => {
  const { role, record, mapIdentity, onSign } = props;
  if (!record) {
    return <Spin />;
  }

  const [modalVisible, setModalVisible] = useState(false);
  const [signIdentityId, setSignIdentityId] = useState('');

  // @TODO 公益诉讼多被询问人
  const { inquirer, inquired } = record;
  const inquirerInfo = inquirer[mapIdentity[InquiryIdentityTypes.Inquirer]![0]];
  const recorderInfo = inquirer[mapIdentity[InquiryIdentityTypes.Recorder]![0]];
  const womanInquirerInfo =
    inquirer[mapIdentity[InquiryIdentityTypes.WomanInquirer]?.[0] || ''];
  const currentInquireeIdentityId = getInquireeIdentityIdByMapIdentity(
    mapIdentity,
  )!;
  const inquireeInfo = inquired[currentInquireeIdentityId];

  const cls = classnames({
    [styles.signature]: true,
    [styles.gap]: true,
  });

  return (
    <div className={cls}>
      <Row>
        <Col>笔录确认开始时间：</Col>
        <Col flex={1} className={styles.underlined}>
          {inquireeInfo.confirmBeginTime &&
            moment(inquireeInfo.confirmBeginTime).format(
              'YYYY年M月D日 HH时mm分ss秒',
            )}
        </Col>
      </Row>
      <Row>
        <Col>笔录确认结束时间：</Col>
        <Col flex={1} className={styles.underlined}>
          {inquireeInfo.confirmEndTime &&
            moment(inquireeInfo.confirmEndTime).format(
              'YYYY年M月D日 HH时mm分ss秒',
            )}
        </Col>
      </Row>
      <Row justify="center" className={styles.confirmImg}>
        {inquireeInfo.confirmImage && (
          <img src={inquireeInfo.confirmImage.ossFileName} />
        )}
      </Row>
      <Row align="middle" justify="space-between">
        <Col>被询问人签字：</Col>
        {inquireeInfo.signImage ? (
          <Col className={styles.signImg}>
            <img src={inquireeInfo.signImage.ossFileName} />
          </Col>
        ) : (
          <Col flex={1}>待签字</Col>
        )}
      </Row>
      <Row align="middle" justify="space-between">
        <Col>被询问人捺印：</Col>
        {inquireeInfo.fingerprint ? (
          <Col className={styles.signImg}>
            <img src={inquireeInfo.fingerprint.ossFileName} />
          </Col>
        ) : (
          <Col flex={1}>待捺印</Col>
        )}
      </Row>
      <Row align="middle" justify="space-between">
        <Col>询问人签字：</Col>
        {inquirerInfo.signImage ? (
          <Col className={styles.signImg}>
            <img src={inquirerInfo.signImage.ossFileName} />
          </Col>
        ) : role === InquirerRoles.Inquirer ||
          role === InquirerRoles.InquirerRecorder ? (
          <Col flex={1}>
            <EditOutlined
              onClick={() => {
                setSignIdentityId(inquirerInfo.identityId);
                setModalVisible(true);
              }}
            />
          </Col>
        ) : (
          <Col flex={1}>待签字</Col>
        )}
      </Row>
      <Row align="middle" justify="space-between">
        <Col>记录人签字：</Col>
        {recorderInfo.signImage ? (
          <Col className={styles.signImg}>
            <img src={recorderInfo.signImage.ossFileName} />
          </Col>
        ) : role === InquirerRoles.Recorder ||
          role === InquirerRoles.InquirerRecorder ? (
          <Col flex={1}>
            <EditOutlined
              onClick={() => {
                setSignIdentityId(recorderInfo.identityId);
                setModalVisible(true);
              }}
            />
          </Col>
        ) : (
          <Col flex={1}>待签字</Col>
        )}
      </Row>
      {!!womanInquirerInfo && (
        <Row align="middle" justify="space-between">
          <Col>女性办案人员签字：</Col>
          {womanInquirerInfo.signImage ? (
            <Col className={styles.signImg}>
              <img src={womanInquirerInfo.signImage.ossFileName} />
            </Col>
          ) : role === InquirerRoles.Recorder ||
            role === InquirerRoles.InquirerRecorder ? (
            <Col flex={1}>
              <EditOutlined
                onClick={() => {
                  setSignIdentityId(womanInquirerInfo.identityId);
                  setModalVisible(true);
                }}
              />
            </Col>
          ) : (
            <Col flex={1}>待签字</Col>
          )}
        </Row>
      )}
      {modalVisible && (
        <SignatureDrawer
          visible={modalVisible}
          onOk={blob => {
            onSign?.(blob, signIdentityId);
            setModalVisible(false);
          }}
          onCancel={() => setModalVisible(false)}
        />
      )}
    </div>
  );
};

export default React.memo(InquirySignatureCard);
