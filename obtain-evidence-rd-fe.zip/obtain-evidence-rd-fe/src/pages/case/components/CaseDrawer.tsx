import React, { useEffect } from 'react';
import { omit } from 'lodash-es';
import { Case, CaseType, UserInfo } from 'umi';

import { Drawer, Button, Form, Input, Cascader, Select } from 'antd';
const { Option } = Select;
import { FormItemProps, FormProps } from 'antd/lib/form';

import { DEFAULT_SPLITTER } from '@/common/constants';

const formItemLayout: Partial<FormItemProps> = {
  labelCol: { span: 6 },
  wrapperCol: { span: 18 },
};

interface CaseDrawerProps {
  visible: boolean;
  value?: Partial<Case>;
  caseTypes: CaseType[];
  users: UserInfo[];
  onSave: (value: Case) => void;
  onCancel: () => void;
}

const CaseDrawer: React.FC<CaseDrawerProps> = props => {
  const [form] = Form.useForm();
  const { visible, value, caseTypes, users, onSave, onCancel } = props;

  useEffect(() => {
    if (value && visible && value.id) {
      const types = [value.typeId, value.subTypeId];
      const participants =
        value.participants?.map(({ userId, userName }) =>
          [userId, userName].join(DEFAULT_SPLITTER),
        ) || [];
      const dutyUser = [value.dutyUserId, value.dutyUserName].join(
        DEFAULT_SPLITTER,
      );
      const fieldValues = {
        ...value,
        types,
        dutyUser,
        participants,
      };
      form.setFieldsValue(fieldValues);
    }
  }, [value, visible]);

  const save: FormProps['onFinish'] = values => {
    const [dutyUserId, dutyUserName] = values.dutyUser.split(DEFAULT_SPLITTER);
    values.participants = values.participants.map((p: string) => {
      const [userId, userName] = p.split(DEFAULT_SPLITTER);
      return { userId, userName };
    });
    values.dutyUserId = dutyUserId;
    values.dutyUserName = dutyUserName;
    values.type = values.types[0];
    values.subType = values.types[1];

    const caseValue = omit(values, ['dutyUser', 'types']) as Case;
    onSave(caseValue);
  };

  const userOptions = users.map(({ userId, userName }) => (
    <Option key={userId} value={[userId, userName].join(DEFAULT_SPLITTER)}>
      {userName}
    </Option>
  ));

  const resetFields = (isOpen: boolean) => {
    if (!isOpen) {
      form.resetFields();
    }
  };

  return (
    <Drawer
      title={`${value?.id ? '编辑' : '新增'}案事件档案`}
      visible={visible}
      width={640}
      footer={
        <div className="button-group">
          <Button type="primary" onClick={form.submit}>
            确定
          </Button>
          <Button onClick={onCancel}>取消</Button>
        </div>
      }
      afterVisibleChange={resetFields}
      onClose={onCancel}
    >
      <Form form={form} labelAlign="left" onFinish={save}>
        <Form.Item hidden name="id">
          <Input />
        </Form.Item>
        <Form.Item
          label="案事件名称"
          name="title"
          rules={[{ required: true }]}
          {...formItemLayout}
        >
          <Input placeholder="请填写案事件名称" />
        </Form.Item>
        <Form.Item
          label="案事件类型"
          name="types"
          rules={[{ required: true }]}
          {...formItemLayout}
        >
          <Cascader
            options={caseTypes}
            fieldNames={{ label: 'name', value: 'id' }}
            placeholder="请选择类型"
          />
        </Form.Item>
        <Form.Item
          label="案件负责人"
          name="dutyUser"
          rules={[{ required: true }]}
          {...formItemLayout}
        >
          <Select>{userOptions}</Select>
        </Form.Item>
        <Form.Item
          label="参与侦办人"
          name="participants"
          rules={[{ required: true }]}
          {...formItemLayout}
        >
          <Select mode="multiple">{userOptions}</Select>
        </Form.Item>
        <Form.Item label="建档人" {...formItemLayout}>
          <Input disabled value={value?.creatorName} />
        </Form.Item>
      </Form>
    </Drawer>
  );
};

export default CaseDrawer;
