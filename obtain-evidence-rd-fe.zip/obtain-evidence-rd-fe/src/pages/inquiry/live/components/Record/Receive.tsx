import React, { useState } from 'react';
import { EvidenceImage } from 'umi';

import { CloseCircleFilled } from '@ant-design/icons';
import { Spin, Row, Col, Empty } from 'antd';

import styles from './Record.less';

interface ReceiveEvidenceProps {
  value?: EvidenceImage[];
}

const ReceiveEvidence: React.FC<ReceiveEvidenceProps> = props => {
  const { value } = props;
  if (!value) {
    return <Spin />;
  }

  const [selectedEvidence, setSelectedEvidence] = useState<
    EvidenceImage['detail']
  >();

  return (
    <div className={styles.evidence}>
      {value.length ? (
        <Row gutter={[4, 4]}>
          {value.map(({ detail }, idx) => (
            <Col key={idx}>
              <div className={styles.evidenceItem}>
                <img
                  src={detail.file.ossFileName}
                  className={styles.evidenceImage}
                  onClick={() => {
                    setSelectedEvidence(detail);
                  }}
                />
              </div>
            </Col>
          ))}
        </Row>
      ) : (
        <Row align="middle" justify="center">
          <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="暂无接收" />
        </Row>
      )}
      {selectedEvidence && (
        <div className={styles.receive}>
          <div className={styles.shadow}>
            <Row align="middle" justify="end" className={styles.warning}>
              {/* @TODO */}
              {/* <CloseCircleFilled color="danger" />
              <label>有 PS 痕迹</label> */}
            </Row>
          </div>
          <div className={styles.img}>
            <img
              className="g-fit-contain"
              src={selectedEvidence.file.ossFileName}
            />
          </div>
          <Row align="middle" className={styles.sign}>
            <Col>签字确认信息：</Col>
            <Col flex="1" className={styles.signImage}>
              <img
                src={selectedEvidence.inquiredSignImage.ossFileName}
                className="g-fit-contain"
              />
            </Col>
          </Row>
        </div>
      )}
    </div>
  );
};

export default React.memo(ReceiveEvidence);
