import moment from 'moment';
import { InquiryRecordLine, MapConfig } from 'umi';
import { InquiryRecordTypes } from '@/models/constants';

/**
 * 云上取证 type=1
 */
export const CLOUD_SYSTEM_TYPE = 1;
export const DAY_HOURS = 24;
export const HOUR_MINUTES = 60;
export const DAY_SECTIONS = DAY_HOURS * 2;
export const MINUTE_STEP = (DAY_HOURS * HOUR_MINUTES) / DAY_SECTIONS;
export const DAYS_OF_WEEK = 7;

export const DEFAULT_PAGE_SIZE = 10;

export const SEARCH_FORM_CHANGE_DEBOUNCE = 800;

export const DEFAULT_SPLITTER = '@@@';

export const WS_ADDRESS = `wss://${window.location.host}/websocket/`;

const currentTime = new Date().getTime();

export enum NotificationActions {
  keepAlive = 'KEEP_ALIVE',
  imageEvidenceUploaded = 'IMAGE_EVIDENCE_UPLOADED',
  imageEvidenceConfirmed = 'IMAGE_EVIDENCE_CONFIRMED',
  startRecordConfirm = 'START_RECORD_CONFIRM',
  startRecordSign = 'START_RECORD_SIGN',
  editRecord = 'EDIT_EVIDENCE',
  recordConfirmed = 'RECORD_CONFIRMED',
  recordSigned = 'RECORD_SIGNED',
  recordEdited = 'RECORD_EDITED', //笔录更新通知
}

// @FIXME 等询问动态模板功能完成后，彻底删除以下注释
export const DEFAULT_RECORD_LINES: InquiryRecordLine[] = [
  // {
  //   type: InquiryRecordTypes.Ask,
  //   content:
  //     '现依法向你询问有关问题，你应该如实提供证据、证言，如果有意作伪证或者隐匿罪证的，要负法律责任。你听明白了吗？',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Answer,
  //   content: '',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Ask,
  //   content: `现依法向你宣读《被害人诉讼权利义务告知书》。根据《中华人民共和国刑事诉讼法》的规定，在公安机关对案件进行侦查期间，被害人有如下权利和义务：
  //     权利：
  //     1、有用本民族的语言文字进行诉讼的权利。
  //     2、对侦查人员侵犯其诉讼权利或者进行人身侮辱的行为，有权提出控告。
  //     3、对于侦查人员、鉴定人、记录人、翻译人员有下列情形之一的，被害人及其法定代理人有权申请回避：
  //     （一）是本案的当事人
  //     或者当事人的近亲属的；
  //     （二）本人或者他的近亲属和本案有利害关系的；
  //     （三）担任过本案的证人、鉴定人、辩护人、诉讼代理人的；
  //     （四）与本案当事人有其他关系，可能影响公正处理案件的。对驳回申请回避的决定，可以申请复议一次。
  //     4、被害人由于被告人的犯罪行为而遭受物质损失的，在刑事诉讼过程中，有权提起附带民事诉讼。
  //     5、对于被害人的报案，公安机关作出不予立案决定的，被害人如果不服，可以申请复议。
  //     6、被害人认为公安机关对应当立案侦查的案件而不立案侦查，有权向人民检察院提出。
  //     7、被害人有权核对询问笔录。被害人没有阅读能力的，侦查人员应当向其宣读。如果记载有遗漏或者差错，被害人可以提出补充或者改正。被害人有权自行书写被害人陈述。
  //     8、有权知道用作证据的鉴定结论的内容，可以申请补充鉴定或者重新鉴定。
  //     义务：
  //     1、当如实地提供证据，作为陈述，捏造事实诬告陷害他人或者隐匿罪证应负法律责任。
  //        以上内容向你宣读完毕，你听清楚了吗？`,
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Answer,
  //   content: '我听清楚了。',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Ask,
  //   content: '你是否提出回避申请？',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Answer,
  //   content: '',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Ask,
  //   content: '你因何事到报案？',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Answer,
  //   content: '',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Ask,
  //   content: '你将事情的经过讲一讲？',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Answer,
  //   content: '',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Ask,
  //   content: '事情发生的时间和地点？',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Answer,
  //   content: '',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Ask,
  //   content: '对方是如何诈骗你的？',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Answer,
  //   content: '',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Ask,
  //   content: '你与对方如何认识的？',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Answer,
  //   content: '',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Ask,
  //   content: '你与对方的联系方式？',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Answer,
  //   content: '',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Ask,
  //   content: '对方的电话号码和QQ号（微信号）多少？',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Answer,
  //   content: '',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Ask,
  //   content: '你的电话和QQ号（微信号）是多少？',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Answer,
  //   content: '',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Ask,
  //   content:
  //     '你与对方聊天记录，对方网站情况，相关手机短信，手机通话记录是否保存，能否提供给我们？',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Answer,
  //   content: '',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Ask,
  //   content: '你是通过什么方式转账的？',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Answer,
  //   content: '',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Ask,
  //   content: '你一共给对方转了多少钱？',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Answer,
  //   content: '',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Ask,
  //   content: '你的支付账户信息？',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Answer,
  //   content: '',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Ask,
  //   content: '对方的收款账户信息？',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Answer,
  //   content: '',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Ask,
  //   content: '你的打款明细？包括银行卡账号、开户行，对方的银行卡账号、开户行',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Answer,
  //   content: '',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Ask,
  //   content: '你是否还有其他要补充的？',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Answer,
  //   content: '',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Ask,
  //   content: '以上笔录是否属实？',
  //   timestamp: currentTime,
  // },
  // {
  //   type: InquiryRecordTypes.Answer,
  //   content: '',
  //   timestamp: currentTime,
  // },
];

DEFAULT_RECORD_LINES.forEach((line, idx) => {
  line.timestamp += idx;
});

export const STATISTICS_ITEMS = [
  {
    key: 'caseCount',
    title: '云上累计案件',
    unit: '起',
    icon: 'iconanjian',
  },
  {
    key: 'inquiryCount',
    title: '累计询问时长',
    unit: '小时',
    icon: 'iconshichang',
  },
  {
    key: 'recordCount',
    title: '累计记录笔录',
    unit: '起',
    icon: 'icon-note',
  },
  {
    key: 'evidenceCount',
    title: '累计电子物证',
    unit: '份',
    icon: 'icon-evidence',
  },
  {
    key: 'timeSaved',
    title: '预估累积节约',
    unit: '小时',
    icon: 'iconjieyue-copy',
  },
  {
    key: 'paperSaved',
    title: '预估节约纸张',
    unit: '张',
    icon: 'icon-paper',
  },
  {
    key: 'retrievalCount',
    title: '已累积调阅案卷',
    unit: '(实时)',
    icon: 'icon-archive',
  },
  {
    key: 'inquiredCount',
    title: '已累积询问人次',
    unit: '(实时)',
    icon: 'icon-user-group',
  },
];

export const MAP_CONFIG: MapConfig = {
  key: 'map',
  map: {
    center: [110.19382669582967, 38.258134],
    pitch: 0,
    style: 'light',
    zoom: 3.8,
  },
  style: {
    position: 'relative',
    width: '100%',
    height: '100%',
  },
};

export const DONUT_CONFIG = {
  key: 'donut',
  forceFit: true,
  radius: 0.6,
  padding: 'auto',
  angleField: 'value',
  colorField: 'type',
  label: {
    visible: true,
    type: 'outer-center',
    formatter: (text: any, item: any) =>
      `${item._origin.type}: ${item._origin.value}`,
  },
  legend: {
    visible: false,
  },
};

export const LINE_CONFIG = {
  key: 'line',
  options: {
    autoFit: true,
  },
  shape: {
    values: 'arc',
  },
  color: { values: '#2950B8' },
  size: {
    values: 4,
  },
  animate: {
    duration: 4,
    interval: 1,
    trailLength: 2,
  },
  style: {
    opacity: 1,
  },
};

export const POINT_CONFIG = {
  key: 'point',
  shape: {
    values: 'circle',
  },
  color: { values: '#4068E2' },
  size: {
    values: 20,
  },
  animate: {
    speed: 0.5,
  },
  active: {
    option: true,
  },
  style: {
    opacity: 0.9,
  },
};

export const MARKER_CONFIG = {
  option: {
    color: '#E7000C',
  },
  onMarkerLoaded: function(e: any) {
    const svgElement = e.getElement().children[0];
    svgElement.setAttribute('height', '24px');
  },
};
