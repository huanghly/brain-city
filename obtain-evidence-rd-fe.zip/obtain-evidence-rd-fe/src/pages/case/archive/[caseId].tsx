import React from 'react';
import moment, { Moment } from 'moment';
import {
  connect,
  ConnectProps,
  RootModelState,
  ModelNamespaces,
  Dispatch,
  CaseQueryTypes,
} from 'umi';
import { getDispatchType } from '@/common/util';

import { ArrowLeftOutlined } from '@ant-design/icons';
import { Row, Col, Tabs, Empty, message } from 'antd';
const { TabPane } = Tabs;

import ContentPage from '@/components/ContentPage';
import CalendarSelector from '@/components/Calendar/Selector';

import CaseCard from './components/CaseCard';
import CaseInquiry from './components/CaseInquiry';
import CaseEvidence from './components/CaseEvidence';

import styles from './archive.less';

type CaseArchiveDetailProps = ConnectProps &
  CaseArchiveDetailStateProps &
  CaseArchiveDetailDispatchProps;

class CaseArchiveDetail extends React.PureComponent<CaseArchiveDetailProps> {
  private goToCaseArchive = () => {
    const { history } = this.props;
    if (history.length) {
      history.goBack();
    } else {
      history.replace(`/case/${CaseQueryTypes.All}`);
    }
  };

  private changeMonth = (step: 1 | -1) => {
    const { selectedDate } = this.props;
    const nextSelectedDate = selectedDate.add(step, 'month');
    this.selectDate(nextSelectedDate);
  };

  private selectDate = (date: Moment) => {
    this.props.setSelectedDate(date);
  };

  private selectTabPane = (key: string) => {
    const inquiryId = +key;
    const { caseInquiriesEvidences, getCaseInquiryEvidences } = this.props;
    if (caseInquiriesEvidences[inquiryId]) {
      return;
    }
    getCaseInquiryEvidences(inquiryId);
  };

  render() {
    const {
      currentCase,
      selectedDate,
      monthInquiryDates,
      dayInquiries,
      caseInquiriesEvidences,
    } = this.props;

    return (
      <ContentPage
        title="详情"
        bordered={false}
        backIcon={<ArrowLeftOutlined />}
        onBack={this.goToCaseArchive}
      >
        <Row className={styles.detail}>
          <Col className={styles.left}>
            <CaseCard.Sketch value={currentCase} />
            <CalendarSelector
              className={styles.calendar}
              dates={monthInquiryDates}
              value={selectedDate}
              selectedStyleType="color"
              onChangeMonth={this.changeMonth}
              onSelect={this.selectDate}
            />
            <CaseCard.Description />
          </Col>
          <Col className={styles.right}>
            {!dayInquiries.length ? (
              <Empty
                image={Empty.PRESENTED_IMAGE_SIMPLE}
                description="今日无询问数据"
              />
            ) : (
              <Tabs
                className={styles.recordTabs}
                type="card"
                onTabClick={this.selectTabPane}
              >
                {dayInquiries.map(inquiry => {
                  const { evidence, mapIdentity } =
                    caseInquiriesEvidences[inquiry.inquiryId] || {};

                  const currentRecord = evidence?.record;
                  const inquireeImages = evidence?.inquiree;
                  const inquirerImages = evidence?.inquirer;
                  const video = evidence?.video;
                  const screen = evidence?.screen;

                  return (
                    <TabPane
                      key={inquiry.inquiryId}
                      tab={<CaseInquiry.TabBar inquiry={inquiry} />}
                    >
                      <div className={styles.record}>
                        <CaseInquiry.Record
                          value={currentRecord}
                          mapIdentity={mapIdentity}
                          onDownload={this.props.downloadInquiry}
                          onExport={this.props.exportInquiry}
                          onGetQRCode={this.props.getEvidenceQRCode}
                        />
                      </div>
                      <div className={styles.evidence}>
                        <CaseEvidence.Tabs>
                          <CaseEvidence.ImageEvidence
                            inquiree={inquireeImages}
                            inquirer={inquirerImages}
                            record={currentRecord}
                          />
                          <div></div>
                          <CaseEvidence.VideoEvidence value={screen} />
                          <CaseEvidence.VideoEvidence value={video} />
                        </CaseEvidence.Tabs>
                      </div>
                    </TabPane>
                  );
                })}
              </Tabs>
            )}
          </Col>
        </Row>
      </ContentPage>
    );
  }
}

const mapStateToProps = (state: RootModelState) => ({
  currentCase: state.case.currentCase,
  caseInquiriesEvidences: state.evidence.caseInquiriesEvidences,
  selectedDate: state.case.selectedDate,
  monthInquiryDates: state.case.monthInquiryDates,
  dayInquiries: state.case.dayInquiries,
});

const mapDispatchToProps = (dispatch: Dispatch) => ({
  getCaseInquiryEvidences: (inquiryId: number) =>
    dispatch({
      type: getDispatchType(
        ModelNamespaces.Evidence,
        'getCaseInquiryEvidences',
      ),
      payload: { inquiryId },
    }),
  setSelectedDate: (date: Moment) =>
    dispatch({
      type: getDispatchType(ModelNamespaces.Case, 'setSelectedDate'),
      payload: { date },
    }),
  downloadInquiry: (inquiryId: number) =>
    dispatch({
      type: getDispatchType(ModelNamespaces.Download, 'downloadInquiryRecord'),
      payload: { inquiryId },
    }),
  exportInquiry: (inquiryId: number) =>
    dispatch({
      type: getDispatchType(ModelNamespaces.Download, 'exportInquiryRecord'),
      payload: { inquiryId },
    }),
  getEvidenceQRCode: (uuid: string, callback: (base64: string) => void) => {
    dispatch({
      type: getDispatchType(ModelNamespaces.Case, 'getEvidenceQRCode'),
      payload: { uuid },
      callback,
    });
  },
});

type CaseArchiveDetailStateProps = ReturnType<typeof mapStateToProps>;
type CaseArchiveDetailDispatchProps = ReturnType<typeof mapDispatchToProps>;

export default connect(mapStateToProps, mapDispatchToProps)(CaseArchiveDetail);
