import React, { useRef, useEffect } from 'react';
import classnames from 'classnames';

import { LeftOutlined, RightOutlined } from '@ant-design/icons';

import styles from './index.less';

export type CollapserPlacement = 'right' | 'left';

const CollapserIconSetting: {
  [key in CollapserPlacement]: [React.ReactNode, React.ReactNode];
} = {
  left: [<LeftOutlined />, <RightOutlined />],
  right: [<RightOutlined />, <LeftOutlined />],
};

interface CollapserProps {
  placement: CollapserPlacement;
  collapsed: boolean;
  onToggle: (collapsed: boolean) => void;
}

const Collapser: React.FC<CollapserProps> = props => {
  const { placement, collapsed, onToggle } = props;
  const icon = CollapserIconSetting[placement][Number(collapsed)];
  const ref = useRef<HTMLDivElement>();
  useEffect(() => {
    const parentElem = ref.current?.parentElement;
    if (parentElem) {
      parentElem.style.position = 'relative';
      parentElem.style.overflowX = 'visible';
    }
  }, []);

  const cls = classnames({
    [styles.collapser]: true,
    [styles.left]: placement === 'left',
    [styles.right]: placement === 'right',
    [styles.collapsed]: collapsed,
  });
  return (
    <div ref={ref} className={cls} onClick={() => onToggle(!collapsed)}>
      {icon}
    </div>
  );
};

export default Collapser;
