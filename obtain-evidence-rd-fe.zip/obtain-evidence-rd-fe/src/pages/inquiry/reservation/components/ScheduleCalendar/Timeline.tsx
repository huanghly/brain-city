import React from 'react';
import classnames from 'classnames';
import { CalendarReservation } from 'umi';

import { ClockCircleFilled } from '@ant-design/icons';
import { Card, Row, Timeline, Empty } from 'antd';

import styles from './ScheduleCalendar.less';

interface ScheduleTimelineProps {
  className?: string;
  value: CalendarReservation[];
}

const ScheduleTimeline: React.FC<ScheduleTimelineProps> = props => {
  const { className, value } = props;

  const cls = classnames({
    [styles.timeline]: true,
    [className as string]: !!className,
  });
  return (
    <Card
      size="small"
      className={cls}
      bordered={false}
      title={
        <Row align="middle" className={styles.title}>
          <ClockCircleFilled /> <span> 今天预约</span>
        </Row>
      }
    >
      {value?.length ? (
        <Timeline mode="left">
          {value.map((reservation, idx) => (
            <Timeline.Item
              key={idx}
              label={
                <div className={styles.timelineDesc}>
                  <div>{reservation.startTime}</div>
                  <div>{reservation.durationHours}小时</div>
                </div>
              }
            >
              <div className={styles.timelineDesc}>
                <div>{reservation.roomName}</div>
                <div>{reservation.caseName}</div>
              </div>
            </Timeline.Item>
          ))}
        </Timeline>
      ) : (
        <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
      )}
    </Card>
  );
};

export default ScheduleTimeline;
