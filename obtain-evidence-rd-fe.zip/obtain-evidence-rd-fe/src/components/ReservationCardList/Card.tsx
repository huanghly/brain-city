import React from 'react';
import moment from 'moment';
import classnames from 'classnames';

import {
  ReservationSimple,
  ReservationDisplay,
  ReservationStatusSetting,
  DefaultReservationStatus,
  ReservationStatus,
} from 'umi';

import { Card, Row, Col, Badge, Tag } from 'antd';

import styles from './index.less';

export interface ReservationCardProps {
  className?: string;
  bordered?: boolean;
  value: ReservationSimple;
  renderFooter?: (
    id: string,
    status: ReservationStatus,
    reservation: ReservationSimple,
  ) => React.ReactNode;
}

const ReservationCard: React.FC<ReservationCardProps> = props => {
  const { className, bordered, value, renderFooter } = props;
  const {
    id,
    roomName,
    status,
    date,
    startTime,
    endTime,
    caseName,
    inquiredName,
    inquirerName,
    recorderName,
  } = value as ReservationDisplay;
  const { text, color } =
    ReservationStatusSetting[status] || DefaultReservationStatus;
  const momentDate = moment(date);
  const weekday = momentDate.format('ddd');
  const formattedDate = momentDate.format('YYYY/MM/DD');

  const cardCls = classnames({
    [styles.card]: true,
    [className as string]: !!className,
  });

  return (
    <Card bordered={bordered} className={cardCls} size="small">
      <Row className={styles.title} align="middle" justify="space-between">
        <Col>被询问人：{inquiredName}</Col>
        <Col>
          <Badge {...(color && { color })} />
          <span>{text}</span>
        </Col>
      </Row>
      <Row className={styles.duration}>{caseName}</Row>
      <Row className={styles.duration}>
        {startTime} - {endTime}（{weekday} {formattedDate}）
      </Row>
      <Row
        align="bottom"
        justify="space-between"
        style={{ flexWrap: 'nowrap' }}
      >
        <div>
          <div className={styles.subtitles}>
            <div></div>
            {!!inquiredName && (
              <div className={styles.gap}>
                被询问人：{inquiredName}
                {status !== ReservationStatus.Finished &&
                  !!(status & ReservationStatus.InquireeEntered) && (
                    <Tag color="warning">已进入</Tag>
                  )}
              </div>
            )}
            {!!inquirerName && (
              <div>
                询问人：{inquirerName}
                {status !== ReservationStatus.Finished &&
                  !!(status & ReservationStatus.InquirerEntered) && (
                    <Tag color="warning">已进入</Tag>
                  )}
              </div>
            )}
            {!!recorderName && (
              <div>
                记录人：{recorderName}
                {status !== ReservationStatus.Finished &&
                  !!(status & ReservationStatus.RecorderEntered) && (
                    <Tag color="warning">已进入</Tag>
                  )}
              </div>
            )}
          </div>
        </div>
        {renderFooter && renderFooter(id, status, value)}
      </Row>
    </Card>
  );
};

export default ReservationCard;
