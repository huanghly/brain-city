import React, { useEffect, useState } from 'react';
import { EvidenceRecord, InquiryMapIdentity } from 'umi';

import { LinkOutlined, PrinterOutlined } from '@ant-design/icons';
import { Spin, Row, Col, Popover, Button, Card, Empty } from 'antd';
import InquiryCard from '@/components/InquiryCard';

import styles from './CaseInquiry.less';

interface CaseInquiryRecordProps {
  value?: EvidenceRecord;
  mapIdentity: InquiryMapIdentity;
  onDownload: (inquiryId: number) => void;
  onExport: (inquiryId: number) => void;
  onGetQRCode: (uuid: string, callback: (base64: string) => void) => void;
}

const CaseInquiryRecord: React.FC<CaseInquiryRecordProps> = props => {
  const { value, mapIdentity, onDownload, onExport, onGetQRCode } = props;

  const [qrCode, setQRCode] = useState('');
  const uuid = value?.detail?.uuid;
  useEffect(() => {
    if (uuid) {
      onGetQRCode(uuid, (base64: string) => {
        setQRCode(base64);
      });
    }
  }, [uuid]);

  const record = value?.detail;
  if (!value || !record) {
    return <Spin />;
  }

  const renderHeader = () => (
    <Row align="middle" justify="space-between" className={styles.header}>
      <Col className={styles.title}>电子询问笔录</Col>
      <Col className={styles.buttons}>
        <Popover
          trigger="click"
          content={
            value?.blockchainInfo ? (
              <Card>
                <Row>区块链认证记录</Row>
                <Row>文件哈希：{value.blockchainInfo.txHash}</Row>
                <Row>上链时间：{value.blockchainInfo.onlineTime}</Row>
              </Card>
            ) : (
              <Empty />
            )
          }
        >
          <Button
            type="link"
            size="small"
            icon={<i className="iconfont icon-blockchain" />}
          >
            区块链
          </Button>
        </Popover>
        <Button
          type="link"
          size="small"
          icon={<i className="iconfont icon-print" />}
          onClick={() => {
            onDownload(value.inquiryId);
          }}
        >
          笔录打印
        </Button>
        <Button
          type="link"
          size="small"
          icon={<i className="iconfont icon-print" />}
          onClick={() => {
            onExport(value.inquiryId);
          }}
        >
          笔录导出
        </Button>
        {qrCode && <img src={qrCode} />}
      </Col>
    </Row>
  );

  const renderImagePopover = (lineIdx: number) => {
    const recordImages = record.lines![lineIdx];
    return (
      <Row gutter={[8, 8]} className={styles.imageContent}>
        {recordImages.images!.map(image => (
          <Col span={6}>
            <img src={image.file} />
          </Col>
        ))}
      </Row>
    );
  };

  return (
    <>
      <InquiryCard.Basic
        record={record}
        mapIdentity={mapIdentity}
        renderHeader={renderHeader}
      />
      <InquiryCard.Note
        value={record.lines}
        renderImagePopover={renderImagePopover}
      />
      <InquiryCard.Signature record={value.detail} mapIdentity={mapIdentity} />
    </>
  );
};

export default CaseInquiryRecord;
