import React from 'react';
import { RouteComponentProps } from 'react-router';
import { Tabs, Button, Dropdown, Menu, Modal } from 'antd';
import styles from './interrogationIn.less';
import { Media } from '@/common/media';

type IProps = RouteComponentProps;
type IState = {
  mainVideo: string;
  modal: boolean;
};
export default class InterrogationIn extends React.PureComponent<
  IProps,
  IState
> {
  constructor(props: IProps) {
    super(props);
    this.state = {
      mainVideo: '/chenxiao/demo.mp4',
      modal: false,
    };
  }

  private closeModal = () => {
    this.setState({ modal: false });
  };
  private showModal = () => {
    this.setState({ modal: true });
  };

  private onSwitchMainVideoClick = () => {
    this.setState({
      mainVideo: '/chenxiao/demo2.mp4',
      modal: false,
    });
  };

  private onCloseClick = () => {
    this.props.history.push('/inquiryMgr/myReservation');
  };

  render() {
    return (
      <div className={styles.interrogationIn}>
        <div className={styles.topTitle}>
          同步录音录像&nbsp;&nbsp;<span style={{ color: 'green' }}>•</span>{' '}
          00:14
        </div>
        <div className={styles.content}>
          <div className={styles.leftVideos}>
            <img src="/chenxiao/interrogationIn_leftVideos.png" />
            <div>
              <Media className={styles.leftVideo} src="/chenxiao/demo2.mp4" />
            </div>
          </div>
          <div className={styles.middleVideo}>
            <Media
              style={{ width: '100%', height: '100%' }}
              src={this.state.mainVideo}
            />
          </div>
          <div className={styles.rightContent}>
            <Tabs>
              <Tabs.TabPane tab="笔录" key="1">
                <img src="/chenxiao/record.png" />
              </Tabs.TabPane>
              <Tabs.TabPane tab="示证" key="2">
                <img src="/chenxiao/interrogationIn_rightTab2.png" />
              </Tabs.TabPane>
              <Tabs.TabPane tab="接收" key="3">
                <img src="/chenxiao/interrogationIn_rightTab3.png" />
              </Tabs.TabPane>
            </Tabs>
          </div>
        </div>
        <div className={styles.bottomContent}>
          <Modal
            title={null}
            visible={this.state.modal}
            wrapClassName={styles.modal}
            onCancel={this.closeModal}
            onOk={this.onSwitchMainVideoClick}
            okText="确定"
            cancelText="取消"
          >
            你确定向询问人发起签印吗？
          </Modal>
          <div className={styles.buttons}>
            <Dropdown
              overlayClassName={styles.dropdown}
              overlay={
                <Menu>
                  <Menu.Item>
                    <Button type="link">宣读确认</Button>
                  </Menu.Item>
                  <Menu.Item>
                    <Button type="link">浏览确认</Button>
                  </Menu.Item>
                </Menu>
              }
              placement="topCenter"
            >
              <div className={styles.btn1}></div>
            </Dropdown>
            <div className={styles.btn2} onClick={this.showModal}></div>
            <div className={styles.btn3} onClick={this.onCloseClick}></div>
            <div className={styles.btn4}></div>
          </div>
        </div>
      </div>
    );
  }
}
