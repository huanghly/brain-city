import { AnalysisModelType } from 'umi';
import { set } from 'lodash-es';
import { ModelNamespaces } from './constants';
import api from '@/services';
import { handleError } from '@/common/util';

const AnalysisModel: AnalysisModelType = {
  namespace: ModelNamespaces.Analysis,
  state: {
    pieData: [],
    mapData: [],
    statisticData: {},
  },
  effects: {
    *getSatisticsResult(_, { put, call }) {
      try {
        const data = yield call(api.getSatisticsResult);
        yield put({
          type: 'save',
          payload: { value: data, path: ['statisticData'] },
        });
      } catch (err) {
        handleError(err);
      }
    },
    *getPieData(_, { put, call }) {
      try {
        const data = yield call(api.getPieData);
        yield put({
          type: 'save',
          payload: { value: data, path: ['pieData'] },
        });
      } catch (err) {
        handleError(err);
      }
    },
    *getMapData(_, { put, call }) {
      try {
        const data = yield call(api.getMapData);
        yield put({
          type: 'save',
          payload: { value: data, path: ['mapData'] },
        });
      } catch (err) {
        handleError(err);
      }
    },
  },
  reducers: {
    save(state, action) {
      const { value, path } = action.payload;
      set(state, path, value);
    },
  },
  subscriptions: {
    setup({ dispatch, history }) {
      return history.listen(({ pathname }) => {
        if (pathname === '/inquiry/guide') {
          dispatch({ type: 'getSatisticsResult' });
          dispatch({ type: 'getPieData' });
          dispatch({ type: 'getMapData' });
        }
      });
    },
  },
};

export default AnalysisModel;
