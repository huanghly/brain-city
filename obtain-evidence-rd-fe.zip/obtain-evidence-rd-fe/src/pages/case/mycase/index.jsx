import React, { Component } from 'react';
import {
  Input,
  Select,
  DatePicker,
  Button,
  Table,
  Space,
  Drawer,
  Form,
} from 'antd';
import { history } from 'umi';
import { SearchOutlined } from '@ant-design/icons';
import styles from './index.less';

class MyCase extends Component {
  mockColumns() {
    const columns = [
      {
        title: '案事件名称',
        dataIndex: 'name',
        key: 'name',
        render: text => <a>{text}</a>,
      },
      {
        title: '案事件类型',
        dataIndex: 'type',
        key: 'type',
      },
      {
        title: '建档日期',
        dataIndex: 'date',
        key: 'date',
      },
      {
        title: '负责人',
        dataIndex: 'owner',
        key: 'owner',
      },
      {
        title: '下次询问时间',
        dataIndex: 'nextdate',
        key: 'nextdate',
      },
      {
        title: 'Action',
        key: 'action',
        render: () => (
          <Space size="middle">
            <a
              onClick={() => {
                history.push('/case/detail');
              }}
            >
              浏览
            </a>
          </Space>
        ),
      },
    ];
    return columns;
  }

  mockData() {
    const data = [];
    for (var i = 0; i < 10; i++) {
      const item = {};
      item.key = i;
      item.name = '案件' + i;
      item.type = i % 2 ? '诈骗案' : '盗窃案';
      item.date = '2020-06-20';
      item.owner = i % 2 ? '张三' : '李四';
      item.nextdate = '2020-06-30';
      data.push(item);
    }
    return data;
  }

  render() {
    return (
      <div className={styles.wrapper}>
        <h2>我的案件</h2>
        <div className={styles.content}>
          <div className={styles.optbar}>
            <Input
              placeholder="请输入关键词，如案事件名称"
              suffix={<SearchOutlined className="site-form-item-icon" />}
              style={{ width: 248 }}
            />
          </div>
          <Table columns={this.mockColumns()} dataSource={this.mockData()} />
        </div>
      </div>
    );
  }
}

export default MyCase;
