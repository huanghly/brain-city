import React from 'react';
import {
  EvidenceRecord,
  InquiryMapIdentity,
  getInquireeIdentityIdByMapIdentity,
} from 'umi';

import { Spin, Card, Descriptions } from 'antd';

interface CardInquireeProps {
  value?: EvidenceRecord['detail']['inquired'];
  mapIdentity: InquiryMapIdentity;
}

const InquireeCard: React.FC<CardInquireeProps> = props => {
  const { value, mapIdentity } = props;
  if (!value) {
    return <Spin />;
  }

  // @TODO 多被询问人信息
  const currentInquireeIdentityId = getInquireeIdentityIdByMapIdentity(
    mapIdentity,
  )!;
  const inquireeInfo = value[currentInquireeIdentityId];

  return (
    <Card title="被询问人信息" size="small" bordered={false}>
      <Descriptions column={1}>
        <Descriptions.Item label="姓名">
          {inquireeInfo?.userName}
        </Descriptions.Item>
        <Descriptions.Item label="证件号码">
          {inquireeInfo?.certNo}
        </Descriptions.Item>
        <Descriptions.Item label="出生日期">
          {inquireeInfo?.birth}
        </Descriptions.Item>
        <Descriptions.Item label="联系电话">
          {inquireeInfo?.phoneNo}
        </Descriptions.Item>
        <Descriptions.Item label="虚拟身份">
          {inquireeInfo?.virtualName}
        </Descriptions.Item>
      </Descriptions>
    </Card>
  );
};

export default React.memo(InquireeCard);
