import React from 'react';
import { Case } from 'umi';

import { Spin, Card, Row, Col } from 'antd';

import styles from './CaseCard.less';

interface CaseSketchCardProps {
  value?: Case;
}

const CaseSketchCard: React.FC<CaseSketchCardProps> = props => {
  const { value } = props;
  if (!value) {
    return <Spin />;
  }

  const {
    title,
    typeName,
    subTypeName,
    createDate,
    dutyUserName,
    participants,
  } = value;

  return (
    <Card title={title} bordered={false}>
      <Row className={styles.sketch}>
        <Col span={10}>类型</Col>
        <Col span={14}>
          {typeName}-{subTypeName}
        </Col>
        <Col span={10}>建档日期</Col>
        <Col span={14}>{createDate}</Col>
        <Col span={10}>负责人</Col>
        <Col span={14}>{dutyUserName}</Col>
        <Col span={10}>参与侦办人</Col>
        <Col span={14}>
          {participants.map(({ userName }) => userName).join('，')}
        </Col>
      </Row>
    </Card>
  );
};

export default CaseSketchCard;
