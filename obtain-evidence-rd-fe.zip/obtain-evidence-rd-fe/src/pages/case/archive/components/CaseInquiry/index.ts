import TabBar from './TabBar';
import Record from './Record';

export default {
  TabBar,
  Record,
};
