import React from 'react';
import { InquiryInfoSimple } from 'umi';

import { ClockCircleOutlined } from '@ant-design/icons';

interface CaseInquiryTabBarProps {
  inquiry: InquiryInfoSimple;
}

const CaseInquiryTabBar: React.FC<CaseInquiryTabBarProps> = props => {
  const { startTime, endTime } = props.inquiry;
  return (
    <>
      <ClockCircleOutlined />
      <span>
        {startTime}-{endTime}
      </span>
    </>
  );
};

export default CaseInquiryTabBar;
